# Arlecchino install bundle

This archive contains Arlecchino V6, all of its references and runtime scripts,
the ten pinned V4 domain subskills, and the ten pinned native V5 domain
subskills. Both immutable snapshot manifests are included. The installer exposes
Arlecchino and the selected V4 subskills while retaining the native V5 snapshot
as a vendored dependency for explicit source selection.

## Install

```bash
tar -xzf arlecchino-install-ready.tar.gz
cd arlecchino-bundle
./install.sh
```

The default destination is `${CODEX_HOME:-$HOME/.codex}`. To use another Codex
root, set `CODEX_HOME` before running the installer. An optional first argument
overrides only the final `skills` directory:

```bash
CODEX_HOME=/path/to/codex ./install.sh /path/to/codex/skills
```

Existing entries with the same names are moved to a timestamped directory under
`$CODEX_HOME/skill-backups`. The dependency closure is copied under
`$CODEX_HOME/skill-bundles/arlecchino-v6`, so the extracted archive need not be
kept after installation.

Run `./verify.sh` to verify the unpacked bundle without installing it.
