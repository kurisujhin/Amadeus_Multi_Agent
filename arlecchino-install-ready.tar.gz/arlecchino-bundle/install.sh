#!/usr/bin/env bash
set -euo pipefail

bundle_root=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
source_series="$bundle_root/skills/multi-agent-workflow-designer"
codex_root=${CODEX_HOME:-$HOME/.codex}
skills_dir=${1:-$codex_root/skills}
installed_series="$codex_root/skill-bundles/arlecchino-v6/multi-agent-workflow-designer"
stamp=$(date -u +%Y%m%dT%H%M%SZ)-$$
backup_root="$codex_root/skill-backups/arlecchino-$stamp"

"$bundle_root/verify.sh" "$source_series"

if [[ -e "$installed_series" || -L "$installed_series" ]]; then
  mkdir -p "$backup_root/bundle"
  mv "$installed_series" "$backup_root/bundle/multi-agent-workflow-designer"
fi
mkdir -p "$(dirname "$installed_series")"
cp -a "$source_series" "$installed_series"
mkdir -p "$skills_dir"

for source in "$bundle_root"/active/*; do
  name=$(basename "$source")
  target="$skills_dir/$name"
  if [[ -e "$target" || -L "$target" ]]; then
    mkdir -p "$backup_root/skills"
    mv "$target" "$backup_root/skills/$name"
  fi
  if [[ $name == arlecchino ]]; then
    destination="$installed_series/versions/v6"
  else
    destination="$installed_series/subskills/snapshots/2026-07-12/$name"
  fi
  ln -s "$destination" "$target"
done

"$bundle_root/verify.sh" "$installed_series"
for source in "$bundle_root"/active/*; do
  name=$(basename "$source")
  [[ -L "$skills_dir/$name" && -e "$skills_dir/$name/SKILL.md" ]]
done

printf 'Installed Arlecchino and 10 domain subskills into %s\n' "$skills_dir"
printf 'Vendored dependency closure: %s\n' "$installed_series"
if [[ -d "$backup_root" ]]; then
  printf 'Previous entries backed up at %s\n' "$backup_root"
fi
