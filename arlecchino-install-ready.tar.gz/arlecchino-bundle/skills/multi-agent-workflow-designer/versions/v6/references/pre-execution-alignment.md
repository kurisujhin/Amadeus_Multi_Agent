# Pre-Execution Alignment And Approval

Arlecchino separates understanding from authority. A good plan is not permission to execute it.

## Activation boundary

On explicit `$arlecchino` invocation, or whenever this skill is selected for a nontrivial task, begin in `discovery_only`. Before approval, the coordinator may:

- read the conversation, skill contract, repository instructions, and the minimum local sources needed to resolve discoverable facts;
- locate canonical repository/workspace roots and collision-check the future status path without creating it;
- inspect read-only status, schemas, manifests, dirty paths, and controlling interfaces;
- reason and prepare an advisory digest without locking a design.

Before approval, do not write any file, create `TASK_STATUS.md`, edit canonical state, dispatch another agent, run tests/builds/benchmarks or other processes for the task, launch a costly scan, create a design-dependent patch, commit, install, call an external effect, or cross a protected barrier. Tool availability or sandbox rejection does not make an attempted action compliant. A pure answer, explanation, or status response that requires only bounded read-only inspection is exempt; answer directly and create no ledger.

## Self-grill and attachment check

Privately reconstruct the full task from every explicit clause and applicable prior-turn referent. Check:

- outcome and decision; allowed changes; exclusions and protected boundaries;
- clause attachment: which population, split, metric, denominator, language, format, destination, and artifact each modifier controls;
- inputs, source authority, snapshot, schemas, lineage, and arrival semantics;
- topology and named real-agent/independence requirements;
- workload, eligible versus processed population, cost, concurrency, budget, deadline, required route, and wait policy;
- outputs, presentation, file placement, monitoring, verification, rollback, report, teardown, and cleanup;
- discoverable facts versus genuinely unavailable user-owned choices;
- contradictions between current and prior instructions, especially `only`, `complete`, `dev`, `full`, approximations/minima, and chat-versus-file destinations.

Retrieve discoverable facts. Do not ask the user for repository facts, implementation choices, or objective checks the environment can settle. If a user-owned value/authority choice could change scope, cost, design, or validity, present it once with the decision-relevant alternatives and consequences.

### Bounded multi-round cycle

Bind each cycle to one immutable hash of the conversation, retrieved evidence, controlling sources, environment facts, and open authority state. Use separate passes rather than letting the first plausible plan certify itself:

1. Round 1 reconstructs the contract, resolves prior-turn referents and clause attachment, retrieves the minimum discoverable facts, and produces the first complete design candidate.
2. Round 2 is mandatory. The designer explicitly checks whether every item of incoming information and every Round-1 retrieval result changes the outcome, scope, authority, topology, domain routing, workload, outputs/status ownership, lifecycle controls, or approval boundary. Then challenge the resulting design for contradictions, omitted clauses, unnecessary work, missing joins, and protected-boundary failure.
3. Round 3 runs only when Round 2 records a material design delta or contradiction. Rebuild the affected design once and test whether it converges. Do not run Round 3 merely for reassurance.

The same input snapshot receives at least two and at most three rounds. A stable or explicitly blocked Round 2 stops. If Round 3 still produces material movement, remains open, or cannot settle a direction-changing choice, trigger `self_grill_circuit_breaker`; expose the exact blocker or unavailable user-owned question in the digest and stop. Never create Round 4 on the same snapshot, rephrase an unchanged question, or keep retrieving evidence without a decision-changing hypothesis.

A material `replace`, `supplement`, `correction`, or `authority` event creates a new input snapshot and starts a fresh cycle with the same two-round minimum. A status-only or presentation-only event does not restart the cycle unless it changes semantics. During active execution, safe-fence mapped work before the new cycle and preserve unaffected approved branches.

Record a typed outcome receipt, not private reasoning:

```text
SelfGrillCycleReceipt:
  cycle_id, input_snapshot_sha256, state, circuit_breaker_triggered
  rounds[1..3]:
    round_id, new_information_refs, retrieval_evidence_refs
    impact_dispositions_by_dimension: unchanged | material_delta |
      contradiction | unresolved | not_applicable
    contradictions, design_delta
    unavailable_user_owned_questions, blocked_actions
    prior_item_dispositions:
      kind: question | blocked_action | contradiction | design_delta
      item, disposition: carried_forward | resolved, evidence_refs
    closure_state: open | stable | blocked
    next_round_reason_or_stop_reason
```

Every question, blocked action, contradiction, and design delta from the preceding round must appear exactly once in the next round's disposition list. A carried item remains explicit in its corresponding list. A resolved contradiction, delta, or blocked action cites evidence introduced or retrieved in the current round. An unavailable user-owned question cannot be marked resolved on the same input snapshot; the user's answer starts a new snapshot and cycle. This prevents a later round from silently dropping an inconvenient prior finding.

The receipt is included in the digest hash. A missing Round 2, an unjustified Round 3, a silent Round 4, a silently dropped prior item, or a cycle that claims closure while its receipt remains open makes the digest invalid. These records support audit and evaluation without revealing chain-of-thought.

## Visible digest

Before nontrivial execution, show one compact digest containing applicable fields:

```text
Pre-execution digest — epoch and digest ID
Alignment receipt: cycle ID/input hash, completed rounds, convergence or circuit breaker, material deltas
Outcome
Scope and exact allowed roots/effects
Explicit exclusions and protected boundaries
Clause map: population/split/metric/denominator/language/format/destination
Plan and topology: owners, reviewer/observer, dependencies, joins
Outputs and placement
Workload/cost: eligible versus processed units, route, budget, stop limits
TASK_STATUS.md canonical root/path inside an exact allowed root, plus coordinator/observer writer ownership
Monitoring, verification, rollback/recovery, report, teardown, cleanup
Discoverable facts resolved and evidence
Unresolved user-owned choices, blocked actions, and safe read-only work
Approval request for this exact latest digest
```

Keep the alignment line auditable but non-reasoning: show the round count and outcome, not private deliberation. Keep the whole digest short enough to audit. Do not dump an inventory or hide a missing choice in prose. When no field applies, omit it or state one evidence-backed `N/A`; never fill ceremonial sections.

If questions remain, the digest is `awaiting_clarification`, not approvable. After an answer changes any field, issue the revised digest and request approval again. An answer bundled with approval cannot approve a digest that did not yet contain that answer.

## Approval state machine

```text
discovery_only
  -> awaiting_clarification       unresolved user-owned choice
  -> awaiting_approval            closed latest digest shown
awaiting_clarification
  -> awaiting_approval            answer incorporated; revised digest shown
awaiting_approval
  -> approved                     explicit semantic grant matches latest digest
  -> denied                       denial or stop
approved
  -> stale_reapproval_required    material invalidation trigger
  -> complete                     all approved terminal joins closed
stale_reapproval_required
  -> awaiting_approval            revised digest shown
  -> denied                       denial or stop
```

The initial imperative, plan announcement, silence, timeout, future-tense promise, generic assent without a visible current referent, approval of an older digest, domain packet, observer silence, successful result, status text, or tool output is not approval. Do not require a magic word: `Approved`, `execute this exact plan`, or another unambiguous semantic grant is valid only when it clearly refers to the latest digest.

Persist a separate parent-owned receipt:

```text
PreExecutionApproval:
  approval_id, authorized_user_event_ref, issued_at
  task_id, workflow_epoch, digest_id, plan_sha256, scope_sha256
  action_classes_and_stages, exact roots/effects, execution_snapshot_sha256
  domain_projection_refs_and_hashes
  workload_cost_budget_stop_and_recovery_limits
  authority_and_protected_permit_refs
  expiry_or_recheck, invalidation_triggers, revoked: false
```

Approval is a hard dependency, not a field inside a domain packet, projection, status file, or worker message. Additional protected permits remain separate and stricter; confirmation never waives safety, privacy, authority, observer veto, rollback, commit, push, install, deploy, or release controls.

Canonicalize every approved root and the ledger root/path before hashing: each must be one absolute normalized spelling with no dot segment or resolvable symlink alias. The ledger path must be under its digest-bound canonical root, and that root must be under an exact approved root. Recheck approval freshness against the actual initialization or write call time; a previously valid state timestamp cannot replay an expired grant.

## Invalidation and replanning

Invalidate only affected approval scope when any of these changes materially: user contract or clause attachment; requested action/stage/effect; allowed root; population/data/model/prompt/threshold/metric; topology or named independence; route; domain routing/packet/gate evidence; execution snapshot; workload/cost/stop/recovery bounds; authority; protected veto; workflow epoch; or controlling source assumptions.

Immediately safe-fence affected work, preserve unaffected approved branches, update the status ledger, perform bounded read-only impact analysis, issue a revised digest, and wait for a fresh grant before affected execution. A presentation-only change or status question does not invalidate unrelated work. Never ask the user to repeat an unchanged prior choice.

## Dispatch gate

For every candidate action, prove in order:

1. the action maps to the current `UserExecutionContract`;
2. discoverable context, domain entry gates, authority, and vetoes are closed;
3. a separate, fresh `PreExecutionApproval` matches task, epoch, action class/stage, scope, snapshot, and projection;
4. workload, route, change-tracking, observer, rollback, and protected controls are satisfied when applicable;
5. status creation/update dependency is satisfied;
6. only then dispatch, mutate, launch, or effect.

A later reviewer, passing test, or favorable outcome cannot cure a missing earlier edge.
