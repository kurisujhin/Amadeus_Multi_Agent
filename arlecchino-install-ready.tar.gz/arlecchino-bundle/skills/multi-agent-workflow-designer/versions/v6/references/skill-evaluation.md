# Efficient Skill Evaluation

Use `fast reject, slow accept`. Evaluation exists to decide promotion, not to create an endless editing loop.

## Freeze before policy edits

For a reusable behavior change, freeze an `EvolutionEvidencePlan` before the first material policy edit:

- exact unchanged parent and candidate boundary;
- diagnosed incident corpus, deduplication, reminder/non-example criterion, and failure locus;
- behavioral claims, protected invariants, and smallest plausible control-surface change;
- case, chronological event, run, and verdict schemas with additional fields rejected;
- visible cases, withheld keys, matched baseline conditions, route/tools/permissions/budget parity, and untouched custody;
- hard gates, weighted 0–4 rubric, promotion thresholds, invalidation/reuse rules, and campaign cap;
- one-repair and post-freeze disposition.

Keep prompts, keys, arm identity, and untouched content outside the installable package. Bind every artifact by hash.

Use four closed schemas: `Case` freezes the task, interactions, expected controls, and semantic oracle; `Event` records authenticated chronology and attempted effects; `Run` binds source/install/input/evaluator/environment/route/budget and derived chronology; `Verdict` binds blind evidence, every hard gate, every applicable dimension, semantic validity, and disposition. Reject additional fields. Controller-derived grant, route, writer, and event-order evidence takes precedence over respondent prose.

## Tiers

- `T0 mechanics`: zero model calls. Validate package/install closure, metadata, bounded self-grill chronology and prior-item conservation, approval state machine, action classifier, status locator/writer/lifecycle, domain packet authority firewall and all-ten adapter/projection, schemas/custody, evaluator dependency order and thresholds, and retry automaton. Any failure stops.
- `T1 sentinels`: a few frozen candidate cases plus the minimum matched parent baseline covering the changed mechanism, highest-risk collision, and pure non-example. T1 may reject, repair, or justify expansion; it cannot promote.
- `T3 promotion`: only for an explicit whole-skill claim or protected/cross-cutting change. Complete the bounded visible portfolio, matched comparisons, independent blind scoring, protected cases, and one untouched same-fingerprint confirmation.

Skip T2 when the change is inherently cross-cutting and no honest scoped promotion claim exists. Do not launch a tier because capacity is available.

## Chronological evidence

Record typed events for user/assistant turns, approval request/grant/invalidation, tool attempt/result, role dispatch/message, status write and authenticated writer, observer verdict, domain packet validation/projection, verification, budget, and termination. Hash-chain events and derive chronology mechanically. A blocked unsafe attempt remains failure evidence; retrospective prose cannot earn a missed earlier behavior.

Each run binds exact producer/install, rendered input, model and reasoning effort, tools, permissions, budget, seed, environment semantics, topology/order/shared state, evaluator, event chain, output, authority, and freshness. If the required route cannot be selected and attested, wait or withhold the comparative claim; never silently substitute.

## Rubric and gates

Use hard gates for the mandatory second self-grill round, conditional-only third round, no fourth round, conservation or current-evidence resolution of prior findings, approval chronology/freshness, literal digest fidelity, status timing/path/writer/currentness/terminal state, protected controls, pure-answer proportionality, domain non-authority/integration, legacy losslessness, custody/parity, and semantic validity. Hard gates override averages.

Use a weighted 0–4 rubric covering alignment/approval, literal contract, status lifecycle, replanning/observation/terminal joins, domain routing/handoff, protected preservation, and efficiency/user burden. Score 3 means correct and evidence-linked; 4 also means proactive, precise, and low-overhead. Freeze thresholds before outputs.

## Baseline, blinding, and reuse

Matched arms receive identical raw tasks, source universe, model/effort, tools, permissions, budgets, seeds, event policy, and fresh isolated state. Randomize anonymized outputs. Scorers do not see arm/version identity, source hashes, authorship, private keys, respondent identity, or one another's scores. A distinct adjudicator resolves only disagreements.

Reuse requires exact identity or checked equivalence across producer, input, evaluator, environment, hypothesis, topology/order/shared state, authority/freshness, route, and event chain. Evaluator-only changes rescore. Producer/input/topology changes rerun intersecting cases. Protected changes rerun their gates. Unknown reachability quarantines mapped claims pending one cheapest dependency probe.

## Anti-loop contract

- never retry an unchanged candidate, input, environment, and hypothesis;
- never add a same-snapshot self-grill round after Round 3 or rephrase an unchanged question as new evidence;
- stop on deterministic or inescapable hard failure;
- allow at most one consolidated material repair epoch;
- after repair, rerun only affected closures plus two frozen sentinels;
- a new material defect, hard failure, or protected regression after repair means withhold the release;
- freeze candidate, install closure, subskills, cases, rubric, and keys before untouched confirmation;
- no candidate-relevant edit after untouched begins;
- a valid untouched failure means withhold; replace once only for result-independent contamination/infrastructure invalidity proved before unblinding;
- post-freeze defects become successor-version evidence.

Report actual calls, wall time, reused evidence, invalid attempts, uncertainty, and disagreements. Efficiency never substitutes for behavioral promotion evidence.

The campaign controller fails closed if T0 is not bound to the exact candidate/evaluator closure, T3 starts before T1 passes, a repair starts without a recorded visible failure, a preapproval mutation or wrong required route is accepted, an applicable verdict dimension is missing or below threshold, the untouched slot lacks independent sealed custody, or candidate policy changes after untouched exposure. Baseline behavioral failure is scoreable evidence and is not by itself harness invalidity.

## Subskill-change trigger

Audit parent/subskill authority and expressiveness separately. Prefer, in order: parent projection fix; namespaced parent extension; new immutable subskill snapshot only when a frozen case proves that existing packets cannot express a required domain semantic. A new snapshot needs new manifests/fingerprints and, when fields change, a new schema/validator plus all-ten adapter and behavior tests. Never modify an immutable snapshot in place.
