# TASK_STATUS.md Ledger

Maintain a dedicated `TASK_STATUS.md` automatically for every nontrivial Arlecchino task. It is the single human-facing source of truth for the design plan and execution progress. It is not an authority source: never parse Markdown to create approval, permits, observer resume, commit mode, or dispatch edges.

## Locate the path before approval

Resolve and collision-check the path read-only during discovery. Use this order:

1. honor an explicit valid user/repository path inside an authorized persistent workspace;
2. reuse an existing ledger only when its task identity matches the current task;
3. for one canonical repository/worktree with no collision, use `<canonical-root>/TASK_STATUS.md`;
4. for concurrent tasks or an unrelated root-ledger collision, use `<canonical-root>/.codex/tasks/<stable-task-id>/TASK_STATUS.md`;
5. for a task spanning multiple repositories, use `<narrowest-writable-coordinating-workspace>/.codex/tasks/<stable-task-id>/TASK_STATUS.md`;
6. if no unique safe persistent path is discoverable, block and ask for direction rather than guess or overwrite.

Derive the stable task ID from an explicit task ID when supplied; otherwise use a collision-checked normalized task slug plus a short contract hash. Resolve real paths before selection. Reject symlink traversal or escape, cwd-only guesses, parent decoys, unrelated existing ledgers, skill installation/source directories, temporary directories, home, filesystem root, or another broad/unrelated workspace. A multi-repository task gets one coordinating ledger, never competing per-repository ledgers.

Bind both the selected canonical root and exact ledger path into the digest before approval. Each is an absolute normalized, symlink-free spelling; the path lies under that root, and the root lies under an exact approved scope root. The locator, digest, approval, state, and write target must agree on both values. A relative root such as `.` or a path containing `..`, duplicate separators, trailing aliases, or a resolvable symlink is invalid rather than silently normalized after approval.

Task identity is stable across workflow epochs. A material change safe-fences every nonterminal execution through a typed `approval_invalidation` before either `reapproval_refresh`, `writer_transfer`, or same-ledger resume may install the changed digest. The refresh verifies current fence evidence, reconciles the same trusted ledger, materializes every newly derived execution/output/lifecycle/verification obligation, resets changed proof obligations, and records removed obligations as explicit cancelled/skipped history; it never creates a second ledger merely because the epoch changed. An unchanged-digest approval renewal may refresh expiry without a material fence. Reuse requires the trusted parent identity registry, not a task name parsed from Markdown.

## Creation and ownership

The ledger is a write. Create or update it only after a matching `PreExecutionApproval`; for a new nontrivial task it must be the first mutation after approval and precede delegation, repository mutation, or test/process launch. Validate approval expiry against the actual initialization/write call time, not the ledger's stored event or update time. After expiry, progress, blocker resolution, and completion writes require a new matching approval. A newly observed open blocker or non-complete terminal disposition may still be recorded, but the same atomic update marks approval stale, fences every nonterminal execution, and remains awaiting reapproval (or terminal); it cannot revive execution.

Declare one canonical writer lease at a time:

- coordinator is the default writer;
- a named observer may write only when its lease/transfer and scope are declared;
- executor, reviewer, domain specialist, and other agents never edit the file directly;
- non-writers return a `StatusDeltaPacket` to the coordinator/observer, which validates evidence and applies it.

```text
StatusDeltaPacket:
  task_id, epoch, source_runtime_and_role, observed_at
  affected_milestone_or_node, proposed_state
  evidence_refs, blocker_or_verification, next_step
  source_snapshot, sensitivity, confidence
```

Reject self-labelled writer roles; use authenticated runtime/tool identity. Serialize writes and re-read the current sequence before update. A worker-authored delta relayed and rendered by the coordinator remains a coordinator write.

## Required content

Use the packaged template and keep the following current:

- task identity, workflow epoch, canonical root/path, coordinator, observer, current writer, update sequence/time, overall state;
- confirmed contract, digest/plan/scope hashes, approval state and evidence reference, exclusions, wait policy, change mode, effect authorities;
- self-grill cycle ID/input hash, completed round count, dimension-level impact summary, design deltas, convergence or circuit-breaker result, and blocker/question references—never private reasoning;
- domain routing, projection/gate state, user-owned questions, and protected vetoes;
- milestone table with stable ID, owner, state, evidence, and next step;
- current DAG execution: ready, dispatched, running, blocked, waiting, joins, monitoring, and terminal nodes;
- decisions, corrections, replans, invalidations, and approval refreshes;
- blockers/risks with owner, evidence, recheck trigger, and required action;
- verification results bound to exact snapshots;
- terminal disposition, report/output links, residual uncertainty, teardown/cleanup, and open joins.

The ledger may reference opaque authority receipts but must not embed secrets or sensitive raw payloads. `approved` in Markdown reports a verified external receipt; it cannot create one.

## Update triggers

Update immediately after:

- initial post-approval creation and any approval invalidation/refresh;
- each material milestone or change to the ready set caused by dispatch/completion;
- material correction, supplement, replan, scope/route/domain/evidence change, or partial invalidation;
- completion of a post-input self-grill cycle when it changes the digest, closes a replan, or trips its bounded circuit breaker;
- blocker, circuit breaker, observer intervention, recovery, restart, or wait-policy event;
- decision-relevant observation or workload contradiction;
- every verification result, including failure and its disposition;
- requested report creation, terminal join closure, teardown, cleanup, or final disposition.

Do not rewrite for every microstep or cosmetic narration. Do not postpone all updates until the final answer: retrospective final-only creation/update fails the contract. Increment the sequence monotonically and preserve prior decisions/evidence in append-only tables where practical.

Because the initial cycle precedes approval, do not violate the write barrier merely to log it. Include its final receipt summary in the first post-approval ledger creation. For a later material input, record the immediate safe-fence/invalidation under the existing authority, then update again when the new bounded cycle converges or blocks.

## Completion

The final assistant response and the ledger must agree. Derive a nonempty terminal obligation set deterministically from every approved plan node, requested output, and the approved monitoring, verification, rollback/recovery, report, teardown, and cleanup clauses. Materialize those entries at initialization; callers cannot replace the set with a smaller hand-written list, omit its catalogs, or override a digest-derived ID as pre-completed at sequence zero. A required plan node must be completed, every required lifecycle/output milestone completed, and required verification passed. `cancelled` or `skipped` does not silently satisfy required work; removing or waiving an obligation requires a typed material replan in a newly approved digest, with the old work safe-fenced and the replacement obligations materialized. Mark complete only after those joins plus applicable observer/reviewer and protected-effect dispositions close. Otherwise record `blocked`, `withheld`, or `partial` with exact open joins and next action.
