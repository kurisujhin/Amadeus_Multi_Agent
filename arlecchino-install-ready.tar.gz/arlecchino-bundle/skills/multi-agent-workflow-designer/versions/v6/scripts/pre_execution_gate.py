#!/usr/bin/env python3
"""Deterministic Arlecchino V6 pre-execution approval gate.

This module validates typed parent state. It never infers approval from prose,
domain packets, TASK_STATUS.md, or tool results.
"""

from __future__ import annotations

import argparse
import copy
import hashlib
import json
import os
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


DIGEST_FORMAT = "arlecchino-pre-execution-digest-v1"
APPROVAL_FORMAT = "arlecchino-pre-execution-approval-v1"
APPROVAL_KEYS = {
    "format",
    "approval_id",
    "authorized_user_event_ref",
    "issued_at",
    "expires_at",
    "task_id",
    "workflow_epoch",
    "digest_id",
    "digest_sha256",
    "plan_sha256",
    "scope_sha256",
    "action_classes_and_stages",
    "exact_roots_and_effects",
    "execution_snapshot_sha256",
    "domain_projection_refs_and_hashes",
    "workload_cost_budget_stop_and_recovery_limits",
    "authority_and_protected_permit_refs",
    "invalidation_triggers",
    "revoked",
    "state",
    "invalidation_evidence",
}
STATES = {
    "discovery_only",
    "awaiting_clarification",
    "awaiting_approval",
    "approved",
    "denied",
    "stale_reapproval_required",
    "complete",
}
SAFE_PREAPPROVAL_OPS = {"inspect", "advisory", "answer"}
SAFE_PREAPPROVAL_EFFECTS = {"none", "read_only", "advisory"}
NONTRIVIAL_OPS = {
    "status_write",
    "repo_write",
    "dispatch",
    "test",
    "build",
    "benchmark",
    "launch",
    "costly_scan",
    "design_lock",
    "commit",
    "install",
    "external_effect",
    "protected_effect",
}
MATERIAL_INVALIDATION_FIELDS = {
    "user_contract",
    "clause_attachment",
    "action",
    "stage",
    "scope",
    "allowed_roots",
    "effects",
    "population",
    "data",
    "model",
    "prompt",
    "threshold",
    "metric",
    "topology",
    "route",
    "domain_routing",
    "domain_packet",
    "gate_evidence",
    "execution_snapshot",
    "workload",
    "cost",
    "stop_limits",
    "recovery",
    "authority",
    "protected_veto",
    "workflow_epoch",
}
GRILL_FORMAT = "arlecchino-self-grill-cycle-v1"
GRILL_IMPACT_DIMENSIONS = (
    "outcome_and_prior_turn_referents",
    "clause_attachment_population_split_metric_denominator_language_format_destination",
    "scope_exclusions_and_protected_authority",
    "plan_topology_owners_independence_and_joins",
    "domain_routing_gates_and_action_bindings",
    "workload_eligible_processed_retained_cost_budget_route_and_wait_policy",
    "outputs_status_path_and_writer_ownership",
    "monitoring_verification_rollback_report_teardown_and_cleanup",
    "approval_invalidation_and_blocked_actions",
)
GRILL_DISPOSITIONS = {"unchanged", "material_delta", "contradiction", "unresolved", "not_applicable"}
GRILL_ROUND_KEYS = {
    "cycle_id",
    "round_id",
    "input_snapshot_sha256",
    "new_information_refs",
    "retrieval_evidence_refs",
    "impact_dispositions_by_dimension",
    "contradictions",
    "design_delta",
    "unavailable_user_owned_questions",
    "blocked_actions",
    "prior_item_dispositions",
    "closure_state",
    "next_round_reason_or_stop_reason",
}
GRILL_PRIOR_ITEM_FIELDS = {
    "question": "unavailable_user_owned_questions",
    "blocked_action": "blocked_actions",
    "contradiction": "contradictions",
    "design_delta": "design_delta",
}


class GateError(ValueError):
    """A fail-closed contract violation."""


def canonical_bytes(value: Any) -> bytes:
    return json.dumps(
        value, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False
    ).encode("utf-8")


def sha256(value: Any) -> str:
    return hashlib.sha256(canonical_bytes(value)).hexdigest()


def _nonempty_string(value: Any, field: str) -> str:
    if not isinstance(value, str) or not value.strip():
        raise GateError(f"{field} must be a non-empty string")
    return value


def _string_list(value: Any, field: str, *, allow_empty: bool = True) -> list[str]:
    if not isinstance(value, list) or (not allow_empty and not value):
        raise GateError(f"{field} must be a list" + (" with at least one value" if not allow_empty else ""))
    if any(not isinstance(item, str) or not item.strip() for item in value):
        raise GateError(f"{field} must contain non-empty strings")
    if len(value) != len(set(value)):
        raise GateError(f"{field} must not contain duplicates")
    return value


def _sha256_string(value: Any, field: str) -> str:
    if (
        not isinstance(value, str)
        or len(value) != 64
        or any(char not in "0123456789abcdef" for char in value)
    ):
        raise GateError(f"{field} must be lowercase SHA-256")
    return value


def canonical_absolute_path(value: Any, field: str) -> str:
    """Validate one absolute, normalized, symlink-free path spelling.

    Approval receipts bind path strings, so a cwd-relative spelling, lexical
    ``..`` segment, duplicate separator, or already-resolvable symlink would
    make the same string denote different effects at another call site.
    Nonexistent suffixes are allowed for planned outputs, but every existing
    prefix must already resolve to the exact approved spelling.
    """

    value = _nonempty_string(value, field)
    candidate = Path(value)
    if not candidate.is_absolute():
        raise GateError(f"{field} must be an absolute path")
    if os.path.normpath(value) != value or os.fspath(candidate) != value:
        raise GateError(f"{field} must use one normalized absolute spelling")
    if any(part in {".", ".."} for part in candidate.parts):
        raise GateError(f"{field} must not contain dot segments")
    try:
        resolved = candidate.resolve(strict=False)
    except (OSError, RuntimeError) as exc:
        raise GateError(f"{field} cannot be resolved safely") from exc
    if os.fspath(resolved) != value:
        raise GateError(f"{field} must not contain a resolvable symlink alias")
    return value


def path_is_within(path: str, root: str) -> bool:
    """Return lexical containment after both values passed canonical validation."""

    try:
        Path(path).relative_to(Path(root))
        return True
    except ValueError:
        return False


def new_self_grill_cycle(*, cycle_id: str, input_snapshot_sha256: str) -> dict[str, Any]:
    _nonempty_string(cycle_id, "cycle_id")
    if (
        not isinstance(input_snapshot_sha256, str)
        or len(input_snapshot_sha256) != 64
        or any(char not in "0123456789abcdef" for char in input_snapshot_sha256)
    ):
        raise GateError("input_snapshot_sha256 must be lowercase SHA-256")
    return {
        "format": GRILL_FORMAT,
        "cycle_id": cycle_id,
        "input_snapshot_sha256": input_snapshot_sha256,
        "rounds": [],
        "state": "round_1_required",
        "circuit_breaker_triggered": False,
    }


def _validate_grill_round(round_receipt: dict[str, Any], cycle: dict[str, Any]) -> dict[str, Any]:
    if not isinstance(round_receipt, dict) or set(round_receipt) != GRILL_ROUND_KEYS:
        raise GateError("self-grill round fields mismatch")
    if round_receipt["cycle_id"] != cycle["cycle_id"]:
        raise GateError("self-grill round belongs to another cycle")
    expected_round = len(cycle["rounds"]) + 1
    if round_receipt["round_id"] != expected_round or expected_round > 3:
        raise GateError("self-grill rounds must be sequential and stop at three")
    if round_receipt["input_snapshot_sha256"] != cycle["input_snapshot_sha256"]:
        raise GateError("self-grill input snapshot changed inside a cycle")
    for field in (
        "new_information_refs",
        "retrieval_evidence_refs",
        "contradictions",
        "design_delta",
        "unavailable_user_owned_questions",
        "blocked_actions",
    ):
        _string_list(round_receipt[field], f"self_grill.{field}")
    impacts = round_receipt["impact_dispositions_by_dimension"]
    if not isinstance(impacts, dict) or set(impacts) != set(GRILL_IMPACT_DIMENSIONS):
        raise GateError("self-grill impact dimensions mismatch")
    if any(value not in GRILL_DISPOSITIONS for value in impacts.values()):
        raise GateError("self-grill impact disposition is unsupported")
    if round_receipt["closure_state"] not in {"open", "stable", "blocked"}:
        raise GateError("self-grill closure_state is unsupported")
    if "material_delta" in impacts.values() and not round_receipt["design_delta"]:
        raise GateError("material self-grill impact requires an explicit design delta")
    if "contradiction" in impacts.values() and not round_receipt["contradictions"]:
        raise GateError("contradiction disposition requires an explicit contradiction")
    unresolved = "unresolved" in impacts.values()
    has_blocker = bool(
        round_receipt["unavailable_user_owned_questions"]
        or round_receipt["blocked_actions"]
    )
    if unresolved and (not has_blocker or round_receipt["closure_state"] != "blocked"):
        raise GateError("unresolved self-grill impact must close as an explicit blocker")
    if round_receipt["closure_state"] == "stable" and has_blocker:
        raise GateError("stable self-grill round cannot retain a blocker or question")
    if round_receipt["closure_state"] == "blocked" and not has_blocker:
        raise GateError("blocked self-grill round must expose a blocker or question")

    dispositions = round_receipt["prior_item_dispositions"]
    if not isinstance(dispositions, list):
        raise GateError("self-grill prior_item_dispositions must be a list")
    expected_prior: set[tuple[str, str]] = set()
    if cycle["rounds"]:
        previous = cycle["rounds"][-1]
        for kind, field in GRILL_PRIOR_ITEM_FIELDS.items():
            expected_prior.update((kind, item) for item in previous[field])
    observed_prior: set[tuple[str, str]] = set()
    available_resolution_refs = set(
        round_receipt["new_information_refs"] + round_receipt["retrieval_evidence_refs"]
    )
    for item in dispositions:
        if not isinstance(item, dict) or set(item) != {
            "kind",
            "item",
            "disposition",
            "evidence_refs",
        }:
            raise GateError("self-grill prior-item disposition fields mismatch")
        kind = item["kind"]
        if kind not in GRILL_PRIOR_ITEM_FIELDS:
            raise GateError("self-grill prior-item kind is unsupported")
        prior_item = _nonempty_string(item["item"], "self_grill.prior_item")
        key = (kind, prior_item)
        if key in observed_prior:
            raise GateError("self-grill prior item was dispositioned more than once")
        observed_prior.add(key)
        if item["disposition"] not in {"carried_forward", "resolved"}:
            raise GateError("self-grill prior-item disposition is unsupported")
        evidence_refs = _string_list(
            item["evidence_refs"],
            "self_grill.prior_item.evidence_refs",
        )
        current_items = set(round_receipt[GRILL_PRIOR_ITEM_FIELDS[kind]])
        if item["disposition"] == "carried_forward":
            if prior_item not in current_items:
                raise GateError("carried self-grill item must remain explicit in the next round")
        else:
            if kind == "question":
                raise GateError("an unavailable user-owned question requires a new input snapshot")
            if not evidence_refs or not set(evidence_refs) <= available_resolution_refs:
                raise GateError("resolved self-grill item requires current evidence references")
    if observed_prior != expected_prior:
        raise GateError("every prior self-grill item must be carried or evidence-resolved")
    _nonempty_string(
        round_receipt["next_round_reason_or_stop_reason"],
        "self_grill.next_round_reason_or_stop_reason",
    )
    return copy.deepcopy(round_receipt)


def _round_is_material(round_receipt: dict[str, Any]) -> bool:
    return bool(
        round_receipt["design_delta"]
        or round_receipt["contradictions"]
        or any(
            value in {"material_delta", "contradiction"}
            for value in round_receipt["impact_dispositions_by_dimension"].values()
        )
    )


def add_self_grill_round(cycle: dict[str, Any], round_receipt: dict[str, Any]) -> dict[str, Any]:
    validate_self_grill_cycle(cycle, require_complete=False)
    if cycle["state"] in {"digest_ready", "digest_blocked", "circuit_breaker"}:
        raise GateError("self-grill cycle is already closed")
    receipt = _validate_grill_round(round_receipt, cycle)
    result = copy.deepcopy(cycle)
    result["rounds"].append(receipt)
    round_id = receipt["round_id"]
    material = _round_is_material(receipt)

    if round_id == 1:
        result["state"] = "round_2_required"
    elif round_id == 2:
        if material:
            result["state"] = "round_3_required"
        elif receipt["unavailable_user_owned_questions"] or receipt["blocked_actions"] or receipt["closure_state"] == "blocked":
            result["state"] = "digest_blocked"
        elif receipt["closure_state"] == "stable":
            result["state"] = "digest_ready"
        else:
            raise GateError("a non-material second round must close or expose a blocker")
    else:
        # Round three is the no-new-evidence circuit boundary. It may close the
        # Round-2 delta once; otherwise it must expose blockers instead of looping.
        if material or receipt["closure_state"] == "open":
            if not (receipt["unavailable_user_owned_questions"] or receipt["blocked_actions"]):
                raise GateError("nonconverged third round must expose a blocker or question")
            result["state"] = "circuit_breaker"
            result["circuit_breaker_triggered"] = True
        elif receipt["unavailable_user_owned_questions"] or receipt["blocked_actions"] or receipt["closure_state"] == "blocked":
            result["state"] = "digest_blocked"
        elif receipt["closure_state"] == "stable":
            result["state"] = "digest_ready"
        else:
            raise GateError("third round has no valid stop disposition")
    validate_self_grill_cycle(result, require_complete=False)
    return result


def validate_self_grill_cycle(cycle: dict[str, Any], *, require_complete: bool = True) -> dict[str, Any]:
    required = {
        "format",
        "cycle_id",
        "input_snapshot_sha256",
        "rounds",
        "state",
        "circuit_breaker_triggered",
    }
    if not isinstance(cycle, dict) or set(cycle) != required:
        raise GateError("self-grill cycle fields mismatch")
    if cycle["format"] != GRILL_FORMAT:
        raise GateError("wrong self-grill cycle format")
    _nonempty_string(cycle["cycle_id"], "self_grill.cycle_id")
    snapshot = cycle["input_snapshot_sha256"]
    if not isinstance(snapshot, str) or len(snapshot) != 64 or any(char not in "0123456789abcdef" for char in snapshot):
        raise GateError("self-grill input snapshot must be lowercase SHA-256")
    if not isinstance(cycle["rounds"], list) or len(cycle["rounds"]) > 3:
        raise GateError("self-grill rounds must be a list capped at three")
    if not isinstance(cycle["circuit_breaker_triggered"], bool):
        raise GateError("self-grill circuit breaker flag must be boolean")
    expected_states = {
        0: {"round_1_required"},
        1: {"round_2_required"},
        2: {"round_3_required", "digest_ready", "digest_blocked"},
        3: {"digest_ready", "digest_blocked", "circuit_breaker"},
    }
    if cycle["state"] not in expected_states[len(cycle["rounds"])]:
        raise GateError("self-grill state does not match its round count")
    for index, item in enumerate(cycle["rounds"], 1):
        if item.get("round_id") != index:
            raise GateError("self-grill round sequence is invalid")
        _validate_grill_round(item, {**cycle, "rounds": cycle["rounds"][: index - 1]})
    if len(cycle["rounds"]) == 2:
        material = _round_is_material(cycle["rounds"][1])
        if material != (cycle["state"] == "round_3_required"):
            raise GateError("material second-round delta must require round three")
    if len(cycle["rounds"]) == 3:
        if not _round_is_material(cycle["rounds"][1]):
            raise GateError("round three is allowed only after a material second-round delta")
        third_requires_breaker = (
            _round_is_material(cycle["rounds"][2])
            or cycle["rounds"][2]["closure_state"] == "open"
        )
        if third_requires_breaker != (cycle["state"] == "circuit_breaker"):
            raise GateError("third-round convergence state is inconsistent")
        if third_requires_breaker and not (
            cycle["rounds"][2]["unavailable_user_owned_questions"]
            or cycle["rounds"][2]["blocked_actions"]
        ):
            raise GateError("third-round circuit breaker must expose a blocker or question")
    if cycle["state"] == "circuit_breaker" and not cycle["circuit_breaker_triggered"]:
        raise GateError("circuit-breaker state requires its flag")
    if cycle["state"] != "circuit_breaker" and cycle["circuit_breaker_triggered"]:
        raise GateError("circuit-breaker flag is inconsistent")
    if require_complete and cycle["state"] not in {"digest_ready", "digest_blocked", "circuit_breaker"}:
        raise GateError("self-grill cycle has not completed the required impact/challenge rounds")
    return cycle


def input_requires_new_grill_cycle(*, event_kind: str, semantic_change: bool) -> bool:
    if event_kind not in {"replace", "supplement", "correction", "status", "authority", "presentation"}:
        raise GateError("unknown human input event kind")
    if event_kind in {"status", "presentation"} and not semantic_change:
        return False
    return semantic_change or event_kind in {"replace", "supplement", "correction", "authority"}


def validate_digest(digest: dict[str, Any]) -> dict[str, str]:
    if not isinstance(digest, dict):
        raise GateError("digest must be an object")
    required = {
        "format",
        "task_id",
        "workflow_epoch",
        "digest_id",
        "outcome",
        "scope",
        "exclusions",
        "clause_map",
        "plan",
        "topology",
        "outputs",
        "workload_cost",
        "task_status",
        "monitoring_verification_cleanup",
        "resolved_facts",
        "questions",
        "blocked_actions",
        "execution_snapshot_sha256",
        "domain_projection_refs_and_hashes",
        "authority_and_protected_permit_refs",
        "self_grill_cycle_receipt",
    }
    if set(digest) != required:
        missing = sorted(required - set(digest))
        extra = sorted(set(digest) - required)
        raise GateError(f"digest fields mismatch; missing={missing}, extra={extra}")
    if digest["format"] != DIGEST_FORMAT:
        raise GateError("wrong digest format")
    for field in ("task_id", "workflow_epoch", "digest_id", "outcome"):
        _nonempty_string(digest[field], field)
    snapshot = _nonempty_string(digest["execution_snapshot_sha256"], "execution_snapshot_sha256")
    if len(snapshot) != 64 or any(char not in "0123456789abcdef" for char in snapshot):
        raise GateError("execution_snapshot_sha256 must be lowercase SHA-256")

    scope = digest["scope"]
    if not isinstance(scope, dict) or set(scope) != {"allowed_roots", "actions", "effects"}:
        raise GateError("scope must contain exactly allowed_roots, actions, effects")
    roots = _string_list(scope["allowed_roots"], "scope.allowed_roots", allow_empty=False)
    for index, root in enumerate(roots):
        canonical_absolute_path(root, f"scope.allowed_roots[{index}]")
    _string_list(scope["actions"], "scope.actions", allow_empty=False)
    _string_list(scope["effects"], "scope.effects")
    _string_list(digest["exclusions"], "exclusions")

    clause_map = digest["clause_map"]
    if not isinstance(clause_map, list) or not clause_map:
        raise GateError("clause_map must contain at least one mapping")
    for item in clause_map:
        if not isinstance(item, dict) or set(item) != {"clause", "attaches_to"}:
            raise GateError("each clause_map item must contain clause and attaches_to")
        _nonempty_string(item["clause"], "clause_map.clause")
        _nonempty_string(item["attaches_to"], "clause_map.attaches_to")

    plan = digest["plan"]
    if not isinstance(plan, list) or not plan:
        raise GateError("plan must contain at least one node")
    node_ids: list[str] = []
    for node in plan:
        if not isinstance(node, dict) or set(node) != {"node_id", "owner", "action", "stage", "dependencies"}:
            raise GateError("plan node has wrong fields")
        node_ids.append(_nonempty_string(node["node_id"], "plan.node_id"))
        for field in ("owner", "action", "stage"):
            _nonempty_string(node[field], f"plan.{field}")
        _string_list(node["dependencies"], "plan.dependencies")
    if len(node_ids) != len(set(node_ids)):
        raise GateError("duplicate plan node_id")
    if any(node["action"] not in scope["actions"] for node in plan):
        raise GateError("every plan action must be declared in scope.actions")
    known_nodes = set(node_ids)
    if any(
        dependency not in known_nodes or dependency == node["node_id"]
        for node in plan
        for dependency in node["dependencies"]
    ):
        raise GateError("plan dependencies must reference another declared node")
    dependencies_by_node = {
        node["node_id"]: set(node["dependencies"])
        for node in plan
    }
    resolved: set[str] = set()
    while len(resolved) < len(dependencies_by_node):
        ready = {
            node_id
            for node_id, dependencies in dependencies_by_node.items()
            if node_id not in resolved and dependencies <= resolved
        }
        if not ready:
            raise GateError("plan dependency graph contains a cycle")
        resolved.update(ready)

    topology = digest["topology"]
    if not isinstance(topology, dict) or set(topology) != {"mode", "roles", "joins"}:
        raise GateError("topology must contain exactly mode, roles, joins")
    _nonempty_string(topology["mode"], "topology.mode")
    _string_list(topology["roles"], "topology.roles", allow_empty=False)
    _string_list(topology["joins"], "topology.joins")
    _string_list(digest["outputs"], "outputs", allow_empty=False)

    workload = digest["workload_cost"]
    workload_fields = {
        "eligible_units",
        "processed_units",
        "retained_units",
        "cost_basis",
        "budget",
        "stop_limits",
        "recovery_limits",
        "route_and_wait_policy",
    }
    if not isinstance(workload, dict) or set(workload) != workload_fields:
        raise GateError("workload_cost fields mismatch")
    for field in workload_fields:
        if field.endswith("_units"):
            if not isinstance(workload[field], (int, str)) or isinstance(workload[field], bool):
                raise GateError(f"workload_cost.{field} must be integer or evidence-backed text")
        else:
            _nonempty_string(workload[field], f"workload_cost.{field}")

    status = digest["task_status"]
    if not isinstance(status, dict) or set(status) != {
        "canonical_root",
        "path",
        "allowed_writers",
        "current_writer",
    }:
        raise GateError("task_status fields mismatch")
    canonical_root = canonical_absolute_path(
        status["canonical_root"], "task_status.canonical_root"
    )
    status_path = canonical_absolute_path(status["path"], "task_status.path")
    if Path(status_path).name != "TASK_STATUS.md":
        raise GateError("task_status.path must name TASK_STATUS.md")
    if not path_is_within(status_path, canonical_root):
        raise GateError("task_status.path must lie under task_status.canonical_root")
    if not any(path_is_within(canonical_root, root) for root in roots):
        raise GateError("task_status.canonical_root must lie under an approved root")
    if status["allowed_writers"] != ["coordinator", "observer"]:
        raise GateError("task_status.allowed_writers must be coordinator, observer")
    if status["current_writer"] not in {"coordinator", "observer"}:
        raise GateError("task_status.current_writer must be coordinator or observer")

    terminal = digest["monitoring_verification_cleanup"]
    terminal_fields = {"monitoring", "verification", "rollback_recovery", "report", "teardown", "cleanup"}
    if not isinstance(terminal, dict) or set(terminal) != terminal_fields:
        raise GateError("monitoring_verification_cleanup fields mismatch")
    for field in terminal_fields:
        _nonempty_string(terminal[field], f"monitoring_verification_cleanup.{field}")

    for field in ("resolved_facts", "questions", "blocked_actions"):
        _string_list(digest[field], field)
    references = digest["domain_projection_refs_and_hashes"]
    if not isinstance(references, list):
        raise GateError("domain_projection_refs_and_hashes must be a list")
    normalized_references: list[bytes] = []
    for reference in references:
        if not isinstance(reference, dict) or set(reference) != {
            "projection_ref",
            "projection_sha256",
        }:
            raise GateError("domain projection reference fields mismatch")
        _nonempty_string(reference["projection_ref"], "domain_projection.projection_ref")
        _sha256_string(reference["projection_sha256"], "domain_projection.projection_sha256")
        normalized_references.append(canonical_bytes(reference))
    if len(normalized_references) != len(set(normalized_references)):
        raise GateError("domain projection references must not contain duplicates")
    _string_list(
        digest["authority_and_protected_permit_refs"],
        "authority_and_protected_permit_refs",
    )

    cycle = validate_self_grill_cycle(digest["self_grill_cycle_receipt"])
    if cycle["state"] == "digest_ready" and digest["questions"]:
        raise GateError("a ready self-grill cycle cannot hide unresolved questions")
    if cycle["state"] in {"digest_blocked", "circuit_breaker"} and not (
        digest["questions"] or digest["blocked_actions"]
    ):
        raise GateError("a blocked/circuit-breaker digest must expose questions or blocked actions")
    if cycle["state"] in {"digest_blocked", "circuit_breaker"}:
        final_round = cycle["rounds"][-1]
        if not set(final_round["unavailable_user_owned_questions"]).issubset(digest["questions"]):
            raise GateError("self-grill questions must be exposed unchanged in the digest")
        if not set(final_round["blocked_actions"]).issubset(digest["blocked_actions"]):
            raise GateError("self-grill blocked actions must be exposed unchanged in the digest")

    return digest_hashes(digest)


def digest_hashes(digest: dict[str, Any]) -> dict[str, str]:
    scope_projection = {
        "task_id": digest["task_id"],
        "workflow_epoch": digest["workflow_epoch"],
        "scope": digest["scope"],
        "exclusions": digest["exclusions"],
        "clause_map": digest["clause_map"],
        "outputs": digest["outputs"],
        "task_status": digest["task_status"],
    }
    plan_projection = {
        "plan": digest["plan"],
        "topology": digest["topology"],
        "workload_cost": digest["workload_cost"],
        "monitoring_verification_cleanup": digest["monitoring_verification_cleanup"],
        "domain_projection_refs_and_hashes": digest["domain_projection_refs_and_hashes"],
        "self_grill_cycle_receipt": digest["self_grill_cycle_receipt"],
    }
    return {
        "digest_sha256": sha256(digest),
        "plan_sha256": sha256(plan_projection),
        "scope_sha256": sha256(scope_projection),
    }


def state_for_digest(digest: dict[str, Any]) -> str:
    validate_digest(digest)
    cycle_state = digest["self_grill_cycle_receipt"]["state"]
    return (
        "awaiting_clarification"
        if digest["questions"] or cycle_state != "digest_ready"
        else "awaiting_approval"
    )


def classify_action(action: dict[str, Any], *, task_kind: str = "nontrivial") -> str:
    if not isinstance(action, dict):
        raise GateError("action must be an object")
    expected = {"op", "effect_class", "bounded", "costly", "locks_design"}
    if set(action) != expected:
        raise GateError("action fields mismatch")
    op = _nonempty_string(action["op"], "action.op")
    effect_class = _nonempty_string(action["effect_class"], "action.effect_class")
    if not isinstance(action["bounded"], bool) or not isinstance(action["costly"], bool) or not isinstance(action["locks_design"], bool):
        raise GateError("action flags must be boolean")
    if op in NONTRIVIAL_OPS or effect_class not in SAFE_PREAPPROVAL_EFFECTS or action["costly"] or action["locks_design"]:
        return "approval_required"
    if op in SAFE_PREAPPROVAL_OPS and action["bounded"]:
        if task_kind in {"pure_answer", "status_only"}:
            return "exempt_direct"
        return "preapproval_read_only"
    return "approval_required"


def issue_approval(
    digest: dict[str, Any],
    user_event: dict[str, Any],
    *,
    issued_at: str,
    expires_at: str | None = None,
) -> dict[str, Any]:
    hashes = validate_digest(digest)
    if digest["questions"] or digest["self_grill_cycle_receipt"]["state"] != "digest_ready":
        raise GateError("only a converged digest-ready self-grill cycle can be approved")
    required_event = {
        "source_role",
        "controller_derived",
        "explicit",
        "semantic_grant",
        "refers_to_digest_id",
        "user_event_ref",
        "material_changes",
    }
    if not isinstance(user_event, dict) or set(user_event) != required_event:
        raise GateError("user event fields mismatch")
    if user_event["source_role"] != "user" or user_event["controller_derived"] is not True:
        raise GateError("approval must come from an authenticated controller-derived user event")
    if user_event["explicit"] is not True or user_event["semantic_grant"] is not True:
        raise GateError("approval must be explicit and semantically grant execution")
    if user_event["refers_to_digest_id"] != digest["digest_id"]:
        raise GateError("approval does not refer to the latest digest")
    _nonempty_string(user_event["user_event_ref"], "user_event_ref")
    if not isinstance(user_event["material_changes"], list):
        raise GateError("material_changes must be a list")
    if user_event["material_changes"]:
        raise GateError("a correction bundled with assent requires a revised digest and reconfirmation")
    _parse_time(issued_at, "issued_at")
    if expires_at is not None and _parse_time(expires_at, "expires_at") <= _parse_time(issued_at, "issued_at"):
        raise GateError("expires_at must be after issued_at")

    approval_core = {
        "format": APPROVAL_FORMAT,
        "authorized_user_event_ref": user_event["user_event_ref"],
        "issued_at": issued_at,
        "expires_at": expires_at,
        "task_id": digest["task_id"],
        "workflow_epoch": digest["workflow_epoch"],
        "digest_id": digest["digest_id"],
        **hashes,
        "action_classes_and_stages": [
            {"action": node["action"], "stage": node["stage"]} for node in digest["plan"]
        ],
        "exact_roots_and_effects": {
            "allowed_roots": digest["scope"]["allowed_roots"],
            "effects": digest["scope"]["effects"],
        },
        "execution_snapshot_sha256": digest["execution_snapshot_sha256"],
        "domain_projection_refs_and_hashes": digest["domain_projection_refs_and_hashes"],
        "workload_cost_budget_stop_and_recovery_limits": digest["workload_cost"],
        "authority_and_protected_permit_refs": digest["authority_and_protected_permit_refs"],
        "invalidation_triggers": sorted(MATERIAL_INVALIDATION_FIELDS),
        "revoked": False,
        "state": "approved",
        "invalidation_evidence": [],
    }
    approval_core["approval_id"] = sha256(approval_core)
    return approval_core


def validate_approval(approval: dict[str, Any]) -> dict[str, Any]:
    """Validate exact receipt shape and immutable issuance identity.

    Revocation changes state/evidence but deliberately retains the immutable
    issuance ID, so those fields are normalized only for the identity check.
    """

    if not isinstance(approval, dict) or set(approval) != APPROVAL_KEYS:
        raise GateError("approval fields mismatch")
    if approval["format"] != APPROVAL_FORMAT:
        raise GateError("wrong approval format")
    for field in (
        "approval_id",
        "authorized_user_event_ref",
        "issued_at",
        "task_id",
        "workflow_epoch",
        "digest_id",
    ):
        _nonempty_string(approval[field], f"approval.{field}")
    for field in (
        "approval_id",
        "digest_sha256",
        "plan_sha256",
        "scope_sha256",
        "execution_snapshot_sha256",
    ):
        _sha256_string(approval[field], f"approval.{field}")
    issued = _parse_time(approval["issued_at"], "approval.issued_at")
    expiry = approval["expires_at"]
    if expiry is not None and _parse_time(expiry, "approval.expires_at") <= issued:
        raise GateError("approval expires_at must follow issued_at")

    actions = approval["action_classes_and_stages"]
    if not isinstance(actions, list) or not actions:
        raise GateError("approval requires action classes and stages")
    for item in actions:
        if not isinstance(item, dict) or set(item) != {"action", "stage"}:
            raise GateError("approval action/stage fields mismatch")
        _nonempty_string(item["action"], "approval.action")
        _nonempty_string(item["stage"], "approval.stage")

    roots_effects = approval["exact_roots_and_effects"]
    if not isinstance(roots_effects, dict) or set(roots_effects) != {
        "allowed_roots",
        "effects",
    }:
        raise GateError("approval roots/effects fields mismatch")
    approval_roots = _string_list(
        roots_effects["allowed_roots"], "approval.allowed_roots", allow_empty=False
    )
    for index, root in enumerate(approval_roots):
        canonical_absolute_path(root, f"approval.allowed_roots[{index}]")
    _string_list(roots_effects["effects"], "approval.effects")

    references = approval["domain_projection_refs_and_hashes"]
    if not isinstance(references, list):
        raise GateError("approval domain projection references must be a list")
    normalized_references: list[bytes] = []
    for reference in references:
        if not isinstance(reference, dict) or set(reference) != {
            "projection_ref",
            "projection_sha256",
        }:
            raise GateError("approval domain projection reference fields mismatch")
        _nonempty_string(reference["projection_ref"], "approval.projection_ref")
        _sha256_string(reference["projection_sha256"], "approval.projection_sha256")
        normalized_references.append(canonical_bytes(reference))
    if len(normalized_references) != len(set(normalized_references)):
        raise GateError("approval domain projection references must be unique")
    if not isinstance(approval["workload_cost_budget_stop_and_recovery_limits"], dict):
        raise GateError("approval workload/cost limits must be an object")
    _string_list(
        approval["authority_and_protected_permit_refs"],
        "approval.authority_and_protected_permit_refs",
    )
    if approval["invalidation_triggers"] != sorted(MATERIAL_INVALIDATION_FIELDS):
        raise GateError("approval invalidation triggers mismatch")
    if not isinstance(approval["revoked"], bool):
        raise GateError("approval revoked flag must be boolean")
    if approval["state"] not in {"approved", "stale_reapproval_required"}:
        raise GateError("approval state is unsupported")
    evidence = approval["invalidation_evidence"]
    if not isinstance(evidence, list):
        raise GateError("approval invalidation evidence must be a list")
    for item in evidence:
        if not isinstance(item, dict) or set(item) != {"changed_fields", "evidence_ref"}:
            raise GateError("approval invalidation evidence fields mismatch")
        _string_list(item["changed_fields"], "approval.changed_fields", allow_empty=False)
        _nonempty_string(item["evidence_ref"], "approval.evidence_ref")
    if approval["state"] == "approved" and (approval["revoked"] or evidence):
        raise GateError("approved receipt cannot carry revocation state")
    if approval["state"] == "stale_reapproval_required" and (
        not approval["revoked"] or not evidence
    ):
        raise GateError("stale approval requires revocation evidence")

    issuance = copy.deepcopy(approval)
    observed_id = issuance.pop("approval_id")
    issuance["state"] = "approved"
    issuance["revoked"] = False
    issuance["invalidation_evidence"] = []
    if sha256(issuance) != observed_id:
        raise GateError("approval issuance integrity mismatch")
    return copy.deepcopy(approval)


def approval_matches_digest(
    approval: dict[str, Any],
    digest: dict[str, Any],
    *,
    now: str,
) -> bool:
    """Return whether one canonical, current approval matches the full digest."""

    try:
        hashes = validate_digest(digest)
        validate_approval(approval)
        current_time = _parse_time(now, "now")
        issued = _parse_time(approval["issued_at"], "approval.issued_at")
        expiry = approval["expires_at"]
    except GateError:
        return False
    if digest["self_grill_cycle_receipt"]["state"] != "digest_ready" or digest["questions"]:
        return False
    if approval["state"] != "approved" or approval["revoked"]:
        return False
    if current_time < issued or (
        expiry is not None and current_time >= _parse_time(expiry, "approval.expires_at")
    ):
        return False
    expected = {
        "task_id": digest["task_id"],
        "workflow_epoch": digest["workflow_epoch"],
        "digest_id": digest["digest_id"],
        "digest_sha256": hashes["digest_sha256"],
        "plan_sha256": hashes["plan_sha256"],
        "scope_sha256": hashes["scope_sha256"],
        "action_classes_and_stages": [
            {"action": node["action"], "stage": node["stage"]}
            for node in digest["plan"]
        ],
        "exact_roots_and_effects": {
            "allowed_roots": digest["scope"]["allowed_roots"],
            "effects": digest["scope"]["effects"],
        },
        "execution_snapshot_sha256": digest["execution_snapshot_sha256"],
        "domain_projection_refs_and_hashes": digest["domain_projection_refs_and_hashes"],
        "workload_cost_budget_stop_and_recovery_limits": digest["workload_cost"],
        "authority_and_protected_permit_refs": digest["authority_and_protected_permit_refs"],
        "invalidation_triggers": sorted(MATERIAL_INVALIDATION_FIELDS),
    }
    return all(approval[field] == value for field, value in expected.items())


def _parse_time(value: str, field: str) -> datetime:
    _nonempty_string(value, field)
    try:
        parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
    except ValueError as exc:
        raise GateError(f"{field} must be ISO-8601") from exc
    if parsed.tzinfo is None:
        raise GateError(f"{field} must include timezone")
    return parsed.astimezone(timezone.utc)


def approval_allows(
    approval: dict[str, Any],
    digest: dict[str, Any],
    action: dict[str, str],
    *,
    now: str,
) -> bool:
    if not approval_matches_digest(approval, digest, now=now):
        return False
    if not isinstance(action, dict) or set(action) != {"action", "stage", "root", "effect"}:
        return False
    if {"action": action["action"], "stage": action["stage"]} not in approval.get("action_classes_and_stages", []):
        return False
    if action["action"] not in digest["scope"]["actions"]:
        return False
    try:
        canonical_absolute_path(action["root"], "action.root")
    except GateError:
        return False
    if action["root"] not in digest["scope"]["allowed_roots"]:
        return False
    if action["effect"] not in digest["scope"]["effects"] and action["effect"] != "none":
        return False
    return True


def invalidate_approval(approval: dict[str, Any], changed_fields: list[str], *, evidence_ref: str) -> dict[str, Any]:
    if not isinstance(changed_fields, list) or any(not isinstance(item, str) for item in changed_fields):
        raise GateError("changed_fields must be a list of strings")
    affected = sorted(set(changed_fields) & MATERIAL_INVALIDATION_FIELDS)
    result = copy.deepcopy(approval)
    if affected:
        result["state"] = "stale_reapproval_required"
        result["revoked"] = True
        result.setdefault("invalidation_evidence", []).append(
            {"changed_fields": affected, "evidence_ref": _nonempty_string(evidence_ref, "evidence_ref")}
        )
    return result


def transition(state: str, event: str) -> str:
    if state not in STATES:
        raise GateError("unknown state")
    transitions = {
        ("discovery_only", "questions_found"): "awaiting_clarification",
        ("discovery_only", "closed_digest_shown"): "awaiting_approval",
        ("awaiting_clarification", "revised_closed_digest_shown"): "awaiting_approval",
        ("awaiting_approval", "matching_explicit_grant"): "approved",
        ("awaiting_approval", "denial"): "denied",
        ("approved", "material_change"): "stale_reapproval_required",
        ("approved", "all_terminal_joins_closed"): "complete",
        ("stale_reapproval_required", "revised_closed_digest_shown"): "awaiting_approval",
        ("stale_reapproval_required", "denial"): "denied",
    }
    try:
        return transitions[(state, event)]
    except KeyError as exc:
        raise GateError(f"invalid state transition: {state} + {event}") from exc


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=["validate-digest", "classify-action", "check-approval"])
    parser.add_argument("input", type=Path, help="JSON input path")
    args = parser.parse_args()
    payload = json.loads(args.input.read_text(encoding="utf-8"))
    if args.command == "validate-digest":
        print(json.dumps(validate_digest(payload), sort_keys=True))
    elif args.command == "classify-action":
        print(classify_action(payload))
    else:
        approval, digest, action, now = (
            payload["approval"], payload["digest"], payload["action"], payload["now"]
        )
        print("allow" if approval_allows(approval, digest, action, now=now) else "block")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
