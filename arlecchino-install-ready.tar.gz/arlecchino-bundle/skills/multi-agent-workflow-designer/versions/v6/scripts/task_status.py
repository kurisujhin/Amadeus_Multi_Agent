#!/usr/bin/env python3
"""Deterministic TASK_STATUS locator, renderer, and writer for Arlecchino V6.

The Markdown ledger is the tracking source of truth, but it is deliberately not
an authorization database.  Approval receipts, authenticated principals,
writer declarations, and same-task identity records are supplied by trusted
parent state and are never reconstructed by parsing Markdown.
"""

from __future__ import annotations

import argparse
import contextlib
import fcntl
import hashlib
import importlib.util
import json
import os
import re
import sys
import tempfile
import unicodedata
from dataclasses import dataclass, field, replace
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterable, Mapping, Optional, Sequence, Tuple


SCRIPT_DIR = Path(__file__).resolve().parent
TEMPLATE_PATH = SCRIPT_DIR.parent / "assets" / "TASK_STATUS.template.md"
STATUS_FILENAME = "TASK_STATUS.md"
_SHA256_RE = re.compile(r"^[0-9a-f]{64}$")
_SAFE_TASK_ID_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._-]{0,79}$")


def _load_pre_execution_gate() -> Any:
    """Load the sibling canonical gate even when this file is loaded by path."""

    module_name = "arlecchino_v6_pre_execution_gate"
    existing = sys.modules.get(module_name)
    if existing is not None:
        return existing
    module_path = SCRIPT_DIR / "pre_execution_gate.py"
    spec = importlib.util.spec_from_file_location(module_name, module_path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"cannot load canonical pre-execution gate: {module_path}")
    module = importlib.util.module_from_spec(spec)
    sys.modules[module_name] = module
    spec.loader.exec_module(module)
    return module


pre_execution_gate = _load_pre_execution_gate()


class TaskStatusError(RuntimeError):
    """Base class for fail-closed task-status errors."""


class UnsafeStatusPath(TaskStatusError):
    """The requested ledger path is ambiguous, unsafe, or unrelated."""


class ApprovalRequired(TaskStatusError):
    """A current canonical pre-execution approval is absent or mismatched."""


class WriterRejected(TaskStatusError):
    """The caller does not hold the authenticated current-writer lease."""


class SequenceRejected(TaskStatusError):
    """An update is stale, duplicated, or skips a sequence."""


class LifecycleRejected(TaskStatusError):
    """An update violates the ledger lifecycle."""


def _absolute(path: os.PathLike[str] | str, cwd: Path) -> Path:
    candidate = Path(path)
    if not candidate.is_absolute():
        candidate = cwd / candidate
    return Path(os.path.abspath(os.fspath(candidate)))


def _is_within(path: Path, root: Path) -> bool:
    try:
        path.relative_to(root)
        return True
    except ValueError:
        return False


def _json_clone(value: Any) -> Any:
    """Return a JSON-only deep copy and reject NaN/nonportable values."""

    try:
        encoded = json.dumps(value, allow_nan=False, sort_keys=True, ensure_ascii=False)
        return json.loads(encoded)
    except (TypeError, ValueError) as exc:
        raise LifecycleRejected(f"status data must be deterministic JSON: {exc}") from exc


def _canonical_time(value: str, label: str) -> str:
    if not isinstance(value, str) or not value.strip():
        raise LifecycleRejected(f"{label} requires an ISO-8601 timestamp")
    try:
        parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
    except ValueError as exc:
        raise LifecycleRejected(f"{label} must be ISO-8601") from exc
    if parsed.tzinfo is None:
        raise LifecycleRejected(f"{label} must include a timezone")
    return parsed.astimezone(timezone.utc).isoformat().replace("+00:00", "Z")


def _time_value(value: str, label: str) -> datetime:
    return datetime.fromisoformat(_canonical_time(value, label).replace("Z", "+00:00"))


def _string_list(
    value: Any,
    label: str,
    *,
    allow_empty: bool = True,
    unique: bool = True,
) -> list[str]:
    if not isinstance(value, list) or (not allow_empty and not value):
        suffix = " with at least one value" if not allow_empty else ""
        raise LifecycleRejected(f"{label} must be a list{suffix}")
    if any(not isinstance(item, str) or not item.strip() for item in value):
        raise LifecycleRejected(f"{label} must contain nonempty strings")
    if unique and len(value) != len(set(value)):
        raise LifecycleRejected(f"{label} must not contain duplicates")
    return value


def _exact_keys(value: Any, keys: set[str], label: str) -> dict[str, Any]:
    if not isinstance(value, dict) or set(value) != keys:
        raise LifecycleRejected(f"{label} fields mismatch")
    return value


def stable_task_id(task_id: str) -> str:
    """Return a stable path component without permitting alias collisions."""

    normalized = unicodedata.normalize("NFKC", task_id).strip()
    if _SAFE_TASK_ID_RE.fullmatch(normalized) and normalized not in {".", ".."}:
        return normalized
    slug = re.sub(r"[^A-Za-z0-9._-]+", "-", normalized).strip("-._") or "task"
    slug = slug[:48].rstrip("-._") or "task"
    digest = hashlib.sha256(task_id.encode("utf-8")).hexdigest()[:12]
    return f"{slug}--{digest}"


@dataclass(frozen=True)
class TaskIdentity:
    """Stable task identity; workflow epochs deliberately are not identity."""

    task_id: str
    identity_digest: str

    def validate(self) -> None:
        if not isinstance(self.task_id, str) or not self.task_id.strip():
            raise UnsafeStatusPath("task identity requires a nonempty task_id")
        if not _SHA256_RE.fullmatch(self.identity_digest):
            raise UnsafeStatusPath("task identity_digest must be lowercase SHA-256")


@dataclass(frozen=True)
class ExistingLedger:
    """Stable identity record from trusted parent state, never Markdown."""

    path: Path
    task_id: str
    identity_digest: str
    registry_verified: bool = False

    def matches(self, identity: TaskIdentity) -> bool:
        return (
            self.registry_verified
            and self.task_id == identity.task_id
            and self.identity_digest == identity.identity_digest
        )


@dataclass(frozen=True)
class PathPolicy:
    """Environment boundaries used by the fail-closed locator."""

    home_roots: Tuple[Path, ...] = field(default_factory=tuple)
    temp_roots: Tuple[Path, ...] = field(default_factory=tuple)
    skill_install_roots: Tuple[Path, ...] = field(default_factory=tuple)
    additional_forbidden_roots: Tuple[Path, ...] = field(default_factory=tuple)
    minimum_owner_depth: int = 3

    @classmethod
    def system_default(cls) -> "PathPolicy":
        home = Path.home().resolve()
        return cls(
            home_roots=(home,),
            temp_roots=(Path(tempfile.gettempdir()).resolve(),),
            skill_install_roots=(
                (home / ".codex" / "skills").resolve(),
                (home / ".agents" / "skills").resolve(),
            ),
        )


@dataclass(frozen=True)
class LocatorResult:
    path: Path
    reason: str
    canonical_root: Path
    task_namespace: Optional[str]
    reused: bool


def discover_repository_root(cwd: os.PathLike[str] | str) -> Path:
    """Discover the nearest Git worktree root (`.git` directory or file)."""

    cursor = Path(cwd).resolve()
    if not cursor.is_dir():
        cursor = cursor.parent
    while True:
        marker = cursor / ".git"
        if marker.is_symlink():
            raise UnsafeStatusPath(f"symlinked Git marker is unsafe: {marker}")
        if marker.is_dir() or marker.is_file():
            return cursor
        if cursor.parent == cursor:
            raise UnsafeStatusPath(f"no canonical Git worktree found from {cwd}")
        cursor = cursor.parent


class StatusLocator:
    """Select one safe ledger path without touching the filesystem."""

    def __init__(self, policy: Optional[PathPolicy] = None):
        self.policy = policy or PathPolicy.system_default()

    def _normal_root(self, value: os.PathLike[str] | str, cwd: Path) -> Path:
        lexical = _absolute(value, cwd)
        if lexical.is_symlink():
            raise UnsafeStatusPath(f"owner root is a symlink: {lexical}")
        resolved = lexical.resolve()
        if not resolved.is_dir():
            raise UnsafeStatusPath(f"owner root is not a directory: {resolved}")
        return resolved

    def _home_roots(self) -> Tuple[Path, ...]:
        return tuple(Path(root).resolve() for root in self.policy.home_roots)

    def _subtree_forbidden_roots(self) -> Tuple[Path, ...]:
        roots = (
            self.policy.temp_roots
            + self.policy.skill_install_roots
            + self.policy.additional_forbidden_roots
        )
        return tuple(Path(root).resolve() for root in roots)

    def _assert_owner_safe(self, root: Path) -> None:
        if root == Path(root.anchor) or len(root.parts) < self.policy.minimum_owner_depth:
            raise UnsafeStatusPath(f"owner root is too broad: {root}")
        if root in self._home_roots():
            raise UnsafeStatusPath(f"home root itself is too broad: {root}")
        for forbidden in self._subtree_forbidden_roots():
            if _is_within(root, forbidden):
                raise UnsafeStatusPath(f"owner root is inside forbidden area {forbidden}: {root}")

    def _assert_no_symlink(self, candidate: Path, boundary: Path) -> None:
        if not _is_within(candidate, boundary):
            raise UnsafeStatusPath(f"path escapes owner root {boundary}: {candidate}")
        cursor = boundary
        if cursor.is_symlink():
            raise UnsafeStatusPath(f"owner root is a symlink: {cursor}")
        for part in candidate.relative_to(boundary).parts:
            cursor = cursor / part
            if cursor.is_symlink():
                raise UnsafeStatusPath(f"symlink component is unsafe: {cursor}")

    def _validate_candidate(
        self,
        candidate: Path,
        allowed_roots: Sequence[Path],
        *,
        allow_existing: bool,
    ) -> Path:
        candidate = _absolute(candidate, Path.cwd())
        if candidate.name != STATUS_FILENAME:
            raise UnsafeStatusPath(f"ledger must be named {STATUS_FILENAME}: {candidate}")
        containing = [root for root in allowed_roots if _is_within(candidate, root)]
        if not containing:
            raise UnsafeStatusPath(f"ledger is outside all task-owned roots: {candidate}")
        boundary = max(containing, key=lambda path: len(path.parts))
        self._assert_no_symlink(candidate, boundary)
        for forbidden in self._subtree_forbidden_roots():
            if _is_within(candidate, forbidden):
                raise UnsafeStatusPath(f"ledger is inside forbidden area {forbidden}: {candidate}")
        if candidate.parent == Path(candidate.anchor):
            raise UnsafeStatusPath(f"ledger path is too broad: {candidate}")
        if candidate.exists():
            if candidate.is_symlink() or not candidate.is_file():
                raise UnsafeStatusPath(f"existing ledger target is not a regular file: {candidate}")
            if not allow_existing:
                raise UnsafeStatusPath(f"refusing unrelated overwrite: {candidate}")
        return candidate

    @staticmethod
    def _matching_records(
        identity: TaskIdentity, existing_ledgers: Sequence[ExistingLedger]
    ) -> Tuple[ExistingLedger, ...]:
        return tuple(record for record in existing_ledgers if record.matches(identity))

    def _namespace_candidate(
        self,
        root: Path,
        identity: TaskIdentity,
        allowed_roots: Sequence[Path],
    ) -> Path:
        namespace = stable_task_id(identity.task_id)
        base = root / ".codex" / "tasks" / namespace / STATUS_FILENAME
        if not base.exists():
            return self._validate_candidate(base, allowed_roots, allow_existing=False)
        fallback = (
            root
            / ".codex"
            / "tasks"
            / f"{namespace}--{identity.identity_digest[:12]}"
            / STATUS_FILENAME
        )
        if fallback.exists():
            raise UnsafeStatusPath(
                f"both stable task namespaces collide with unrelated ledgers: {base}, {fallback}"
            )
        return self._validate_candidate(fallback, allowed_roots, allow_existing=False)

    def locate(
        self,
        identity: TaskIdentity,
        *,
        cwd: os.PathLike[str] | str,
        repository_roots: Sequence[os.PathLike[str] | str] = (),
        coordinating_workspace: Optional[os.PathLike[str] | str] = None,
        explicit_path: Optional[os.PathLike[str] | str] = None,
        explicit_allowed_roots: Sequence[os.PathLike[str] | str] = (),
        existing_ledgers: Sequence[ExistingLedger] = (),
        concurrent: bool = False,
    ) -> LocatorResult:
        identity.validate()
        cwd_path = Path(cwd).resolve()
        roots = list(repository_roots)
        if not roots:
            roots = [discover_repository_root(cwd_path)]
        canonical_roots = tuple(
            sorted(
                {self._normal_root(root, cwd_path) for root in roots},
                key=lambda path: os.fspath(path),
            )
        )
        for root in canonical_roots:
            self._assert_owner_safe(root)

        workspace: Optional[Path] = None
        if coordinating_workspace is not None:
            workspace = self._normal_root(coordinating_workspace, cwd_path)
            self._assert_owner_safe(workspace)
        approved_roots = tuple(
            self._normal_root(root, cwd_path) for root in explicit_allowed_roots
        )
        for root in approved_roots:
            self._assert_owner_safe(root)

        allowed_roots = tuple(dict.fromkeys(canonical_roots + approved_roots + ((workspace,) if workspace else ())))
        matches = self._matching_records(identity, existing_ledgers)

        # Priority 1: a valid explicit user/repository path.
        if explicit_path is not None:
            explicit = _absolute(explicit_path, cwd_path)
            matching_explicit = [
                record for record in matches if _absolute(record.path, cwd_path) == explicit
            ]
            if explicit.exists() and len(matching_explicit) != 1:
                raise UnsafeStatusPath(
                    f"explicit path exists without one trusted same-task identity: {explicit}"
                )
            path = self._validate_candidate(
                explicit, allowed_roots, allow_existing=bool(matching_explicit)
            )
            containing = max(
                (root for root in allowed_roots if _is_within(path, root)),
                key=lambda item: len(item.parts),
            )
            return LocatorResult(
                path=path,
                reason="explicit_valid_path",
                canonical_root=containing,
                task_namespace=None,
                reused=bool(matching_explicit),
            )

        # Priority 2: one trusted same-task record. Physical Markdown is never
        # inspected for identity and unregistered decoys are ignored.
        if len(matches) > 1:
            raise UnsafeStatusPath("multiple trusted same-task ledgers are ambiguous")
        if len(matches) == 1:
            record_path = _absolute(matches[0].path, cwd_path)
            if not record_path.exists():
                raise UnsafeStatusPath(f"trusted same-task record is stale: {record_path}")
            path = self._validate_candidate(record_path, allowed_roots, allow_existing=True)
            containing = max(
                (root for root in allowed_roots if _is_within(path, root)),
                key=lambda item: len(item.parts),
            )
            return LocatorResult(
                path=path,
                reason="trusted_same_task_ledger",
                canonical_root=containing,
                task_namespace=path.parent.name if ".codex" in path.parts else None,
                reused=True,
            )

        # Priority 3/4: a single canonical worktree, with namespacing for a
        # concurrent task or a root collision.
        if len(canonical_roots) == 1:
            root = canonical_roots[0]
            root_candidate = root / STATUS_FILENAME
            if not concurrent and not root_candidate.exists():
                path = self._validate_candidate(root_candidate, allowed_roots, allow_existing=False)
                return LocatorResult(path, "single_canonical_repo", root, None, False)
            path = self._namespace_candidate(root, identity, allowed_roots)
            reason = "concurrent_task_namespace" if concurrent else "root_collision_namespace"
            return LocatorResult(path, reason, root, path.parent.name, False)

        # Priority 5: multiple repositories use their exact narrowest common,
        # writable coordinating workspace. A broader caller-selected directory
        # is rejected instead of silently scattering task state.
        common = Path(os.path.commonpath([os.fspath(root) for root in canonical_roots])).resolve()
        self._assert_owner_safe(common)
        if workspace is not None and workspace != common:
            raise UnsafeStatusPath(
                f"coordinating workspace is not the narrowest common root: {workspace} != {common}"
            )
        owner = workspace or common
        if not owner.is_dir() or not os.access(owner, os.W_OK):
            raise UnsafeStatusPath(f"narrowest coordinating workspace is not writable: {owner}")
        multi_allowed = tuple(dict.fromkeys(allowed_roots + (owner,)))
        path = self._namespace_candidate(owner, identity, multi_allowed)
        return LocatorResult(path, "multi_repo_task_namespace", owner, path.parent.name, False)


@dataclass(frozen=True)
class FirstMutationGuard:
    approval_id: str
    prior_post_approval_mutations: int
    mutation_name: str = STATUS_FILENAME
    verified_by_host: bool = False

    def validate(self, canonical_approval: Mapping[str, Any]) -> None:
        if not self.verified_by_host:
            raise ApprovalRequired("first-mutation guard is not host-verified")
        if not isinstance(canonical_approval, Mapping):
            raise ApprovalRequired("first-mutation guard requires a canonical approval object")
        if self.approval_id != canonical_approval.get("approval_id"):
            raise ApprovalRequired("first-mutation guard is for a different canonical approval")
        if self.prior_post_approval_mutations != 0 or self.mutation_name != STATUS_FILENAME:
            raise ApprovalRequired(f"{STATUS_FILENAME} is not attested as the first mutation")


@dataclass(frozen=True)
class AuthenticatedPrincipal:
    principal_id: str
    role: str
    authn_subject: str
    verified_by_host: bool


@dataclass(frozen=True)
class WriterAuthority:
    """One authenticated current-writer lease over two declared candidates."""

    coordinator_id: str
    coordinator_subject: str
    observer_id: Optional[str] = None
    observer_subject: Optional[str] = None
    current_writer_role: str = "coordinator"
    lease_id: str = ""

    def validate(self) -> None:
        if not self.coordinator_id or not self.coordinator_subject or not self.lease_id:
            raise WriterRejected("writer authority requires coordinator identity and lease_id")
        if (self.observer_id is None) != (self.observer_subject is None):
            raise WriterRejected("observer identity and subject must be declared together")
        if self.current_writer_role not in {"coordinator", "observer"}:
            raise WriterRejected("current writer role must be coordinator or observer")
        if self.current_writer_role == "observer" and self.observer_id is None:
            raise WriterRejected("observer cannot hold a lease without a declared observer")

    @property
    def current_writer_id(self) -> str:
        self.validate()
        if self.current_writer_role == "coordinator":
            return self.coordinator_id
        assert self.observer_id is not None
        return self.observer_id

    @property
    def current_writer_subject(self) -> str:
        self.validate()
        if self.current_writer_role == "coordinator":
            return self.coordinator_subject
        assert self.observer_subject is not None
        return self.observer_subject

    def authorize(self, principal: AuthenticatedPrincipal) -> None:
        self.validate()
        if not principal.verified_by_host or not principal.authn_subject:
            raise WriterRejected("writer identity is not host-authenticated")
        if (
            principal.role != self.current_writer_role
            or principal.principal_id != self.current_writer_id
            or principal.authn_subject != self.current_writer_subject
        ):
            raise WriterRejected("caller does not hold the authenticated current-writer lease")

    def transferred(self, to_role: str, new_lease_id: str) -> "WriterAuthority":
        candidate = replace(self, current_writer_role=to_role, lease_id=new_lease_id)
        candidate.validate()
        if candidate.current_writer_role == self.current_writer_role:
            raise WriterRejected("writer transfer must change the current writer role")
        return candidate


CONTRACT_KEYS = {
    "outcome",
    "scope",
    "exclusions",
    "clause_map",
    "plan",
    "outputs",
    "monitoring_verification_cleanup",
    "wait_policy",
    "change_mode",
    "effect_authorities",
    "terminal_requirements",
    "status_path",
}
CHANGE_MODES = {"N/A", "diff_only", "verified_checkpoint", "atomic_delivery"}
SELF_GRILL_KEYS = {
    "cycle_id",
    "input_snapshot_sha256",
    "state",
    "completed_rounds",
    "circuit_breaker_triggered",
    "impact_summary",
    "design_deltas",
    "question_refs",
    "blocker_refs",
}
TERMINAL_STATES = {"complete", "partial", "blocked", "withheld", "cancelled"}
OVERALL_STATES = {"active", "blocked", "awaiting_reapproval"} | TERMINAL_STATES
DECISION_KINDS = {
    "decision",
    "replan",
    "approval_invalidation",
    "reapproval_refresh",
    "writer_transfer",
}
TERMINAL_MILESTONE_FIELDS = (
    "monitoring",
    "rollback_recovery",
    "report",
    "teardown",
    "cleanup",
)
TERMINAL_VERIFICATION_ID = "terminal-verification"


@dataclass(frozen=True)
class TaskStatusState:
    task_id: str
    identity_digest: str
    title: str
    epoch: str
    canonical_root: str
    ledger_path: str
    sequence: int
    coordinator_id: str
    observer_id: Optional[str]
    current_writer_role: str
    current_writer_id: str
    writer_lease_id: str
    created_at: str
    updated_at: str
    overall_state: str
    approval_id: str
    approval_issued_at: str
    approval_expires_at: Optional[str]
    digest_id: str
    digest_sha256: str
    plan_sha256: str
    scope_sha256: str
    approval_state: str
    contract: Mapping[str, Any]
    self_grill: Mapping[str, Any]
    domain_gates: Tuple[Mapping[str, Any], ...] = ()
    milestones: Tuple[Mapping[str, Any], ...] = ()
    execution: Tuple[Mapping[str, Any], ...] = ()
    decisions: Tuple[Mapping[str, Any], ...] = ()
    blockers: Tuple[Mapping[str, Any], ...] = ()
    verification: Tuple[Mapping[str, Any], ...] = ()
    terminal: Optional[Mapping[str, Any]] = None
    history: Tuple[Mapping[str, Any], ...] = ()


@dataclass(frozen=True)
class StatusUpdate:
    sequence: int
    kind: str
    payload: Mapping[str, Any]
    observed_at: str
    source_packet_id: Optional[str] = None
    canonical_digest: Optional[Mapping[str, Any]] = None
    canonical_approval: Optional[Mapping[str, Any]] = None


@dataclass(frozen=True)
class StatusDeltaPacket:
    packet_id: str
    task_id: str
    epoch: str
    base_sequence: int
    author_id: str
    author_role: str
    kind: str
    payload: Mapping[str, Any]
    observed_at: str


def _validate_canonical_binding(
    identity: TaskIdentity,
    path: Path,
    canonical_root: Path,
    canonical_digest: Mapping[str, Any],
    canonical_approval: Mapping[str, Any],
    *,
    now: str,
    expected_writer_role: str,
) -> dict[str, str]:
    """Validate the sole approval chain and its exact status-ledger binding."""

    identity.validate()
    digest_value = _json_clone(canonical_digest)
    approval_value = _json_clone(canonical_approval)
    canonical_now = _canonical_time(now, "approval observation time")
    try:
        hashes = pre_execution_gate.validate_digest(digest_value)
        pre_execution_gate.validate_approval(approval_value)
        current = pre_execution_gate.approval_matches_digest(
            approval_value, digest_value, now=canonical_now
        )
    except (pre_execution_gate.GateError, TypeError, ValueError) as exc:
        raise ApprovalRequired(f"canonical pre-execution approval is invalid: {exc}") from exc
    if not current:
        raise ApprovalRequired("canonical approval is stale, expired, or mismatched")
    if digest_value["task_id"] != identity.task_id:
        raise ApprovalRequired("canonical approval belongs to another stable task")
    status = digest_value["task_status"]
    declared_root = Path(status["canonical_root"])
    declared_path = Path(status["path"])
    try:
        pre_execution_gate.canonical_absolute_path(
            os.fspath(canonical_root), "location.canonical_root"
        )
        pre_execution_gate.canonical_absolute_path(
            os.fspath(path), "location.path"
        )
    except pre_execution_gate.GateError as exc:
        raise ApprovalRequired(f"status location is not canonical: {exc}") from exc
    if declared_root != canonical_root:
        raise ApprovalRequired("canonical digest is bound to another canonical root")
    if not declared_path.is_absolute() or _absolute(declared_path, Path.cwd()) != Path(path):
        raise ApprovalRequired("canonical digest is bound to another TASK_STATUS path")
    if not _is_within(Path(path), canonical_root):
        raise ApprovalRequired("TASK_STATUS path lies outside its canonical root")
    if not any(
        pre_execution_gate.path_is_within(
            os.fspath(canonical_root), approved_root
        )
        for approved_root in digest_value["scope"]["allowed_roots"]
    ):
        raise ApprovalRequired("TASK_STATUS canonical root lies outside approved scope")
    if status["current_writer"] != expected_writer_role:
        raise ApprovalRequired("canonical digest is bound to another current writer")
    return hashes


def validate_canonical_approval(
    identity: TaskIdentity,
    path: Path,
    canonical_root: Path,
    canonical_digest: Mapping[str, Any],
    canonical_approval: Mapping[str, Any],
    *,
    now: str,
    expected_writer_role: str,
) -> dict[str, str]:
    """Public wrapper for controller adapters and integration checks."""

    return _validate_canonical_binding(
        identity,
        Path(path),
        Path(canonical_root),
        canonical_digest,
        canonical_approval,
        now=now,
        expected_writer_role=expected_writer_role,
    )


def _output_milestone_id(output: str) -> str:
    digest = hashlib.sha256(
        json.dumps(output, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
    ).hexdigest()
    return f"output-{digest}"


def _derived_terminal_requirements(digest_value: Mapping[str, Any]) -> list[str]:
    requirements = [
        *(f"execution:{node['node_id']}" for node in digest_value["plan"]),
        *(f"milestone:terminal-{field.replace('_', '-')}" for field in TERMINAL_MILESTONE_FIELDS),
        *(f"milestone:{_output_milestone_id(output)}" for output in digest_value["outputs"]),
        f"verification:{TERMINAL_VERIFICATION_ID}",
    ]
    if len(requirements) != len(set(requirements)):
        raise LifecycleRejected("derived terminal requirements collide")
    return sorted(requirements)


def terminal_requirements_from_digest(
    canonical_digest: Mapping[str, Any],
) -> list[str]:
    """Derive every nontrivial terminal join from the approved digest."""

    digest_value = _json_clone(canonical_digest)
    try:
        pre_execution_gate.validate_digest(digest_value)
    except pre_execution_gate.GateError as exc:
        raise ApprovalRequired(
            f"cannot derive terminal requirements from invalid digest: {exc}"
        ) from exc
    return _derived_terminal_requirements(digest_value)


def _required_status_entries(
    digest_value: Mapping[str, Any],
    *,
    coordinator_id: str,
    sequence: int,
) -> tuple[list[Mapping[str, Any]], list[Mapping[str, Any]], list[Mapping[str, Any]]]:
    """Materialize the non-vacuous digest-derived terminal catalogs."""

    evidence_prefix = (
        "approved digest" if sequence == 0 else "approved replan digest"
    )
    milestones = [
        {
            "id": f"terminal-{field.replace('_', '-')}",
            "owner": coordinator_id,
            "state": "pending",
            "evidence": [f"{evidence_prefix}:{digest_value['digest_id']}"],
            "next": digest_value["monitoring_verification_cleanup"][field],
            "updated_sequence": sequence,
        }
        for field in TERMINAL_MILESTONE_FIELDS
    ] + [
        {
            "id": _output_milestone_id(output),
            "owner": coordinator_id,
            "state": "pending",
            "evidence": [f"approved output:{output}"],
            "next": f"produce and record {output}",
            "updated_sequence": sequence,
        }
        for output in digest_value["outputs"]
    ]
    execution = [
        {
            "id": node["node_id"],
            "owner": node["owner"],
            "state": "planned",
            "evidence": [f"{evidence_prefix}:{digest_value['digest_id']}:node:{node['node_id']}"],
            "next": f"{node['stage']}:{node['action']}",
            "updated_sequence": sequence,
        }
        for node in digest_value["plan"]
    ]
    verification = [{
        "id": TERMINAL_VERIFICATION_ID,
        "owner": coordinator_id,
        "state": "pending",
        "evidence": [f"approved verification:{digest_value['digest_id']}"],
        "next": digest_value["monitoring_verification_cleanup"]["verification"],
        "updated_sequence": sequence,
    }]
    return milestones, execution, verification


def contract_from_digest(
    canonical_digest: Mapping[str, Any],
    *,
    change_mode: str,
    terminal_requirements: Optional[Sequence[str]] = None,
) -> Mapping[str, Any]:
    """Derive the required status contract from the approved digest."""

    digest_value = _json_clone(canonical_digest)
    try:
        pre_execution_gate.validate_digest(digest_value)
    except pre_execution_gate.GateError as exc:
        raise ApprovalRequired(f"cannot derive contract from invalid digest: {exc}") from exc
    if change_mode not in CHANGE_MODES:
        raise LifecycleRejected(f"unsupported change_mode: {change_mode}")
    requirements = _derived_terminal_requirements(digest_value)
    if terminal_requirements is not None:
        supplied = list(terminal_requirements)
        _string_list(supplied, "terminal_requirements", allow_empty=False)
        if supplied != requirements:
            raise LifecycleRejected(
                "terminal_requirements must equal the deterministic digest-derived set"
            )
    contract = {
        "outcome": digest_value["outcome"],
        "scope": digest_value["scope"],
        "exclusions": digest_value["exclusions"],
        "clause_map": digest_value["clause_map"],
        "plan": digest_value["plan"],
        "outputs": digest_value["outputs"],
        "monitoring_verification_cleanup": digest_value[
            "monitoring_verification_cleanup"
        ],
        "wait_policy": digest_value["workload_cost"]["route_and_wait_policy"],
        "change_mode": change_mode,
        "effect_authorities": {
            "effects": digest_value["scope"]["effects"],
            "authority_and_protected_permit_refs": digest_value[
                "authority_and_protected_permit_refs"
            ],
        },
        "terminal_requirements": requirements,
        "status_path": digest_value["task_status"]["path"],
    }
    _validate_contract(contract)
    return _json_clone(contract)


def self_grill_summary_from_digest(
    canonical_digest: Mapping[str, Any],
) -> Mapping[str, Any]:
    """Project a compact typed receipt summary without private reasoning."""

    digest_value = _json_clone(canonical_digest)
    try:
        pre_execution_gate.validate_digest(digest_value)
    except pre_execution_gate.GateError as exc:
        raise ApprovalRequired(f"cannot summarize invalid self-grill receipt: {exc}") from exc
    cycle = digest_value["self_grill_cycle_receipt"]
    impacts: list[dict[str, Any]] = []
    design_deltas: list[str] = []
    question_refs: list[str] = []
    blocker_refs: list[str] = []
    for round_receipt in cycle["rounds"]:
        dispositions = round_receipt["impact_dispositions_by_dimension"]
        impacts.append(
            {
                "round_id": round_receipt["round_id"],
                "closure_state": round_receipt["closure_state"],
                "material_dimensions": sorted(
                    key for key, value in dispositions.items() if value == "material_delta"
                ),
                "contradiction_dimensions": sorted(
                    key for key, value in dispositions.items() if value == "contradiction"
                ),
                "unresolved_dimensions": sorted(
                    key for key, value in dispositions.items() if value == "unresolved"
                ),
            }
        )
        design_deltas.extend(round_receipt["design_delta"])
        question_refs.extend(round_receipt["unavailable_user_owned_questions"])
        blocker_refs.extend(round_receipt["blocked_actions"])

    def unique(values: Sequence[str]) -> list[str]:
        return list(dict.fromkeys(values))

    summary = {
        "cycle_id": cycle["cycle_id"],
        "input_snapshot_sha256": cycle["input_snapshot_sha256"],
        "state": cycle["state"],
        "completed_rounds": len(cycle["rounds"]),
        "circuit_breaker_triggered": cycle["circuit_breaker_triggered"],
        "impact_summary": impacts,
        "design_deltas": unique(design_deltas),
        "question_refs": unique(question_refs),
        "blocker_refs": unique(blocker_refs),
    }
    _validate_self_grill(summary)
    return _json_clone(summary)


def _validate_contract(contract: Mapping[str, Any]) -> None:
    value = _exact_keys(_json_clone(contract), CONTRACT_KEYS, "contract")
    _required_string(value, "outcome", "contract")
    scope = _exact_keys(
        value["scope"], {"allowed_roots", "actions", "effects"}, "contract.scope"
    )
    _string_list(scope["allowed_roots"], "contract.scope.allowed_roots", allow_empty=False)
    _string_list(scope["actions"], "contract.scope.actions", allow_empty=False)
    _string_list(scope["effects"], "contract.scope.effects")
    _string_list(value["exclusions"], "contract.exclusions")
    clauses = value["clause_map"]
    if not isinstance(clauses, list) or not clauses:
        raise LifecycleRejected("contract.clause_map must be nonempty")
    for clause in clauses:
        exact = _exact_keys(
            clause, {"clause", "attaches_to"}, "contract.clause_map item"
        )
        _required_string(exact, "clause", "contract.clause_map item")
        _required_string(exact, "attaches_to", "contract.clause_map item")
    plan = value["plan"]
    if not isinstance(plan, list) or not plan:
        raise LifecycleRejected("contract.plan must be nonempty")
    for node in plan:
        exact = _exact_keys(
            node,
            {"node_id", "owner", "action", "stage", "dependencies"},
            "contract.plan node",
        )
        for key in ("node_id", "owner", "action", "stage"):
            _required_string(exact, key, "contract.plan node")
        _string_list(exact["dependencies"], "contract.plan.dependencies")
    _string_list(value["outputs"], "contract.outputs", allow_empty=False)
    terminal = _exact_keys(
        value["monitoring_verification_cleanup"],
        {"monitoring", "verification", "rollback_recovery", "report", "teardown", "cleanup"},
        "contract.monitoring_verification_cleanup",
    )
    for key in terminal:
        _required_string(terminal, key, "contract.monitoring_verification_cleanup")
    _required_string(value, "wait_policy", "contract")
    if value["change_mode"] not in CHANGE_MODES:
        raise LifecycleRejected("contract.change_mode is unsupported")
    authorities = _exact_keys(
        value["effect_authorities"],
        {"effects", "authority_and_protected_permit_refs"},
        "contract.effect_authorities",
    )
    _string_list(authorities["effects"], "contract.effect_authorities.effects")
    _string_list(
        authorities["authority_and_protected_permit_refs"],
        "contract.effect_authorities.authority_and_protected_permit_refs",
    )
    _string_list(
        value["terminal_requirements"],
        "contract.terminal_requirements",
        allow_empty=False,
    )
    expected_requirements = _derived_terminal_requirements(value)
    if value["terminal_requirements"] != expected_requirements:
        raise LifecycleRejected(
            "contract terminal requirements are not deterministically derived"
        )
    supported_requirements = {
        "milestone",
        "execution",
        "verification",
        "domain_gate",
        "blocker",
    }
    for requirement in value["terminal_requirements"]:
        try:
            kind, item_id = requirement.split(":", 1)
        except ValueError as exc:
            raise LifecycleRejected(
                f"contract terminal requirement is malformed: {requirement}"
            ) from exc
        if kind not in supported_requirements or not item_id.strip():
            raise LifecycleRejected(
                f"contract terminal requirement is unsupported: {requirement}"
            )
    status_path = Path(_required_string(value, "status_path", "contract"))
    if not status_path.is_absolute() or status_path.name != STATUS_FILENAME:
        raise LifecycleRejected(
            "contract.status_path must be an absolute TASK_STATUS.md path"
        )


def _validate_self_grill(summary: Mapping[str, Any]) -> None:
    value = _exact_keys(_json_clone(summary), SELF_GRILL_KEYS, "self_grill summary")
    _required_string(value, "cycle_id", "self_grill summary")
    if not _SHA256_RE.fullmatch(value.get("input_snapshot_sha256", "")):
        raise LifecycleRejected("self_grill input snapshot must be lowercase SHA-256")
    if value.get("state") not in {"digest_ready", "digest_blocked", "circuit_breaker"}:
        raise LifecycleRejected("self_grill summary is not terminal")
    rounds = value.get("completed_rounds")
    impacts = value.get("impact_summary")
    if not isinstance(rounds, int) or not 1 <= rounds <= 3:
        raise LifecycleRejected("self_grill completed_rounds must be between one and three")
    if not isinstance(impacts, list) or len(impacts) != rounds:
        raise LifecycleRejected("self_grill impact summary must cover every round")
    for index, impact in enumerate(impacts, 1):
        exact = _exact_keys(
            impact,
            {
                "round_id",
                "closure_state",
                "material_dimensions",
                "contradiction_dimensions",
                "unresolved_dimensions",
            },
            "self_grill impact",
        )
        if exact["round_id"] != index or exact["closure_state"] not in {
            "open",
            "stable",
            "blocked",
        }:
            raise LifecycleRejected("self_grill impact sequence or closure is invalid")
        for field_name in (
            "material_dimensions",
            "contradiction_dimensions",
            "unresolved_dimensions",
        ):
            _string_list(exact[field_name], f"self_grill impact.{field_name}")
    if not isinstance(value.get("circuit_breaker_triggered"), bool):
        raise LifecycleRejected("self_grill circuit-breaker flag must be boolean")
    if (value["state"] == "circuit_breaker") != value["circuit_breaker_triggered"]:
        raise LifecycleRejected("self_grill circuit-breaker state and flag disagree")
    for field_name in ("design_deltas", "question_refs", "blocker_refs"):
        _string_list(value[field_name], f"self_grill.{field_name}")


def make_initial_state(
    identity: TaskIdentity,
    location: LocatorResult,
    canonical_digest: Mapping[str, Any],
    canonical_approval: Mapping[str, Any],
    authority: WriterAuthority,
    *,
    title: str,
    now: str,
    change_mode: str,
    terminal_requirements: Optional[Sequence[str]] = None,
    domain_gates: Sequence[Mapping[str, Any]] = (),
    milestones: Sequence[Mapping[str, Any]] = (),
    execution: Sequence[Mapping[str, Any]] = (),
    verification: Sequence[Mapping[str, Any]] = (),
) -> TaskStatusState:
    """Build canonical state without writing the ledger."""

    authority.validate()
    observed_at = _canonical_time(now, "initial status time")
    hashes = _validate_canonical_binding(
        identity,
        location.path,
        location.canonical_root,
        canonical_digest,
        canonical_approval,
        now=observed_at,
        expected_writer_role=authority.current_writer_role,
    )
    digest_value = _json_clone(canonical_digest)
    approval_value = _json_clone(canonical_approval)
    (
        required_milestones,
        required_execution,
        required_verification,
    ) = _required_status_entries(
        digest_value,
        coordinator_id=authority.coordinator_id,
        sequence=0,
    )
    state = TaskStatusState(
        task_id=identity.task_id,
        identity_digest=identity.identity_digest,
        title=title,
        epoch=digest_value["workflow_epoch"],
        canonical_root=os.fspath(location.canonical_root),
        ledger_path=os.fspath(location.path),
        sequence=0,
        coordinator_id=authority.coordinator_id,
        observer_id=authority.observer_id,
        current_writer_role=authority.current_writer_role,
        current_writer_id=authority.current_writer_id,
        writer_lease_id=authority.lease_id,
        created_at=observed_at,
        updated_at=observed_at,
        overall_state="active",
        approval_id=approval_value["approval_id"],
        approval_issued_at=approval_value["issued_at"],
        approval_expires_at=approval_value["expires_at"],
        digest_id=digest_value["digest_id"],
        digest_sha256=hashes["digest_sha256"],
        plan_sha256=hashes["plan_sha256"],
        scope_sha256=hashes["scope_sha256"],
        approval_state="approved",
        contract=contract_from_digest(
            digest_value,
            change_mode=change_mode,
            terminal_requirements=terminal_requirements,
        ),
        self_grill=self_grill_summary_from_digest(digest_value),
        domain_gates=tuple(
            _initial_entry(item, "domain gate") for item in domain_gates
        ),
        milestones=_merge_initial_entries(
            milestones, required_milestones, "milestone"
        ),
        execution=_merge_initial_entries(
            execution, required_execution, "execution"
        ),
        verification=_merge_initial_entries(
            verification, required_verification, "verification"
        ),
    )
    validate_status_state(state)
    return state


def _required_string(item: Mapping[str, Any], key: str, label: str) -> str:
    value = item.get(key)
    if not isinstance(value, str) or not value.strip():
        raise LifecycleRejected(f"{label} requires nonempty string {key}")
    return value


def _evidence_list(item: Mapping[str, Any], label: str) -> list[str]:
    return _string_list(
        item.get("evidence"), f"{label}.evidence", allow_empty=False, unique=False
    )


def _initial_entry(item: Mapping[str, Any], label: str) -> Mapping[str, Any]:
    value = _json_clone(item)
    _required_string(value, "id", label)
    _required_string(value, "owner", label)
    _required_string(value, "state", label)
    _required_string(value, "next", label)
    _evidence_list(value, label)
    value["updated_sequence"] = 0
    return value


def _merge_initial_entries(
    supplied: Sequence[Mapping[str, Any]],
    required: Sequence[Mapping[str, Any]],
    label: str,
) -> Tuple[Mapping[str, Any], ...]:
    """Inject digest-derived joins without allowing sequence-zero overrides."""

    mapped: dict[str, Mapping[str, Any]] = {}
    for raw in supplied:
        entry = _initial_entry(raw, label)
        item_id = entry["id"]
        if item_id in mapped:
            raise LifecycleRejected(f"duplicate {label} id: {item_id}")
        mapped[item_id] = entry
    required_ids = {
        _required_string(raw, "id", f"required {label}")
        for raw in required
    }
    collisions = sorted(required_ids & set(mapped))
    if collisions:
        raise LifecycleRejected(
            f"caller cannot override digest-derived {label} entries: {collisions}"
        )
    for raw in required:
        entry = _initial_entry(raw, label)
        mapped[entry["id"]] = entry
    return tuple(mapped[key] for key in sorted(mapped))


def _entry_map(
    entries: Sequence[Mapping[str, Any]], label: str
) -> dict[str, Mapping[str, Any]]:
    mapped: dict[str, Mapping[str, Any]] = {}
    for entry in entries:
        item_id = _required_string(entry, "id", label)
        if item_id in mapped:
            raise LifecycleRejected(f"duplicate {label} id: {item_id}")
        mapped[item_id] = entry
    return mapped


_MILESTONE_TRANSITIONS = {
    None: {"pending", "ready", "in_progress", "blocked", "skipped"},
    "pending": {"ready", "in_progress", "blocked", "skipped"},
    "ready": {"in_progress", "blocked", "skipped"},
    "in_progress": {"blocked", "completed"},
    "blocked": {"ready", "in_progress", "skipped"},
    "completed": set(),
    "skipped": set(),
}
_EXECUTION_TRANSITIONS = {
    None: {"planned", "dispatched", "running", "blocked", "cancelled"},
    "planned": {"dispatched", "running", "blocked", "cancelled"},
    "dispatched": {"running", "blocked", "failed", "cancelled"},
    "running": {"blocked", "completed", "failed", "cancelled"},
    "blocked": {"planned", "dispatched", "running", "cancelled"},
    "failed": {"planned", "blocked", "cancelled"},
    "completed": set(),
    "cancelled": set(),
}
_GATE_TRANSITIONS = {
    None: {"open", "pass", "fail", "not_applicable"},
    "open": {"pass", "fail", "not_applicable"},
    "fail": {"open", "pass", "not_applicable"},
    "pass": {"open"},
    "not_applicable": {"open"},
}
_BLOCKER_TRANSITIONS = {None: {"open"}, "open": {"resolved"}, "resolved": set()}
_VERIFICATION_TRANSITIONS = {
    None: {"pending", "pass", "fail", "invalid"},
    "pending": {"pass", "fail", "invalid"},
    "fail": {"pending", "pass", "invalid"},
    "invalid": {"pending", "pass", "fail"},
    "pass": {"pending"},
}


def _transition_entry(
    entries: Sequence[Mapping[str, Any]],
    payload: Mapping[str, Any],
    *,
    sequence: int,
    label: str,
    transitions: Mapping[Optional[str], set[str]],
) -> Tuple[Mapping[str, Any], ...]:
    value = _json_clone(payload)
    item_id = _required_string(value, "id", label)
    _required_string(value, "owner", label)
    new_state = _required_string(value, "state", label)
    _required_string(value, "next", label)
    _evidence_list(value, label)
    mapped = _entry_map(entries, label)
    old_state = mapped.get(item_id, {}).get("state")
    if new_state not in transitions.get(old_state, set()):
        raise LifecycleRejected(
            f"invalid {label} transition {old_state!r} -> {new_state!r}"
        )
    value["updated_sequence"] = sequence
    mapped[item_id] = value
    return tuple(mapped[key] for key in sorted(mapped))


def _decision_entry(
    payload: Mapping[str, Any], *, kind: str, sequence: int
) -> Mapping[str, Any]:
    value = _json_clone(payload)
    _required_string(value, "id", kind)
    _required_string(value, "summary", kind)
    _required_string(value, "next", kind)
    _evidence_list(value, kind)
    value["kind"] = kind
    value["updated_sequence"] = sequence
    return value


def _next_overall_state(
    state: TaskStatusState, kwargs: Mapping[str, Any]
) -> str:
    if "terminal" in kwargs:
        return kwargs["terminal"]["state"]
    approval_state = kwargs.get("approval_state", state.approval_state)
    if approval_state != "approved":
        return "awaiting_reapproval"
    blockers = kwargs.get("blockers", state.blockers)
    return (
        "blocked"
        if any(item.get("state") == "open" for item in blockers)
        else "active"
    )


def _refresh_catalogs_for_digest(
    state: TaskStatusState,
    digest_value: Mapping[str, Any],
    *,
    sequence: int,
) -> dict[str, Tuple[Mapping[str, Any], ...]]:
    """Reconcile a fenced ledger with every obligation in a new digest.

    Exact unchanged completed obligations retain their evidence. Changed or
    newly introduced obligations are reset/materialized under the new digest;
    removed obligations remain as explicitly cancelled/skipped history.
    """

    required_milestones, required_execution, required_verification = (
        _required_status_entries(
            digest_value,
            coordinator_id=state.coordinator_id,
            sequence=sequence,
        )
    )
    replan_evidence = f"approved replan digest:{digest_value['digest_id']}"

    old_plan = {
        node["node_id"]: node for node in state.contract["plan"]
    }
    new_plan = {
        node["node_id"]: node for node in digest_value["plan"]
    }
    execution = {
        key: _json_clone(value)
        for key, value in _entry_map(state.execution, "execution").items()
    }
    for node_id in sorted(set(old_plan) - set(new_plan)):
        prior = execution.get(node_id)
        if prior is None or prior["state"] in {"completed", "cancelled"}:
            continue
        prior["state"] = "cancelled"
        prior["evidence"] = list(prior["evidence"]) + [replan_evidence]
        prior["next"] = "removed by the newly approved material replan"
        prior["updated_sequence"] = sequence
    required_execution_by_id = {
        item["id"]: _json_clone(item) for item in required_execution
    }
    for node_id, template in required_execution_by_id.items():
        prior = execution.get(node_id)
        unchanged = old_plan.get(node_id) == new_plan[node_id]
        if prior is not None and unchanged and prior["state"] == "completed":
            continue
        if prior is not None:
            template["evidence"] = list(prior["evidence"]) + list(
                template["evidence"]
            )
        execution[node_id] = template

    old_lifecycle = state.contract["monitoring_verification_cleanup"]
    new_lifecycle = digest_value["monitoring_verification_cleanup"]
    old_milestone_semantics = {
        f"terminal-{field.replace('_', '-')}": old_lifecycle[field]
        for field in TERMINAL_MILESTONE_FIELDS
    }
    old_milestone_semantics.update({
        _output_milestone_id(output): output
        for output in state.contract["outputs"]
    })
    new_milestone_semantics = {
        f"terminal-{field.replace('_', '-')}": new_lifecycle[field]
        for field in TERMINAL_MILESTONE_FIELDS
    }
    new_milestone_semantics.update({
        _output_milestone_id(output): output
        for output in digest_value["outputs"]
    })
    milestones = {
        key: _json_clone(value)
        for key, value in _entry_map(state.milestones, "milestone").items()
    }
    for item_id in sorted(set(old_milestone_semantics) - set(new_milestone_semantics)):
        prior = milestones.get(item_id)
        if prior is None or prior["state"] in {"completed", "skipped"}:
            continue
        prior["state"] = "skipped"
        prior["evidence"] = list(prior["evidence"]) + [replan_evidence]
        prior["next"] = "removed by the newly approved material replan"
        prior["updated_sequence"] = sequence
    for template in required_milestones:
        item_id = template["id"]
        prior = milestones.get(item_id)
        unchanged = (
            old_milestone_semantics.get(item_id)
            == new_milestone_semantics[item_id]
        )
        if prior is not None and unchanged:
            continue
        if prior is not None:
            template["evidence"] = list(prior["evidence"]) + list(
                template["evidence"]
            )
        milestones[item_id] = template

    verification = {
        key: _json_clone(value)
        for key, value in _entry_map(state.verification, "verification").items()
    }
    for template in required_verification:
        prior = verification.get(template["id"])
        if prior is not None:
            template["evidence"] = list(prior["evidence"]) + list(
                template["evidence"]
            )
        verification[template["id"]] = template

    return {
        "milestones": tuple(milestones[key] for key in sorted(milestones)),
        "execution": tuple(execution[key] for key in sorted(execution)),
        "verification": tuple(verification[key] for key in sorted(verification)),
    }


def _refresh_fields(
    state: TaskStatusState,
    update: StatusUpdate,
    *,
    expected_writer_role: str,
    change_mode: str,
    terminal_requirements: Sequence[str],
    approval_now: str,
) -> dict[str, Any]:
    if update.canonical_digest is None or update.canonical_approval is None:
        raise ApprovalRequired(
            f"{update.kind} requires a canonical digest and approval"
        )
    identity = TaskIdentity(state.task_id, state.identity_digest)
    hashes = _validate_canonical_binding(
        identity,
        Path(state.ledger_path),
        Path(state.canonical_root),
        update.canonical_digest,
        update.canonical_approval,
        now=approval_now,
        expected_writer_role=expected_writer_role,
    )
    digest_value = _json_clone(update.canonical_digest)
    approval_value = _json_clone(update.canonical_approval)
    if approval_value["approval_id"] == state.approval_id:
        raise ApprovalRequired("refresh requires a newly issued canonical approval")
    contract = contract_from_digest(
        digest_value,
        change_mode=change_mode,
        terminal_requirements=terminal_requirements,
    )
    material_refresh = (
        hashes["digest_sha256"] != state.digest_sha256
        or contract != state.contract
    )
    if material_refresh:
        if state.approval_state != "stale_reapproval_required":
            raise ApprovalRequired(
                "material approval refresh requires a prior typed invalidation"
            )
        previous_refresh_sequence = max(
            (
                item["updated_sequence"]
                for item in state.decisions
                if item.get("kind") in {"reapproval_refresh", "writer_transfer"}
            ),
            default=0,
        )
        current_invalidations = [
            item
            for item in state.decisions
            if item.get("kind") == "approval_invalidation"
            and item.get("updated_sequence", 0) > previous_refresh_sequence
        ]
        if not current_invalidations:
            raise ApprovalRequired(
                "material approval refresh lacks current safe-fence evidence"
            )
        if any(
            item.get("state") not in {"blocked", "completed", "cancelled"}
            for item in state.execution
        ):
            raise ApprovalRequired(
                "material approval refresh found unfenced execution"
            )
    refreshed = {
        "epoch": digest_value["workflow_epoch"],
        "approval_id": approval_value["approval_id"],
        "approval_issued_at": approval_value["issued_at"],
        "approval_expires_at": approval_value["expires_at"],
        "digest_id": digest_value["digest_id"],
        "digest_sha256": hashes["digest_sha256"],
        "plan_sha256": hashes["plan_sha256"],
        "scope_sha256": hashes["scope_sha256"],
        "approval_state": "approved",
        "contract": contract,
        "self_grill": self_grill_summary_from_digest(digest_value),
    }
    if material_refresh:
        refreshed.update(
            _refresh_catalogs_for_digest(
                state,
                digest_value,
                sequence=update.sequence,
            )
        )
    return refreshed


def apply_status_update(
    state: TaskStatusState,
    update: StatusUpdate,
    *,
    approval_now: Optional[str] = None,
) -> TaskStatusState:
    """Apply one exact next-sequence typed update to canonical state."""

    validate_status_state(state)
    if state.terminal is not None:
        raise LifecycleRejected("terminal ledger cannot accept another update")
    if update.sequence != state.sequence + 1:
        raise SequenceRejected(
            f"expected sequence {state.sequence + 1}, received {update.sequence}"
        )
    observed_at = _canonical_time(update.observed_at, "status update time")
    if _time_value(observed_at, "status update time") < _time_value(
        state.updated_at, "state updated_at"
    ):
        raise SequenceRejected("status update time predates the current ledger")
    if state.approval_state != "approved" and update.kind not in {
        "reapproval_refresh",
        "writer_transfer",
        "blocker",
        "verification",
        "terminal",
    }:
        raise ApprovalRequired(
            "safe fence blocks progress until canonical reapproval"
        )

    payload = _json_clone(update.payload)
    kwargs: dict[str, Any] = {}
    item_id: Any = payload.get("id", update.kind)

    if update.kind == "milestone":
        kwargs["milestones"] = _transition_entry(
            state.milestones,
            payload,
            sequence=update.sequence,
            label="milestone",
            transitions=_MILESTONE_TRANSITIONS,
        )
    elif update.kind == "domain_gate":
        kwargs["domain_gates"] = _transition_entry(
            state.domain_gates,
            payload,
            sequence=update.sequence,
            label="domain gate",
            transitions=_GATE_TRANSITIONS,
        )
    elif update.kind == "execution":
        kwargs["execution"] = _transition_entry(
            state.execution,
            payload,
            sequence=update.sequence,
            label="execution",
            transitions=_EXECUTION_TRANSITIONS,
        )
    elif update.kind in {"decision", "replan"}:
        value = _decision_entry(
            payload, kind=update.kind, sequence=update.sequence
        )
        item_id = value["id"]
        if item_id in _entry_map(state.decisions, "decision"):
            raise LifecycleRejected(f"duplicate decision/replan id: {item_id}")
        kwargs["decisions"] = tuple(state.decisions) + (value,)
    elif update.kind == "blocker":
        kwargs["blockers"] = _transition_entry(
            state.blockers,
            payload,
            sequence=update.sequence,
            label="blocker",
            transitions=_BLOCKER_TRANSITIONS,
        )
    elif update.kind == "verification":
        kwargs["verification"] = _transition_entry(
            state.verification,
            payload,
            sequence=update.sequence,
            label="verification",
            transitions=_VERIFICATION_TRANSITIONS,
        )
    elif update.kind == "approval_invalidation":
        value = _exact_keys(
            payload,
            {
                "invalidation_id",
                "changed_fields",
                "affected_execution_ids",
                "summary",
                "evidence",
                "next",
            },
            "approval_invalidation",
        )
        if state.approval_state != "approved":
            raise ApprovalRequired("approval is already stale")
        invalidation_id = _required_string(
            value, "invalidation_id", "approval_invalidation"
        )
        changed = _string_list(
            value["changed_fields"],
            "approval_invalidation.changed_fields",
            allow_empty=False,
        )
        if not set(changed) <= set(
            pre_execution_gate.MATERIAL_INVALIDATION_FIELDS
        ):
            raise LifecycleRejected(
                "approval invalidation contains an unsupported changed field"
            )
        affected = _string_list(
            value["affected_execution_ids"],
            "approval_invalidation.affected_execution_ids",
        )
        fenceable = {
            item["id"]
            for item in state.execution
            if item.get("state") not in {"completed", "cancelled"}
        }
        if set(affected) != fenceable:
            raise LifecycleRejected(
                "safe fence must name every nonterminal execution entry exactly"
            )
        _required_string(value, "summary", "approval_invalidation")
        _required_string(value, "next", "approval_invalidation")
        evidence = _evidence_list(value, "approval_invalidation")
        execution: list[Mapping[str, Any]] = []
        for entry in state.execution:
            cloned = _json_clone(entry)
            if cloned["id"] in fenceable:
                cloned["state"] = "blocked"
                cloned["evidence"] = list(cloned["evidence"]) + evidence
                cloned["next"] = "await canonical reapproval"
                cloned["updated_sequence"] = update.sequence
            execution.append(cloned)
        decision = {
            "id": invalidation_id,
            "kind": "approval_invalidation",
            "summary": value["summary"],
            "changed_fields": changed,
            "affected_execution_ids": affected,
            "evidence": evidence,
            "next": value["next"],
            "updated_sequence": update.sequence,
        }
        if invalidation_id in _entry_map(state.decisions, "decision"):
            raise LifecycleRejected(
                f"duplicate invalidation id: {invalidation_id}"
            )
        kwargs.update(
            execution=tuple(execution),
            decisions=tuple(state.decisions) + (decision,),
            approval_state="stale_reapproval_required",
        )
        item_id = invalidation_id
    elif update.kind == "reapproval_refresh":
        value = _exact_keys(
            payload,
            {
                "change_mode",
                "terminal_requirements",
                "summary",
                "evidence",
                "next",
            },
            "reapproval_refresh",
        )
        _required_string(value, "summary", "reapproval_refresh")
        _required_string(value, "next", "reapproval_refresh")
        _evidence_list(value, "reapproval_refresh")
        requirements = _string_list(
            value["terminal_requirements"],
            "reapproval_refresh.terminal_requirements",
            allow_empty=False,
        )
        kwargs.update(
            _refresh_fields(
                state,
                update,
                expected_writer_role=state.current_writer_role,
                change_mode=value["change_mode"],
                terminal_requirements=requirements,
                approval_now=approval_now or update.observed_at,
            )
        )
        assert update.canonical_approval is not None
        decision = {
            "id": f"reapproval:{update.canonical_approval['approval_id']}",
            "kind": "reapproval_refresh",
            "summary": value["summary"],
            "evidence": value["evidence"],
            "next": value["next"],
            "updated_sequence": update.sequence,
        }
        if decision["id"] in _entry_map(state.decisions, "decision"):
            raise LifecycleRejected(
                f"duplicate refreshed approval: {decision['id']}"
            )
        kwargs["decisions"] = tuple(state.decisions) + (decision,)
        item_id = decision["id"]
    elif update.kind == "writer_transfer":
        value = _exact_keys(
            payload,
            {
                "to_role",
                "new_lease_id",
                "change_mode",
                "terminal_requirements",
                "summary",
                "evidence",
                "next",
            },
            "writer_transfer",
        )
        to_role = _required_string(value, "to_role", "writer_transfer")
        new_lease_id = _required_string(
            value, "new_lease_id", "writer_transfer"
        )
        if (
            to_role not in {"coordinator", "observer"}
            or to_role == state.current_writer_role
        ):
            raise WriterRejected(
                "writer transfer must select the other declared writer"
            )
        if to_role == "observer" and state.observer_id is None:
            raise WriterRejected("writer transfer target observer is not declared")
        if new_lease_id == state.writer_lease_id:
            raise WriterRejected("writer transfer requires a fresh lease_id")
        requirements = _string_list(
            value["terminal_requirements"],
            "writer_transfer.terminal_requirements",
            allow_empty=False,
        )
        _required_string(value, "summary", "writer_transfer")
        _required_string(value, "next", "writer_transfer")
        _evidence_list(value, "writer_transfer")
        kwargs.update(
            _refresh_fields(
                state,
                update,
                expected_writer_role=to_role,
                change_mode=value["change_mode"],
                terminal_requirements=requirements,
                approval_now=approval_now or update.observed_at,
            )
        )
        target_id = (
            state.coordinator_id if to_role == "coordinator" else state.observer_id
        )
        assert target_id is not None
        kwargs.update(
            current_writer_role=to_role,
            current_writer_id=target_id,
            writer_lease_id=new_lease_id,
        )
        decision = {
            "id": f"writer-transfer:{new_lease_id}",
            "kind": "writer_transfer",
            "summary": value["summary"],
            "evidence": value["evidence"],
            "next": value["next"],
            "to_role": to_role,
            "new_lease_id": new_lease_id,
            "updated_sequence": update.sequence,
        }
        if decision["id"] in _entry_map(state.decisions, "decision"):
            raise LifecycleRejected(f"duplicate writer lease: {new_lease_id}")
        kwargs["decisions"] = tuple(state.decisions) + (decision,)
        item_id = decision["id"]
    elif update.kind == "terminal":
        terminal_state = _required_string(payload, "state", "terminal")
        if terminal_state not in TERMINAL_STATES:
            raise LifecycleRejected(f"invalid terminal state: {terminal_state}")
        _required_string(payload, "next", "terminal")
        _evidence_list(payload, "terminal")
        payload["updated_sequence"] = update.sequence
        kwargs["terminal"] = payload
        item_id = terminal_state
    else:
        raise LifecycleRejected(f"unknown status update kind: {update.kind}")

    kwargs["overall_state"] = _next_overall_state(state, kwargs)
    history_item = {
        "sequence": update.sequence,
        "kind": update.kind,
        "id": item_id,
        "observed_at": observed_at,
        "source_packet_id": update.source_packet_id,
    }
    candidate = replace(
        state,
        sequence=update.sequence,
        updated_at=observed_at,
        history=tuple(state.history) + (history_item,),
        **kwargs,
    )
    validate_status_state(candidate)
    if update.kind == "terminal":
        validate_terminal_lifecycle(candidate)
    return candidate


def validate_status_state(state: TaskStatusState) -> None:
    for field_name in (
        "task_id",
        "title",
        "epoch",
        "digest_id",
        "current_writer_id",
        "writer_lease_id",
    ):
        field_value = getattr(state, field_name)
        if not isinstance(field_value, str) or not field_value.strip():
            raise LifecycleRejected(f"state requires nonempty {field_name}")
    for field_name in (
        "identity_digest",
        "approval_id",
        "digest_sha256",
        "plan_sha256",
        "scope_sha256",
    ):
        if not _SHA256_RE.fullmatch(getattr(state, field_name)):
            raise LifecycleRejected(f"{field_name} must be lowercase SHA-256")
    if state.sequence < 0:
        raise SequenceRejected("sequence cannot be negative")
    ledger_path = Path(state.ledger_path)
    canonical_root = Path(state.canonical_root)
    if ledger_path.name != STATUS_FILENAME or not ledger_path.is_absolute():
        raise UnsafeStatusPath(
            f"ledger must be an absolute {STATUS_FILENAME} path"
        )
    try:
        pre_execution_gate.canonical_absolute_path(
            state.canonical_root, "state.canonical_root"
        )
        pre_execution_gate.canonical_absolute_path(
            state.ledger_path, "state.ledger_path"
        )
    except pre_execution_gate.GateError as exc:
        raise UnsafeStatusPath(str(exc)) from exc
    if not _is_within(ledger_path, canonical_root):
        raise UnsafeStatusPath("ledger path lies outside canonical root")
    created = _canonical_time(state.created_at, "state created_at")
    updated = _canonical_time(state.updated_at, "state updated_at")
    approval_issued = _canonical_time(
        state.approval_issued_at, "state approval_issued_at"
    )
    if state.approval_expires_at is not None:
        approval_expires = _canonical_time(
            state.approval_expires_at, "state approval_expires_at"
        )
        if _time_value(approval_expires, "state approval_expires_at") <= _time_value(
            approval_issued, "state approval_issued_at"
        ):
            raise ApprovalRequired("state approval expiry does not follow issuance")
    if _time_value(updated, "state updated_at") < _time_value(
        created, "state created_at"
    ):
        raise SequenceRejected("state updated_at predates created_at")
    if state.current_writer_role not in {"coordinator", "observer"}:
        raise WriterRejected("state current writer role is invalid")
    expected_writer = (
        state.coordinator_id
        if state.current_writer_role == "coordinator"
        else state.observer_id
    )
    if not expected_writer or state.current_writer_id != expected_writer:
        raise WriterRejected("state current writer role and identity disagree")
    if state.approval_state not in {
        "approved",
        "stale_reapproval_required",
    }:
        raise LifecycleRejected("state approval_state is unsupported")
    if state.overall_state not in OVERALL_STATES:
        raise LifecycleRejected("state overall_state is unsupported")
    if (
        state.approval_state != "approved"
        and state.overall_state
        not in {
            "awaiting_reapproval",
            "partial",
            "blocked",
            "withheld",
            "cancelled",
        }
    ):
        raise LifecycleRejected("stale approval must remain fenced or terminal")
    _validate_contract(state.contract)
    if not any(
        pre_execution_gate.path_is_within(
            state.canonical_root, root
        )
        for root in state.contract["scope"]["allowed_roots"]
    ):
        raise UnsafeStatusPath("canonical root lies outside approved contract scope")
    if Path(state.contract["status_path"]) != ledger_path:
        raise LifecycleRejected(
            "contract status_path differs from canonical ledger path"
        )
    _validate_self_grill(state.self_grill)
    if (
        state.approval_state == "approved"
        and state.self_grill.get("state") != "digest_ready"
    ):
        raise LifecycleRejected(
            "approved state requires a digest-ready self-grill summary"
        )

    if state.terminal is None:
        expected_overall = (
            "awaiting_reapproval"
            if state.approval_state != "approved"
            else (
                "blocked"
                if any(item.get("state") == "open" for item in state.blockers)
                else "active"
            )
        )
        if state.overall_state != expected_overall:
            raise LifecycleRejected(
                "nonterminal overall state disagrees with approval and blocker state"
            )

    catalogs = (
        (
            "domain gate",
            state.domain_gates,
            set().union(*_GATE_TRANSITIONS.values()),
        ),
        (
            "milestone",
            state.milestones,
            set().union(*_MILESTONE_TRANSITIONS.values()),
        ),
        (
            "execution",
            state.execution,
            set().union(*_EXECUTION_TRANSITIONS.values()),
        ),
        (
            "blocker",
            state.blockers,
            set().union(*_BLOCKER_TRANSITIONS.values()),
        ),
        (
            "verification",
            state.verification,
            set().union(*_VERIFICATION_TRANSITIONS.values()),
        ),
    )
    for label, entries, valid_states in catalogs:
        _entry_map(entries, label)
        for entry in entries:
            _required_string(entry, "owner", label)
            entry_state = _required_string(entry, "state", label)
            if entry_state not in valid_states:
                raise LifecycleRejected(
                    f"invalid {label} state: {entry_state}"
                )
            _required_string(entry, "next", label)
            _evidence_list(entry, label)
            entry_sequence = entry.get("updated_sequence")
            if (
                not isinstance(entry_sequence, int)
                or not 0 <= entry_sequence <= state.sequence
            ):
                raise SequenceRejected(
                    f"invalid {label} updated_sequence: {entry_sequence}"
                )

    for requirement in state.contract["terminal_requirements"]:
        kind, entry = _requirement_entry(state, requirement)
        if entry is None:
            raise LifecycleRejected(
                f"digest-derived terminal requirement has no ledger entry: {requirement}"
            )
        if (kind == "milestone" and entry.get("state") == "skipped") or (
            kind == "execution" and entry.get("state") == "cancelled"
        ):
            raise LifecycleRejected(
                f"required work cannot be silently waived: {requirement}"
            )

    _entry_map(state.decisions, "decision")
    for entry in state.decisions:
        if entry.get("kind") not in DECISION_KINDS:
            raise LifecycleRejected(
                f"invalid decision kind: {entry.get('kind')}"
            )
        _required_string(entry, "summary", "decision")
        _required_string(entry, "next", "decision")
        _evidence_list(entry, "decision")
        entry_sequence = entry.get("updated_sequence")
        if (
            not isinstance(entry_sequence, int)
            or not 1 <= entry_sequence <= state.sequence
        ):
            raise SequenceRejected(
                f"invalid decision updated_sequence: {entry_sequence}"
            )

    if state.terminal is not None:
        terminal_state = _required_string(state.terminal, "state", "terminal")
        if terminal_state not in TERMINAL_STATES:
            raise LifecycleRejected(
                f"invalid terminal state: {terminal_state}"
            )
        _required_string(state.terminal, "next", "terminal")
        _evidence_list(state.terminal, "terminal")
        if state.terminal.get("updated_sequence") != state.sequence:
            raise SequenceRejected(
                "terminal disposition must be the latest sequence"
            )
        if state.overall_state != terminal_state:
            raise LifecycleRejected("terminal and overall state disagree")

    sequences = [item.get("sequence") for item in state.history]
    if sequences != list(range(1, state.sequence + 1)):
        raise SequenceRejected(
            f"history must contain every sequence 1..{state.sequence}: {sequences}"
        )
    previous = _time_value(created, "state created_at")
    for item in state.history:
        if set(item) != {
            "sequence",
            "kind",
            "id",
            "observed_at",
            "source_packet_id",
        }:
            raise LifecycleRejected("history item fields mismatch")
        observed = _time_value(item["observed_at"], "history observed_at")
        if observed < previous:
            raise SequenceRejected("history timestamps are not monotonic")
        previous = observed
    if (
        state.history
        and _canonical_time(
            state.history[-1]["observed_at"], "history observed_at"
        )
        != updated
    ):
        raise SequenceRejected(
            "updated_at must equal the latest history timestamp"
        )
    if not state.history and updated != created:
        raise SequenceRejected(
            "sequence-zero ledger must have equal creation/update times"
        )


def _requirement_entry(
    state: TaskStatusState, requirement: str
) -> tuple[str, Optional[Mapping[str, Any]]]:
    try:
        kind, item_id = requirement.split(":", 1)
    except ValueError:
        return "", None
    catalogs = {
        "milestone": (state.milestones, {"completed", "skipped"}),
        "execution": (state.execution, {"completed", "cancelled"}),
        "verification": (state.verification, {"pass"}),
        "domain_gate": (
            state.domain_gates,
            {"pass", "not_applicable"},
        ),
        "blocker": (state.blockers, {"resolved"}),
    }
    if kind not in catalogs:
        return kind, None
    entries, _accepted = catalogs[kind]
    entry = _entry_map(entries, kind.replace("_", " ")).get(item_id)
    return kind, entry


def _requirement_satisfied(
    state: TaskStatusState, requirement: str
) -> bool:
    kind, entry = _requirement_entry(state, requirement)
    accepted = {
        "milestone": {"completed"},
        "execution": {"completed"},
        "verification": {"pass"},
        "domain_gate": {"pass", "not_applicable"},
        "blocker": {"resolved"},
    }
    return entry is not None and entry.get("state") in accepted.get(kind, set())


def validate_terminal_lifecycle(state: TaskStatusState) -> None:
    """Reject false completion; partial exits may retain explicit open work."""

    if state.terminal is None or state.terminal.get("state") != "complete":
        return
    if state.approval_state != "approved":
        raise LifecycleRejected("completion cannot rely on a stale approval")
    if any(
        item.get("state") not in {"completed", "skipped"}
        for item in state.milestones
    ):
        raise LifecycleRejected("completion has unfinished milestones")
    if any(
        item.get("state") not in {"completed", "cancelled"}
        for item in state.execution
    ):
        raise LifecycleRejected("completion has unfinished execution joins")
    if any(item.get("state") == "open" for item in state.blockers):
        raise LifecycleRejected("completion has an open blocker")
    if any(item.get("state") != "pass" for item in state.verification):
        raise LifecycleRejected("completion has non-passing verification")
    if any(
        item.get("state") not in {"pass", "not_applicable"}
        for item in state.domain_gates
    ):
        raise LifecycleRejected(
            "completion has an open or failing domain gate"
        )
    missing = [
        requirement
        for requirement in state.contract["terminal_requirements"]
        if not _requirement_satisfied(state, requirement)
    ]
    if missing:
        raise LifecycleRejected(
            f"terminal requirements are not satisfied: {missing}"
        )


def _escape_cell(value: Any) -> str:
    if value is None:
        return "—"
    if isinstance(value, (dict, list, tuple)):
        text_value = json.dumps(
            value,
            ensure_ascii=False,
            sort_keys=True,
            separators=(",", ":"),
        )
    else:
        text_value = str(value)
    return text_value.replace("|", "\\|").replace("\n", "<br>")


def _table(
    headers: Sequence[str], rows: Iterable[Sequence[Any]]
) -> str:
    materialized = list(rows)
    if not materialized:
        return "_None recorded._"
    header = "| " + " | ".join(headers) + " |"
    separator = "| " + " | ".join("---" for _ in headers) + " |"
    body = [
        "| " + " | ".join(_escape_cell(value) for value in row) + " |"
        for row in materialized
    ]
    return "\n".join([header, separator, *body])


def _render_metadata(state: TaskStatusState) -> str:
    declared = [f"coordinator:{state.coordinator_id}"]
    if state.observer_id:
        declared.append(f"observer:{state.observer_id}")
    return "\n".join(
        [
            f"- Task: {state.title}",
            f"- Task ID: {state.task_id}",
            f"- Workflow epoch: {state.epoch}",
            f"- Sequence: {state.sequence}",
            f"- Canonical root: {state.canonical_root}",
            f"- Path: {state.ledger_path}",
            f"- Overall state: {state.overall_state}",
            f"- Created at: {state.created_at}",
            f"- Updated at: {state.updated_at}",
            f"- Declared writers: {', '.join(declared)}",
            (
                f"- Current writer: "
                f"{state.current_writer_role}:{state.current_writer_id}"
            ),
            f"- Writer lease: {state.writer_lease_id}",
        ]
    )


def _render_contract(state: TaskStatusState) -> str:
    approval = "\n".join(
        [
            f"- Approval ID: {state.approval_id}",
            f"- Approval state: {state.approval_state}",
            f"- Approval issued at: {state.approval_issued_at}",
            f"- Approval expires at: {state.approval_expires_at or 'none'}",
            f"- Digest ID: {state.digest_id}",
            f"- Digest SHA-256: {state.digest_sha256}",
            f"- Plan SHA-256: {state.plan_sha256}",
            f"- Scope SHA-256: {state.scope_sha256}",
        ]
    )
    rows = [(key, state.contract[key]) for key in sorted(state.contract)]
    return f"{approval}\n\n{_table(('Field', 'Bound value'), rows)}"


def _render_self_grill(state: TaskStatusState) -> str:
    summary = state.self_grill
    metadata = "\n".join(
        [
            f"- Cycle: {summary['cycle_id']}",
            f"- Input snapshot: {summary['input_snapshot_sha256']}",
            f"- State: {summary['state']}",
            f"- Completed rounds: {summary['completed_rounds']}",
            (
                f"- Circuit breaker: "
                f"{str(summary['circuit_breaker_triggered']).lower()}"
            ),
            f"- Design deltas: {_escape_cell(summary['design_deltas'])}",
            f"- Question refs: {_escape_cell(summary['question_refs'])}",
            f"- Blocker refs: {_escape_cell(summary['blocker_refs'])}",
        ]
    )
    rows = [
        (
            item["round_id"],
            item["closure_state"],
            item["material_dimensions"],
            item["contradiction_dimensions"],
            item["unresolved_dimensions"],
        )
        for item in summary["impact_summary"]
    ]
    return (
        f"{metadata}\n\n"
        + _table(
            (
                "Round",
                "Closure",
                "Material",
                "Contradictions",
                "Unresolved",
            ),
            rows,
        )
    )


def _render_owned_entries(
    entries: Sequence[Mapping[str, Any]]
) -> str:
    rows = []
    for entry in sorted(
        entries, key=lambda item: str(item.get("id", ""))
    ):
        rows.append(
            (
                entry.get("id"),
                entry.get("owner"),
                entry.get("state"),
                entry.get("evidence", []),
                entry.get("next"),
                entry.get("updated_sequence"),
            )
        )
    return _table(
        ("ID", "Owner", "State", "Evidence", "Next", "Seq"), rows
    )


def _render_decisions(
    entries: Sequence[Mapping[str, Any]]
) -> str:
    rows = []
    for entry in sorted(
        entries, key=lambda item: int(item.get("updated_sequence", 0))
    ):
        rows.append(
            (
                entry.get("id"),
                entry.get("kind"),
                entry.get("summary"),
                entry.get("evidence", []),
                entry.get("next"),
                entry.get("updated_sequence"),
            )
        )
    return _table(
        ("ID", "Kind", "Summary", "Evidence", "Next", "Seq"), rows
    )


def _render_terminal(
    terminal: Optional[Mapping[str, Any]]
) -> str:
    if terminal is None:
        return "_Not terminal._"
    return _table(
        ("State", "Evidence", "Next", "Seq"),
        [
            (
                terminal.get("state"),
                terminal.get("evidence", []),
                terminal.get("next"),
                terminal.get("updated_sequence"),
            )
        ],
    )


def render_status(
    state: TaskStatusState, template_path: Path = TEMPLATE_PATH
) -> str:
    """Render canonical state deterministically; no authority is read back."""

    validate_status_state(state)
    validate_terminal_lifecycle(state)
    template = template_path.read_text(encoding="utf-8")
    replacements = {
        "<!-- ARLECCHINO:METADATA -->": _render_metadata(state),
        "<!-- ARLECCHINO:CONTRACT -->": _render_contract(state),
        "<!-- ARLECCHINO:SELF_GRILL -->": _render_self_grill(state),
        "<!-- ARLECCHINO:DOMAIN_GATES -->": _render_owned_entries(
            state.domain_gates
        ),
        "<!-- ARLECCHINO:MILESTONES -->": _render_owned_entries(
            state.milestones
        ),
        "<!-- ARLECCHINO:EXECUTION -->": _render_owned_entries(
            state.execution
        ),
        "<!-- ARLECCHINO:DECISIONS -->": _render_decisions(
            state.decisions
        ),
        "<!-- ARLECCHINO:BLOCKERS -->": _render_owned_entries(
            state.blockers
        ),
        "<!-- ARLECCHINO:VERIFICATION -->": _render_owned_entries(
            state.verification
        ),
        "<!-- ARLECCHINO:TERMINAL -->": _render_terminal(state.terminal),
    }
    rendered = template
    for token, value in replacements.items():
        if rendered.count(token) != 1:
            raise LifecycleRejected(
                f"template must contain token exactly once: {token}"
            )
        rendered = rendered.replace(token, value)
    if "<!-- ARLECCHINO:" in rendered:
        raise LifecycleRejected(
            "template contains an unknown Arlecchino token"
        )
    return rendered.rstrip() + "\n"


def _assert_state_authority(
    state: TaskStatusState,
    principal: AuthenticatedPrincipal,
    authority: WriterAuthority,
) -> None:
    authority.validate()
    if (
        state.coordinator_id != authority.coordinator_id
        or state.observer_id != authority.observer_id
        or state.current_writer_role != authority.current_writer_role
        or state.current_writer_id != authority.current_writer_id
        or state.writer_lease_id != authority.lease_id
    ):
        raise WriterRejected(
            "canonical state and current-writer lease disagree"
        )
    authority.authorize(principal)


@contextlib.contextmanager
def _directory_lock(directory: Path) -> Iterable[None]:
    """Serialize cooperating writers without adding a sidecar status file."""

    flags = os.O_RDONLY
    if hasattr(os, "O_DIRECTORY"):
        flags |= os.O_DIRECTORY
    descriptor = os.open(directory, flags)
    try:
        fcntl.flock(descriptor, fcntl.LOCK_EX)
        yield
    finally:
        fcntl.flock(descriptor, fcntl.LOCK_UN)
        os.close(descriptor)


def _write_new_exclusive(path: Path, content: str) -> None:
    path.parent.mkdir(mode=0o755, parents=True, exist_ok=True)
    flags = os.O_WRONLY | os.O_CREAT | os.O_EXCL
    if hasattr(os, "O_NOFOLLOW"):
        flags |= os.O_NOFOLLOW
    descriptor = os.open(path, flags, 0o644)
    try:
        with os.fdopen(
            descriptor, "w", encoding="utf-8", newline="\n"
        ) as handle:
            handle.write(content)
            handle.flush()
            os.fsync(handle.fileno())
    except Exception:
        try:
            path.unlink()
        except FileNotFoundError:
            pass
        raise


def _assert_location_still_safe(location: LocatorResult) -> None:
    path = Path(location.path)
    root = Path(location.canonical_root).resolve()
    if not _is_within(path, root):
        raise UnsafeStatusPath(
            f"ledger escaped canonical root after location: {path}"
        )
    if path.resolve(strict=False) != path:
        raise UnsafeStatusPath(
            f"ledger path gained a symlink component: {path}"
        )


def _assert_state_matches_approval(
    state: TaskStatusState,
    identity: TaskIdentity,
    location: LocatorResult,
    canonical_digest: Mapping[str, Any],
    canonical_approval: Mapping[str, Any],
    authority: WriterAuthority,
    *,
    now: str,
) -> None:
    hashes = _validate_canonical_binding(
        identity,
        location.path,
        location.canonical_root,
        canonical_digest,
        canonical_approval,
        now=now,
        expected_writer_role=authority.current_writer_role,
    )
    digest_value = _json_clone(canonical_digest)
    approval_value = _json_clone(canonical_approval)
    expected_contract = contract_from_digest(
        digest_value,
        change_mode=state.contract["change_mode"],
        terminal_requirements=state.contract["terminal_requirements"],
    )
    expected = {
        "task_id": identity.task_id,
        "identity_digest": identity.identity_digest,
        "epoch": digest_value["workflow_epoch"],
        "canonical_root": os.fspath(location.canonical_root),
        "ledger_path": os.fspath(location.path),
        "approval_id": approval_value["approval_id"],
        "approval_issued_at": approval_value["issued_at"],
        "approval_expires_at": approval_value["expires_at"],
        "digest_id": digest_value["digest_id"],
        "digest_sha256": hashes["digest_sha256"],
        "plan_sha256": hashes["plan_sha256"],
        "scope_sha256": hashes["scope_sha256"],
        "approval_state": "approved",
        "current_writer_role": authority.current_writer_role,
        "current_writer_id": authority.current_writer_id,
        "writer_lease_id": authority.lease_id,
    }
    for field_name, expected_value in expected.items():
        if getattr(state, field_name) != expected_value:
            raise ApprovalRequired(
                f"state {field_name} differs from canonical approval"
            )
    if state.contract != expected_contract:
        raise ApprovalRequired(
            "state contract differs from canonical digest"
        )
    if state.self_grill != self_grill_summary_from_digest(digest_value):
        raise ApprovalRequired(
            "state self-grill summary differs from canonical digest"
        )


def initialize_status_file(
    state: TaskStatusState,
    identity: TaskIdentity,
    location: LocatorResult,
    canonical_digest: Optional[Mapping[str, Any]],
    canonical_approval: Optional[Mapping[str, Any]],
    guard: Optional[FirstMutationGuard],
    principal: AuthenticatedPrincipal,
    authority: WriterAuthority,
    *,
    now: str,
) -> None:
    """Create TASK_STATUS as the first post-approval task mutation."""

    if (
        canonical_digest is None
        or canonical_approval is None
        or guard is None
    ):
        raise ApprovalRequired(
            "ledger creation requires canonical approval and first-mutation guard"
        )
    if Path(state.ledger_path) != location.path:
        raise UnsafeStatusPath(
            "state ledger path differs from locator result"
        )
    if location.reused:
        raise UnsafeStatusPath(
            "use resume_status_file for a reused ledger"
        )
    canonical_now = _canonical_time(now, "status initialization call time")
    if _time_value(canonical_now, "status initialization call time") < _time_value(
        state.updated_at, "state updated_at"
    ):
        raise SequenceRejected("status initialization call predates canonical state")
    guard.validate(canonical_approval)
    _assert_state_authority(state, principal, authority)
    _assert_state_matches_approval(
        state,
        identity,
        location,
        canonical_digest,
        canonical_approval,
        authority,
        now=canonical_now,
    )
    if state.sequence != 0 or state.history:
        raise SequenceRejected("new ledger must begin at sequence 0")
    with _directory_lock(location.canonical_root):
        _assert_location_still_safe(location)
        if location.path.exists():
            raise UnsafeStatusPath(
                "refusing to overwrite ledger during initialization: "
                f"{location.path}"
            )
        _write_new_exclusive(location.path, render_status(state))


def resume_status_file(
    state: TaskStatusState,
    identity: TaskIdentity,
    location: LocatorResult,
    canonical_digest: Optional[Mapping[str, Any]],
    canonical_approval: Optional[Mapping[str, Any]],
    guard: Optional[FirstMutationGuard],
    first_update: StatusUpdate,
    principal: AuthenticatedPrincipal,
    authority: WriterAuthority,
    *,
    now: str,
) -> TaskStatusState:
    """Refresh a trusted ledger as the first mutation of a new epoch."""

    if (
        canonical_digest is None
        or canonical_approval is None
        or guard is None
    ):
        raise ApprovalRequired(
            "ledger reuse requires canonical approval and first-mutation guard"
        )
    if not location.reused:
        raise UnsafeStatusPath(
            "resume requires a trusted same-task locator result"
        )
    if Path(state.ledger_path) != location.path:
        raise UnsafeStatusPath(
            "state ledger path differs from locator result"
        )
    if (
        state.task_id != identity.task_id
        or state.identity_digest != identity.identity_digest
    ):
        raise UnsafeStatusPath(
            "state belongs to another stable task identity"
        )
    if first_update.kind not in {
        "reapproval_refresh",
        "writer_transfer",
    }:
        raise ApprovalRequired(
            "reused ledger must first record canonical approval refresh"
        )
    guard.validate(canonical_approval)
    if (
        first_update.canonical_digest is not None
        and first_update.canonical_digest != canonical_digest
    ):
        raise ApprovalRequired(
            "first update and resume digest disagree"
        )
    if (
        first_update.canonical_approval is not None
        and first_update.canonical_approval != canonical_approval
    ):
        raise ApprovalRequired(
            "first update and resume approval disagree"
        )
    bound_update = replace(
        first_update,
        canonical_digest=_json_clone(canonical_digest),
        canonical_approval=_json_clone(canonical_approval),
    )
    _assert_state_authority(state, principal, authority)
    _assert_location_still_safe(location)
    return commit_status_update(
        location.path,
        state,
        bound_update,
        principal,
        authority,
        now=now,
    )


def _atomic_replace(path: Path, content: str) -> None:
    descriptor, temp_name = tempfile.mkstemp(
        prefix=".TASK_STATUS.", suffix=".tmp", dir=path.parent
    )
    temporary = Path(temp_name)
    try:
        mode = path.stat().st_mode & 0o777
        os.fchmod(descriptor, mode)
        with os.fdopen(
            descriptor, "w", encoding="utf-8", newline="\n"
        ) as handle:
            handle.write(content)
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temporary, path)
        directory_fd = os.open(path.parent, os.O_RDONLY)
        try:
            os.fsync(directory_fd)
        finally:
            os.close(directory_fd)
    finally:
        try:
            temporary.unlink()
        except FileNotFoundError:
            pass


def commit_status_update(
    path: Path,
    state: TaskStatusState,
    update: StatusUpdate,
    principal: AuthenticatedPrincipal,
    authority: WriterAuthority,
    *,
    now: str,
) -> TaskStatusState:
    """Serialize and atomically persist one current-writer update."""

    path = Path(path)
    if (
        path != Path(state.ledger_path)
        or path.name != STATUS_FILENAME
    ):
        raise UnsafeStatusPath(
            "write path differs from canonical ledger path"
        )
    call_time = _canonical_time(now, "status write call time")
    if _time_value(call_time, "status write call time") < _time_value(
        update.observed_at, "status update time"
    ):
        raise SequenceRejected("status write call time predates the update event")
    issued = _time_value(state.approval_issued_at, "state approval_issued_at")
    expires = (
        None
        if state.approval_expires_at is None
        else _time_value(state.approval_expires_at, "state approval_expires_at")
    )
    current_approval_time = (
        _time_value(call_time, "status write call time") >= issued
        and (expires is None or _time_value(call_time, "status write call time") < expires)
    )
    stale_safe_kinds = {
        "approval_invalidation",
        "reapproval_refresh",
        "writer_transfer",
        "blocker",
        "terminal",
    }
    if not current_approval_time and update.kind not in stale_safe_kinds:
        raise ApprovalRequired("expired approval cannot authorize a progress status write")
    if (
        not current_approval_time
        and update.kind == "terminal"
        and update.payload.get("state") == "complete"
    ):
        raise ApprovalRequired("expired approval cannot support terminal completion")
    if (
        not current_approval_time
        and update.kind == "blocker"
        and update.payload.get("state") != "open"
    ):
        raise ApprovalRequired(
            "expired approval permits only new open blocker evidence"
        )
    _assert_state_authority(state, principal, authority)
    if not path.parent.is_dir() or path.parent.is_symlink():
        raise UnsafeStatusPath(
            f"canonical ledger parent is missing or unsafe: {path.parent}"
        )
    with _directory_lock(path.parent):
        if (
            path.is_symlink()
            or path.resolve(strict=False) != path
            or not path.is_file()
        ):
            raise UnsafeStatusPath(
                f"canonical ledger is missing or unsafe: {path}"
            )
        expected = render_status(state).encode("utf-8")
        if path.read_bytes() != expected:
            raise SequenceRejected(
                "on-disk ledger drifted or another writer won the update"
            )
        candidate = apply_status_update(
            state, update, approval_now=call_time
        )
        if (
            not current_approval_time
            and update.kind in {"blocker", "terminal"}
            and candidate.approval_state == "approved"
        ):
            expiry_evidence = (
                f"approval expired before status write:{state.approval_id}:{call_time}"
            )
            execution: list[Mapping[str, Any]] = []
            affected_execution_ids: list[str] = []
            for entry in candidate.execution:
                cloned = _json_clone(entry)
                if cloned.get("state") not in {"completed", "cancelled"}:
                    affected_execution_ids.append(cloned["id"])
                    cloned["state"] = "blocked"
                    cloned["evidence"] = list(cloned["evidence"]) + [
                        expiry_evidence
                    ]
                    cloned["next"] = "await canonical reapproval"
                    cloned["updated_sequence"] = update.sequence
                execution.append(cloned)
            expiry_decision = {
                "id": f"approval-expired:{state.approval_id}:{update.sequence}",
                "kind": "approval_invalidation",
                "summary": "approval expired before a non-authorizing status write",
                "changed_fields": ["authority"],
                "affected_execution_ids": sorted(affected_execution_ids),
                "evidence": [expiry_evidence],
                "next": "obtain a fresh exact approval before progress",
                "updated_sequence": update.sequence,
            }
            candidate = replace(
                candidate,
                approval_state="stale_reapproval_required",
                overall_state=(
                    candidate.overall_state
                    if candidate.terminal is not None
                    else "awaiting_reapproval"
                ),
                execution=tuple(execution),
                decisions=tuple(candidate.decisions) + (expiry_decision,),
            )
            validate_status_state(candidate)
        _atomic_replace(path, render_status(candidate))
    return candidate


WORKER_DELTA_KINDS = {
    "milestone",
    "domain_gate",
    "execution",
    "blocker",
    "verification",
}


def relay_status_delta(
    path: Path,
    state: TaskStatusState,
    packet: StatusDeltaPacket,
    source: AuthenticatedPrincipal,
    writer: AuthenticatedPrincipal,
    authority: WriterAuthority,
    *,
    now: str,
) -> TaskStatusState:
    """Authenticate a worker report and let the current writer relay it."""

    if not source.verified_by_host:
        raise WriterRejected(
            "status delta source is not host-authenticated"
        )
    if (
        source.principal_id != packet.author_id
        or source.role != packet.author_role
        or source.role in {"coordinator", "observer", "user"}
    ):
        raise WriterRejected(
            "status delta author does not match an authenticated worker role"
        )
    if (
        packet.task_id != state.task_id
        or packet.epoch != state.epoch
    ):
        raise SequenceRejected(
            "status delta belongs to another task or epoch"
        )
    if packet.base_sequence != state.sequence:
        raise SequenceRejected(
            "status delta is stale or based on a future ledger"
        )
    if not packet.packet_id:
        raise LifecycleRejected("status delta requires packet_id")
    if packet.kind not in WORKER_DELTA_KINDS:
        raise WriterRejected(
            "worker delta cannot propose a protected ledger transition"
        )
    update = StatusUpdate(
        sequence=state.sequence + 1,
        kind=packet.kind,
        payload=packet.payload,
        observed_at=packet.observed_at,
        source_packet_id=packet.packet_id,
    )
    return commit_status_update(
        path, state, update, writer, authority, now=now
    )


def _main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--check-template",
        action="store_true",
        help="verify that the packaged deterministic template exists",
    )
    args = parser.parse_args()
    if args.check_template:
        text = TEMPLATE_PATH.read_text(encoding="utf-8")
        required = {
            "METADATA",
            "CONTRACT",
            "SELF_GRILL",
            "DOMAIN_GATES",
            "MILESTONES",
            "EXECUTION",
            "DECISIONS",
            "BLOCKERS",
            "VERIFICATION",
            "TERMINAL",
        }
        found = set(re.findall(r"<!-- ARLECCHINO:([A-Z_]+) -->", text))
        if found != required:
            raise SystemExit(f"template token mismatch: found={sorted(found)}")
        print("TASK_STATUS template: OK")
    return 0


if __name__ == "__main__":
    raise SystemExit(_main())
