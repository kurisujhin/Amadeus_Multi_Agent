#!/usr/bin/env python3
"""Losslessly wrap an exact pinned V4 domain packet as untrusted evidence.

The adapter deliberately does not translate a V4 packet into the native
``v5-domain-1`` schema.  It preserves the source bytes and parsed object, and
labels both as legacy evidence for a parent-owned projection step.
"""

from __future__ import annotations

import argparse
import base64
import hashlib
import json
import re
import sys
from pathlib import Path
from typing import Any


ADAPTER_VERSION = "arlecchino-v4-lossless-1"
EVIDENCE_KIND = "legacy_v4"
LEGACY_SNAPSHOT_ID = "2026-07-12"
PINNED_MANIFEST_SHA256 = "75878ece81f8690044f2a8e009b1a9f993f0a6a759ee290a2c9d3dbc0866c595"
SCRIPT = Path(__file__).resolve()
V6_ROOT = SCRIPT.parent.parent
SERIES_ROOT = V6_ROOT.parent.parent
DEFAULT_LEGACY_ROOT = SERIES_ROOT / "subskills/snapshots" / LEGACY_SNAPSHOT_ID
DEFAULT_MANIFEST = SERIES_ROOT / "subskills/2026-07-12-v4-producers.sha256"

EXPECTED_PRODUCERS = frozenset({
    "workflow-design-llm-nlp",
    "workflow-design-ops-forecasting-optimization",
    "workflow-design-policy-governance",
    "workflow-design-product-business-decision",
    "workflow-design-search-ranking-recsys",
    "workflow-design-security-privacy",
    "workflow-design-software-reliability",
    "workflow-design-speech-audio",
    "workflow-design-tabular-ml-evaluation",
    "workflow-design-vision-multimodal",
})

RECEIPT_KEYS = frozenset({
    "receipt_id",
    "evidence_kind",
    "adapter_version",
    "source_packet_contract",
    "source_subskill_name_and_snapshot_fingerprint",
    "legacy_packet_fingerprint",
    "legacy_packet_payload",
    "legacy_packet_payload_bytes",
    "adaptation_status",
    "unmapped_fields",
    "collision_log",
})

# ``parent_contract_version`` is reserved even though the wrapper intentionally
# omits it: copying it to the wrapper would falsely relabel the V4 source.
RESERVED_WRAPPER_FIELDS = RECEIPT_KEYS | frozenset({
    "parent_contract_version",
    "domain_packet_schema",
    "native_domain_packet",
    "native_validation_receipt",
})

TRANSPORT_KEYS = (RECEIPT_KEYS - {"legacy_packet_payload_bytes"}) | frozenset({
    "transport_contract",
    "legacy_packet_payload_bytes_base64",
})


class LegacyAdapterError(ValueError):
    """Deterministic rejection of a legacy source or adapter receipt."""


def sha256_bytes(payload: bytes) -> str:
    return hashlib.sha256(payload).hexdigest()


def canonical_json_bytes(value: Any) -> bytes:
    try:
        return json.dumps(
            value,
            ensure_ascii=False,
            allow_nan=False,
            sort_keys=True,
            separators=(",", ":"),
        ).encode("utf-8")
    except (TypeError, ValueError, UnicodeEncodeError) as exc:
        raise LegacyAdapterError("value is not strict JSON") from exc


def _reject_duplicate_keys(pairs: list[tuple[str, Any]]) -> dict[str, Any]:
    result: dict[str, Any] = {}
    for key, value in pairs:
        if key in result:
            raise LegacyAdapterError(f"duplicate JSON key: {key}")
        result[key] = value
    return result


def _reject_constant(value: str) -> None:
    raise LegacyAdapterError(f"nonstandard JSON constant: {value}")


def _reject_surrogates(value: Any, location: str = "$") -> None:
    if isinstance(value, str):
        if any(0xD800 <= ord(char) <= 0xDFFF for char in value):
            raise LegacyAdapterError(f"invalid Unicode surrogate at {location}")
    elif isinstance(value, dict):
        for key, nested in value.items():
            _reject_surrogates(key, f"{location}.<key>")
            _reject_surrogates(nested, f"{location}.{key}")
    elif isinstance(value, list):
        for index, nested in enumerate(value):
            _reject_surrogates(nested, f"{location}[{index}]")


def parse_json_bytes(payload_bytes: bytes) -> Any:
    """Parse strict UTF-8 JSON without normalizing the retained source bytes."""
    try:
        source = payload_bytes.decode("utf-8")
    except UnicodeDecodeError as exc:
        raise LegacyAdapterError("legacy packet is not UTF-8") from exc
    if source.startswith("\ufeff"):
        raise LegacyAdapterError("legacy packet must not contain a UTF-8 BOM")
    try:
        value = json.loads(
            source,
            object_pairs_hook=_reject_duplicate_keys,
            parse_constant=_reject_constant,
        )
    except LegacyAdapterError:
        raise
    except json.JSONDecodeError as exc:
        raise LegacyAdapterError(
            f"malformed legacy JSON at line {exc.lineno} column {exc.colno}"
        ) from exc
    _reject_surrogates(value)
    return value


def parse_pinned_manifest(path: Path = DEFAULT_MANIFEST) -> dict[str, str]:
    """Load the exact frozen V4 producer manifest."""
    payload = path.read_bytes()
    if sha256_bytes(payload) != PINNED_MANIFEST_SHA256:
        raise LegacyAdapterError("legacy producer manifest does not match its pinned aggregate")
    entries: dict[str, str] = {}
    try:
        lines = payload.decode("utf-8").splitlines()
    except UnicodeDecodeError as exc:
        raise LegacyAdapterError("legacy producer manifest is not UTF-8") from exc
    for number, line in enumerate(lines, 1):
        match = re.fullmatch(r"([0-9a-f]{64})  ([^/\s]+/SKILL\.md)", line)
        if match is None:
            raise LegacyAdapterError(f"malformed legacy manifest line {number}")
        digest, relative = match.groups()
        producer = relative.split("/", 1)[0]
        if producer in entries:
            raise LegacyAdapterError(f"duplicate legacy producer: {producer}")
        entries[producer] = digest
    if set(entries) != EXPECTED_PRODUCERS:
        raise LegacyAdapterError("legacy producer manifest has an unexpected package set")
    return entries


def verify_legacy_producer(
    producer: str,
    observed_fingerprint: str,
    *,
    legacy_root: Path = DEFAULT_LEGACY_ROOT,
    manifest_path: Path = DEFAULT_MANIFEST,
) -> str:
    """Verify producer name, live source bytes, manifest, and claimed fingerprint."""
    if producer not in EXPECTED_PRODUCERS or "/" in producer:
        raise LegacyAdapterError("unknown legacy producer")
    manifest = parse_pinned_manifest(manifest_path)
    pinned = manifest.get(producer)
    if pinned is None:
        raise LegacyAdapterError("legacy producer is not pinned")
    source = legacy_root / producer / "SKILL.md"
    if not source.is_file():
        raise LegacyAdapterError("legacy producer package is missing")
    live = sha256_bytes(source.read_bytes())
    if live != pinned:
        raise LegacyAdapterError("legacy producer source mismatches the pinned manifest")
    if observed_fingerprint != pinned:
        raise LegacyAdapterError("legacy producer fingerprint mismatch")
    return pinned


def _validate_receipt_shape(receipt: dict[str, Any]) -> None:
    if not isinstance(receipt, dict) or set(receipt) != RECEIPT_KEYS:
        raise LegacyAdapterError("legacy adapter receipt has missing or extra fields")
    if not isinstance(receipt["receipt_id"], str) or not receipt["receipt_id"].strip():
        raise LegacyAdapterError("receipt_id must be a nonblank string")
    if receipt["receipt_id"] != receipt["receipt_id"].strip():
        raise LegacyAdapterError("receipt_id must be canonical")
    if receipt["evidence_kind"] != EVIDENCE_KIND:
        raise LegacyAdapterError("legacy evidence kind mismatch")
    if receipt["adapter_version"] != ADAPTER_VERSION:
        raise LegacyAdapterError("legacy adapter version mismatch")
    if receipt["source_packet_contract"] != "v4":
        raise LegacyAdapterError("legacy packet was relabelled")
    if receipt["adaptation_status"] != "accepted":
        raise LegacyAdapterError("legacy receipt is not accepted")
    if receipt["unmapped_fields"] != []:
        raise LegacyAdapterError("lossless passthrough must not have unmapped fields")
    if not isinstance(receipt["legacy_packet_payload_bytes"], bytes):
        raise LegacyAdapterError("legacy packet bytes must remain bytes in the runtime receipt")


def adapt_legacy_packet(
    payload_bytes: bytes,
    *,
    receipt_id: str,
    producer: str,
    snapshot_id: str,
    observed_fingerprint: str,
    legacy_root: Path = DEFAULT_LEGACY_ROOT,
    manifest_path: Path = DEFAULT_MANIFEST,
) -> dict[str, Any]:
    """Return a lossless, explicitly V4, non-authoritative evidence receipt."""
    if not isinstance(payload_bytes, bytes):
        raise LegacyAdapterError("legacy payload must be exact bytes")
    if not isinstance(receipt_id, str) or not receipt_id.strip() or receipt_id != receipt_id.strip():
        raise LegacyAdapterError("receipt_id must be a canonical nonblank string")
    payload = parse_json_bytes(payload_bytes)
    if not isinstance(payload, dict):
        raise LegacyAdapterError("legacy packet root must be an object")
    if payload.get("parent_contract_version") != "v4":
        raise LegacyAdapterError("missing or unknown legacy parent contract version")
    if snapshot_id != LEGACY_SNAPSHOT_ID:
        raise LegacyAdapterError("legacy snapshot mismatch")
    pinned = verify_legacy_producer(
        producer,
        observed_fingerprint,
        legacy_root=legacy_root,
        manifest_path=manifest_path,
    )
    collisions = sorted(set(payload) & RESERVED_WRAPPER_FIELDS)
    receipt = {
        "receipt_id": receipt_id,
        "evidence_kind": EVIDENCE_KIND,
        "adapter_version": ADAPTER_VERSION,
        "source_packet_contract": "v4",
        "source_subskill_name_and_snapshot_fingerprint": {
            "name": producer,
            "snapshot_id": LEGACY_SNAPSHOT_ID,
            "fingerprint": pinned,
        },
        "legacy_packet_fingerprint": sha256_bytes(payload_bytes),
        "legacy_packet_payload": payload,
        "legacy_packet_payload_bytes": payload_bytes,
        "adaptation_status": "accepted",
        "unmapped_fields": [],
        "collision_log": collisions,
    }
    _validate_receipt_shape(receipt)
    return receipt


def validate_legacy_receipt(
    receipt: dict[str, Any],
    *,
    legacy_root: Path = DEFAULT_LEGACY_ROOT,
    manifest_path: Path = DEFAULT_MANIFEST,
) -> dict[str, Any]:
    """Revalidate an in-memory receipt and reject any mutation after adaptation."""
    _validate_receipt_shape(receipt)
    identity = receipt["source_subskill_name_and_snapshot_fingerprint"]
    if not isinstance(identity, dict) or set(identity) != {"name", "snapshot_id", "fingerprint"}:
        raise LegacyAdapterError("legacy source identity is malformed")
    expected = adapt_legacy_packet(
        receipt["legacy_packet_payload_bytes"],
        receipt_id=receipt["receipt_id"],
        producer=identity["name"],
        snapshot_id=identity["snapshot_id"],
        observed_fingerprint=identity["fingerprint"],
        legacy_root=legacy_root,
        manifest_path=manifest_path,
    )
    if receipt != expected:
        raise LegacyAdapterError("legacy adapter receipt was mutated")
    return receipt


def receipt_to_transport(receipt: dict[str, Any]) -> dict[str, Any]:
    """Encode the one byte field for deterministic JSON transport."""
    validate_legacy_receipt(receipt)
    transport = {key: value for key, value in receipt.items() if key != "legacy_packet_payload_bytes"}
    transport.update({
        "transport_contract": "arlecchino-legacy-v4-transport-1",
        "legacy_packet_payload_bytes_base64": base64.b64encode(
            receipt["legacy_packet_payload_bytes"]
        ).decode("ascii"),
    })
    return transport


def receipt_from_transport(value: Any) -> dict[str, Any]:
    if not isinstance(value, dict) or set(value) != TRANSPORT_KEYS:
        raise LegacyAdapterError("legacy transport has missing or extra fields")
    if value["transport_contract"] != "arlecchino-legacy-v4-transport-1":
        raise LegacyAdapterError("legacy transport contract mismatch")
    try:
        payload_bytes = base64.b64decode(
            value["legacy_packet_payload_bytes_base64"], validate=True
        )
    except (ValueError, TypeError) as exc:
        raise LegacyAdapterError("legacy transport bytes are not canonical base64") from exc
    receipt = {
        key: nested
        for key, nested in value.items()
        if key not in {"transport_contract", "legacy_packet_payload_bytes_base64"}
    }
    receipt["legacy_packet_payload_bytes"] = payload_bytes
    return validate_legacy_receipt(receipt)


def _parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("input", nargs="?", default="-", help="legacy JSON file, or - for stdin")
    parser.add_argument("--receipt-id", required=True)
    parser.add_argument("--producer", required=True)
    parser.add_argument("--snapshot", default=LEGACY_SNAPSHOT_ID)
    parser.add_argument("--fingerprint", required=True)
    return parser


def main(argv: list[str] | None = None) -> int:
    args = _parser().parse_args(argv)
    try:
        payload = sys.stdin.buffer.read() if args.input == "-" else Path(args.input).read_bytes()
        receipt = adapt_legacy_packet(
            payload,
            receipt_id=args.receipt_id,
            producer=args.producer,
            snapshot_id=args.snapshot,
            observed_fingerprint=args.fingerprint,
        )
        sys.stdout.buffer.write(canonical_json_bytes(receipt_to_transport(receipt)) + b"\n")
        return 0
    except (LegacyAdapterError, OSError) as exc:
        sys.stderr.buffer.write(canonical_json_bytes({"error": str(exc), "status": "rejected"}) + b"\n")
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
