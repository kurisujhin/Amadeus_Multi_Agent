#!/usr/bin/env python3
"""Project validated domain evidence into parent-owned, non-authoritative gates.

This module is intentionally pure: it does not create agents, mutate canonical
state, write ``TASK_STATUS.md``, grant approval, or dispatch work.  Domain
evidence can make an action ineligible, but can never make execution eligible
without a separate exact parent approval object.
"""

from __future__ import annotations

import base64
import hashlib
import json
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


SCRIPT = Path(__file__).resolve()
sys.path.insert(0, str(SCRIPT.parent))

import adapt_legacy_domain_packet as legacy_adapter  # noqa: E402
import pre_execution_gate  # noqa: E402
import validate_domain_packet as native_validator  # noqa: E402


PROJECTION_CONTRACT = "arlecchino-domain-alignment-1"
NATIVE_EVIDENCE_KIND = "native_v5_domain_1"
NATIVE_SELECTION_CONTRACT = "arlecchino-native-domain-source-selection-1"
NATIVE_SELECTION_KEYS = frozenset({
    "selection_contract",
    "selection_id",
    "selected_by_role",
    "authorized_parent_event_ref",
    "snapshot_id",
    "producer_root",
    "manifest_path",
    "manifest_sha256",
})
NATIVE_RECEIPT_KEYS = frozenset({
    "receipt_id",
    "evidence_kind",
    "rendered_packet_bytes",
    "rendered_packet_sha256",
    "packet",
    "validation_receipt",
    "source_selection",
})
MATERIAL_CONTEXT_KEYS = frozenset({
    "task_id",
    "workflow_epoch",
    "execution_snapshot_sha256",
    "user_request_sha256",
    "plan_sha256",
    "scope_sha256",
    "model_sha256",
    "data_sha256",
    "threshold_sha256",
})
ROUTE_BINDING_KEYS = frozenset({"receipt_id", "producer", "role", "primary_domain"})
ACTION_BINDING_KEYS = frozenset({
    "action_id",
    "action_stage",
    "join_kind",
    "receipt_id",
    "packet_action_stage",
    "legacy_required_question_indexes",
    "handoff_closure_receipt_id",
})
ACTION_JOIN_KINDS = frozenset({"entry_execution", "result_acceptance"})
HUMAN_RESOLUTION_CONTRACT = "arlecchino-domain-human-resolution-1"
HUMAN_RESOLUTION_KEYS = frozenset({
    "resolution_contract",
    "resolution_id",
    "receipt_id",
    "item_kind",
    "item_index",
    "source_item_sha256",
    "action_id",
    "action_stage",
    "material_context_sha256",
    "disposition",
    "evidence_refs",
    "authorized_parent_event_ref",
})
HANDOFF_CLOSURE_CONTRACT = "arlecchino-domain-handoff-closure-1"
HANDOFF_CLOSURE_KEYS = frozenset({
    "closure_contract",
    "closure_id",
    "receipt_id",
    "source_packet_sha256",
    "source_handoff_status",
    "action_id",
    "action_stage",
    "material_context_sha256",
    "evidence_refs",
    "authorized_parent_event_ref",
})
ROUTING_EXCEPTION_CONTRACT = "arlecchino-domain-routing-exception-1"
ROUTING_EXCEPTION_KEYS = frozenset({
    "exception_contract",
    "exception_id",
    "primary_domain",
    "borrowed_producers",
    "marginal_value_by_producer",
    "material_context_sha256",
    "authorized_parent_event_ref",
})
APPROVAL_KEYS = frozenset({
    "format",
    "approval_id",
    "authorized_user_event_ref",
    "issued_at",
    "expires_at",
    "task_id",
    "workflow_epoch",
    "digest_id",
    "digest_sha256",
    "plan_sha256",
    "scope_sha256",
    "action_classes_and_stages",
    "exact_roots_and_effects",
    "execution_snapshot_sha256",
    "domain_projection_refs_and_hashes",
    "workload_cost_budget_stop_and_recovery_limits",
    "authority_and_protected_permit_refs",
    "invalidation_triggers",
    "revoked",
    "state",
    "invalidation_evidence",
})
DOMAIN_PROJECTION_REF_KEYS = frozenset({"projection_ref", "projection_sha256"})
DOMAIN_PROJECTION_REF = "parent://arlecchino/domain-alignment"
PROJECTION_KEYS = frozenset({
    "projection_contract",
    "owner",
    "authoritative",
    "preapproval_execution_allowed",
    "material_context",
    "evidence",
    "route",
    "actions",
    "global_blockers",
    "alignment_status",
    "alignment_snapshot_sha256",
    "projection_sha256",
})
PROJECTION_EVIDENCE_KEYS = frozenset({
    "receipt_id",
    "evidence_kind",
    "producer",
    "packet_sha256",
})
PROJECTION_ROUTE_KEYS = frozenset({
    "status",
    "primary_domain",
    "bindings",
    "blockers",
    "routing_exception",
})
PROJECTION_ACTION_KEYS = frozenset({
    "action_id",
    "action_stage",
    "join_kind",
    "receipt_ids",
    "gate_results",
    "entry_blockers",
    "result_debt",
    "human_blockers",
    "human_resolutions",
    "handoff_blockers",
    "handoff_closures",
    "domain_eligible",
    "result_acceptance_eligible",
    "execution_state",
})
PROJECTION_GATE_RESULT_KEYS = frozenset({
    "receipt_id",
    "gate_id",
    "proof_phase",
    "verdict",
})
PROJECTION_HUMAN_RESOLUTION_KEYS = frozenset({
    "resolution_id",
    "receipt_id",
    "item_kind",
    "item_index",
})
PROJECTION_HANDOFF_CLOSURE_KEYS = frozenset({
    "closure_id",
    "receipt_id",
    "source_handoff_status",
})
PROJECTED_GATE_BLOCKER_CODES = frozenset({
    "DOMAIN_GATE_BLOCKED",
    "LEGACY_GATE_QUARANTINED",
})
HEX64 = frozenset("0123456789abcdef")


class ProjectionError(ValueError):
    """Deterministic rejection of malformed or mutated projection input."""


def sha256_bytes(payload: bytes) -> str:
    return hashlib.sha256(payload).hexdigest()


def canonical_json_bytes(value: Any) -> bytes:
    try:
        return json.dumps(
            value,
            ensure_ascii=False,
            allow_nan=False,
            sort_keys=True,
            separators=(",", ":"),
        ).encode("utf-8")
    except (TypeError, ValueError, UnicodeEncodeError) as exc:
        raise ProjectionError("value is not strict JSON") from exc


def _is_sha256(value: Any) -> bool:
    return isinstance(value, str) and len(value) == 64 and set(value) <= HEX64


def _canonical_nonblank(value: Any) -> bool:
    return isinstance(value, str) and bool(value.strip()) and value == value.strip()


def _exact_object(value: Any, keys: frozenset[str], label: str) -> dict[str, Any]:
    if not isinstance(value, dict) or set(value) != keys:
        raise ProjectionError(f"{label} has missing or extra fields")
    return value


def _blocker(code: str, **identity: Any) -> dict[str, Any]:
    result = {"code": code}
    result.update(identity)
    return result


def _dedupe_sorted(items: list[dict[str, Any]]) -> list[dict[str, Any]]:
    by_bytes = {canonical_json_bytes(item): item for item in items}
    return [by_bytes[key] for key in sorted(by_bytes)]


def issue_native_source_selection(
    *,
    producer_root: Path,
    manifest_path: Path,
    authorized_parent_event_ref: str,
) -> dict[str, Any]:
    """Create an explicit parent-owned selection for native V5 domain semantics."""

    producer_root = Path(producer_root).resolve()
    manifest_path = Path(manifest_path).resolve()
    if not _canonical_nonblank(authorized_parent_event_ref):
        raise ProjectionError("native source selection requires parent-event provenance")
    if not producer_root.is_dir() or not manifest_path.is_file():
        raise ProjectionError("native source selection paths are unavailable")
    manifest_sha256 = sha256_bytes(manifest_path.read_bytes())
    if manifest_sha256 != native_validator.PINNED_MANIFEST_SHA256:
        raise ProjectionError("native source selection manifest is not the pinned snapshot")
    core = {
        "selection_contract": NATIVE_SELECTION_CONTRACT,
        "selected_by_role": "coordinator",
        "authorized_parent_event_ref": authorized_parent_event_ref,
        "snapshot_id": native_validator.SNAPSHOT_ID,
        "producer_root": str(producer_root),
        "manifest_path": str(manifest_path),
        "manifest_sha256": manifest_sha256,
    }
    core["selection_id"] = sha256_bytes(canonical_json_bytes(core))
    return core


def validate_native_source_selection(selection: Any) -> dict[str, Any]:
    selection = _exact_object(selection, NATIVE_SELECTION_KEYS, "native source selection")
    if selection["selection_contract"] != NATIVE_SELECTION_CONTRACT:
        raise ProjectionError("native source selection contract mismatch")
    if selection["selected_by_role"] != "coordinator":
        raise ProjectionError("only the parent coordinator may select native domain semantics")
    if not _canonical_nonblank(selection["authorized_parent_event_ref"]):
        raise ProjectionError("native source selection lacks parent-event provenance")
    if selection["snapshot_id"] != native_validator.SNAPSHOT_ID:
        raise ProjectionError("native source selection snapshot mismatch")
    for field in ("selection_id", "manifest_sha256"):
        if not _is_sha256(selection[field]):
            raise ProjectionError(f"native source selection {field} must be SHA-256")
    producer_root = Path(selection["producer_root"])
    manifest_path = Path(selection["manifest_path"])
    if (
        not producer_root.is_absolute()
        or not manifest_path.is_absolute()
        or producer_root != producer_root.resolve()
        or manifest_path != manifest_path.resolve()
    ):
        raise ProjectionError("native source selection paths must be canonical absolute paths")
    expected = issue_native_source_selection(
        producer_root=producer_root,
        manifest_path=manifest_path,
        authorized_parent_event_ref=selection["authorized_parent_event_ref"],
    )
    if selection != expected:
        raise ProjectionError("native source selection integrity mismatch")
    return dict(selection)


def build_native_evidence_receipt(
    rendered_packet_bytes: bytes,
    *,
    receipt_id: str,
    source_selection: dict[str, Any],
) -> dict[str, Any]:
    """Validate exact native bytes and bind the validator receipt to them."""
    if not isinstance(rendered_packet_bytes, bytes):
        raise ProjectionError("native packet must be supplied as exact bytes")
    if not _canonical_nonblank(receipt_id):
        raise ProjectionError("receipt_id must be a canonical nonblank string")
    selection = validate_native_source_selection(source_selection)
    producer_root = Path(selection["producer_root"])
    manifest_path = Path(selection["manifest_path"])
    try:
        packet = native_validator.parse_json_bytes(rendered_packet_bytes)
        accepted = native_validator.validate_packet(
            packet,
            producer_root=producer_root,
            manifest_path=manifest_path,
        )
        validation = native_validator.validation_receipt(
            [accepted],
            mode="single",
            rendered_input_bytes=rendered_packet_bytes,
            manifest_path=manifest_path,
        )
    except (native_validator.ContractError, OSError) as exc:
        raise ProjectionError(f"native domain packet rejected: {exc}") from exc
    return {
        "receipt_id": receipt_id,
        "evidence_kind": NATIVE_EVIDENCE_KIND,
        "rendered_packet_bytes": rendered_packet_bytes,
        "rendered_packet_sha256": sha256_bytes(rendered_packet_bytes),
        "packet": packet,
        "validation_receipt": validation,
        "source_selection": selection,
    }


def validate_native_evidence_receipt(receipt: Any) -> dict[str, Any]:
    receipt = _exact_object(receipt, NATIVE_RECEIPT_KEYS, "native evidence receipt")
    expected = build_native_evidence_receipt(
        receipt["rendered_packet_bytes"],
        receipt_id=receipt["receipt_id"],
        source_selection=receipt["source_selection"],
    )
    if receipt != expected:
        raise ProjectionError("native evidence receipt was mutated after validation")
    return receipt


def _receipt_identity(receipt: dict[str, Any]) -> tuple[str, str, str, dict[str, Any]]:
    kind = receipt.get("evidence_kind")
    if kind == NATIVE_EVIDENCE_KIND:
        accepted = validate_native_evidence_receipt(receipt)
        packet = accepted["packet"]
        return (
            accepted["receipt_id"],
            packet["producer"]["subskill_name"],
            accepted["rendered_packet_sha256"],
            packet,
        )
    if kind == legacy_adapter.EVIDENCE_KIND:
        try:
            accepted = legacy_adapter.validate_legacy_receipt(receipt)
        except legacy_adapter.LegacyAdapterError as exc:
            raise ProjectionError(f"legacy evidence receipt rejected: {exc}") from exc
        identity = accepted["source_subskill_name_and_snapshot_fingerprint"]
        return (
            accepted["receipt_id"],
            identity["name"],
            accepted["legacy_packet_fingerprint"],
            accepted["legacy_packet_payload"],
        )
    raise ProjectionError("unknown domain evidence kind")


def _validate_material_context(value: Any) -> dict[str, Any]:
    value = _exact_object(value, MATERIAL_CONTEXT_KEYS, "material context")
    for key in MATERIAL_CONTEXT_KEYS - {"task_id", "workflow_epoch"}:
        if not _is_sha256(value[key]):
            raise ProjectionError(f"material context {key} must be a SHA-256 digest")
    for key in ("task_id", "workflow_epoch"):
        if not _canonical_nonblank(value[key]):
            raise ProjectionError(f"material context {key} must be canonical and nonblank")
    return dict(value)


def _context_sha256(value: dict[str, Any]) -> str:
    return sha256_bytes(canonical_json_bytes(_validate_material_context(value)))


def issue_human_resolution(
    *,
    receipt_id: str,
    item_kind: str,
    item_index: int,
    source_item: Any,
    action_id: str,
    action_stage: str,
    material_context: dict[str, Any],
    evidence_refs: list[str],
    authorized_parent_event_ref: str,
) -> dict[str, Any]:
    if item_kind not in {"native_human_delta", "legacy_question"}:
        raise ProjectionError("human resolution item kind is unsupported")
    if not isinstance(item_index, int) or isinstance(item_index, bool) or item_index < 0:
        raise ProjectionError("human resolution item index must be nonnegative")
    for value, field in (
        (receipt_id, "receipt_id"),
        (action_id, "action_id"),
        (action_stage, "action_stage"),
        (authorized_parent_event_ref, "authorized_parent_event_ref"),
    ):
        if not _canonical_nonblank(value):
            raise ProjectionError(f"human resolution {field} must be canonical and nonblank")
    _string_array(evidence_refs, "human resolution evidence_refs")
    if not evidence_refs:
        raise ProjectionError("human resolution requires evidence")
    core = {
        "resolution_contract": HUMAN_RESOLUTION_CONTRACT,
        "receipt_id": receipt_id,
        "item_kind": item_kind,
        "item_index": item_index,
        "source_item_sha256": sha256_bytes(canonical_json_bytes(source_item)),
        "action_id": action_id,
        "action_stage": action_stage,
        "material_context_sha256": _context_sha256(material_context),
        "disposition": "resolved",
        "evidence_refs": list(evidence_refs),
        "authorized_parent_event_ref": authorized_parent_event_ref,
    }
    core["resolution_id"] = sha256_bytes(canonical_json_bytes(core))
    return core


def validate_human_resolution(value: Any) -> dict[str, Any]:
    value = _exact_object(value, HUMAN_RESOLUTION_KEYS, "human resolution")
    if value["resolution_contract"] != HUMAN_RESOLUTION_CONTRACT:
        raise ProjectionError("human resolution contract mismatch")
    if value["item_kind"] not in {"native_human_delta", "legacy_question"}:
        raise ProjectionError("human resolution item kind is unsupported")
    if not isinstance(value["item_index"], int) or isinstance(value["item_index"], bool) or value["item_index"] < 0:
        raise ProjectionError("human resolution item index must be nonnegative")
    for field in ("receipt_id", "action_id", "action_stage", "authorized_parent_event_ref"):
        if not _canonical_nonblank(value[field]):
            raise ProjectionError(f"human resolution {field} must be canonical and nonblank")
    for field in ("resolution_id", "source_item_sha256", "material_context_sha256"):
        if not _is_sha256(value[field]):
            raise ProjectionError(f"human resolution {field} must be SHA-256")
    if value["disposition"] != "resolved":
        raise ProjectionError("human resolution disposition is unsupported")
    if not _string_array(value["evidence_refs"], "human resolution evidence_refs"):
        raise ProjectionError("human resolution requires evidence")
    core = dict(value)
    observed = core.pop("resolution_id")
    if sha256_bytes(canonical_json_bytes(core)) != observed:
        raise ProjectionError("human resolution integrity mismatch")
    return dict(value)


def issue_handoff_closure(
    *,
    receipt_id: str,
    source_packet_sha256: str,
    source_handoff_status: str,
    action_id: str,
    action_stage: str,
    material_context: dict[str, Any],
    evidence_refs: list[str],
    authorized_parent_event_ref: str,
) -> dict[str, Any]:
    if source_handoff_status not in {"partial", "blocked"}:
        raise ProjectionError("only a non-ready handoff needs a closure receipt")
    if not _is_sha256(source_packet_sha256):
        raise ProjectionError("handoff closure packet hash must be SHA-256")
    for value, field in (
        (receipt_id, "receipt_id"),
        (action_id, "action_id"),
        (action_stage, "action_stage"),
        (authorized_parent_event_ref, "authorized_parent_event_ref"),
    ):
        if not _canonical_nonblank(value):
            raise ProjectionError(f"handoff closure {field} must be canonical and nonblank")
    if not _string_array(evidence_refs, "handoff closure evidence_refs"):
        raise ProjectionError("handoff closure requires evidence")
    core = {
        "closure_contract": HANDOFF_CLOSURE_CONTRACT,
        "receipt_id": receipt_id,
        "source_packet_sha256": source_packet_sha256,
        "source_handoff_status": source_handoff_status,
        "action_id": action_id,
        "action_stage": action_stage,
        "material_context_sha256": _context_sha256(material_context),
        "evidence_refs": list(evidence_refs),
        "authorized_parent_event_ref": authorized_parent_event_ref,
    }
    core["closure_id"] = sha256_bytes(canonical_json_bytes(core))
    return core


def validate_handoff_closure(value: Any) -> dict[str, Any]:
    value = _exact_object(value, HANDOFF_CLOSURE_KEYS, "handoff closure")
    if value["closure_contract"] != HANDOFF_CLOSURE_CONTRACT:
        raise ProjectionError("handoff closure contract mismatch")
    if value["source_handoff_status"] not in {"partial", "blocked"}:
        raise ProjectionError("handoff closure source status is unsupported")
    for field in ("receipt_id", "action_id", "action_stage", "authorized_parent_event_ref"):
        if not _canonical_nonblank(value[field]):
            raise ProjectionError(f"handoff closure {field} must be canonical and nonblank")
    for field in ("closure_id", "source_packet_sha256", "material_context_sha256"):
        if not _is_sha256(value[field]):
            raise ProjectionError(f"handoff closure {field} must be SHA-256")
    if not _string_array(value["evidence_refs"], "handoff closure evidence_refs"):
        raise ProjectionError("handoff closure requires evidence")
    core = dict(value)
    observed = core.pop("closure_id")
    if sha256_bytes(canonical_json_bytes(core)) != observed:
        raise ProjectionError("handoff closure integrity mismatch")
    return dict(value)


def issue_routing_exception(
    *,
    primary_domain: str,
    borrowed_producers: list[str],
    marginal_value_by_producer: dict[str, str],
    material_context: dict[str, Any],
    authorized_parent_event_ref: str,
) -> dict[str, Any]:
    if not _canonical_nonblank(primary_domain) or not _canonical_nonblank(authorized_parent_event_ref):
        raise ProjectionError("routing exception requires primary and parent-event provenance")
    _string_array(borrowed_producers, "routing exception borrowed producers")
    if len(borrowed_producers) <= 2:
        raise ProjectionError("routing exception is unnecessary for two or fewer borrowed lenses")
    if (
        not isinstance(marginal_value_by_producer, dict)
        or set(marginal_value_by_producer) != set(borrowed_producers)
        or any(not _canonical_nonblank(value) for value in marginal_value_by_producer.values())
    ):
        raise ProjectionError("routing exception needs marginal value for every borrowed producer")
    core = {
        "exception_contract": ROUTING_EXCEPTION_CONTRACT,
        "primary_domain": primary_domain,
        "borrowed_producers": sorted(borrowed_producers),
        "marginal_value_by_producer": {
            key: marginal_value_by_producer[key] for key in sorted(marginal_value_by_producer)
        },
        "material_context_sha256": _context_sha256(material_context),
        "authorized_parent_event_ref": authorized_parent_event_ref,
    }
    core["exception_id"] = sha256_bytes(canonical_json_bytes(core))
    return core


def validate_routing_exception(value: Any) -> dict[str, Any]:
    value = _exact_object(value, ROUTING_EXCEPTION_KEYS, "routing exception")
    if value["exception_contract"] != ROUTING_EXCEPTION_CONTRACT:
        raise ProjectionError("routing exception contract mismatch")
    if not _canonical_nonblank(value["primary_domain"]) or not _canonical_nonblank(
        value["authorized_parent_event_ref"]
    ):
        raise ProjectionError("routing exception lacks primary or parent-event provenance")
    borrowed = _string_array(value["borrowed_producers"], "routing exception borrowed producers")
    if len(borrowed) <= 2 or borrowed != sorted(borrowed):
        raise ProjectionError("routing exception borrowed producers must be sorted and exceed two")
    marginal = value["marginal_value_by_producer"]
    if (
        not isinstance(marginal, dict)
        or set(marginal) != set(borrowed)
        or any(not _canonical_nonblank(item) for item in marginal.values())
    ):
        raise ProjectionError("routing exception needs marginal value for every borrowed producer")
    for field in ("exception_id", "material_context_sha256"):
        if not _is_sha256(value[field]):
            raise ProjectionError(f"routing exception {field} must be SHA-256")
    core = dict(value)
    observed = core.pop("exception_id")
    if sha256_bytes(canonical_json_bytes(core)) != observed:
        raise ProjectionError("routing exception integrity mismatch")
    return dict(value)


def _validate_route_binding(value: Any) -> dict[str, Any]:
    value = _exact_object(value, ROUTE_BINDING_KEYS, "route binding")
    for key in ("receipt_id", "producer", "primary_domain"):
        if not _canonical_nonblank(value[key]):
            raise ProjectionError(f"route binding {key} must be canonical and nonblank")
    if value["role"] not in {"primary", "borrowed"}:
        raise ProjectionError("route binding role is unsupported")
    return dict(value)


def _validate_action_binding(value: Any) -> dict[str, Any]:
    value = _exact_object(value, ACTION_BINDING_KEYS, "action binding")
    for key in ("action_id", "action_stage", "receipt_id", "packet_action_stage"):
        if not _canonical_nonblank(value[key]):
            raise ProjectionError(f"action binding {key} must be canonical and nonblank")
    if value["join_kind"] not in ACTION_JOIN_KINDS:
        raise ProjectionError("action binding join_kind is unsupported")
    indexes = value["legacy_required_question_indexes"]
    if (
        not isinstance(indexes, list)
        or any(not isinstance(index, int) or isinstance(index, bool) or index < 0 for index in indexes)
        or len(indexes) != len(set(indexes))
    ):
        raise ProjectionError("legacy required-question indexes must be unique nonnegative integers")
    closure = value["handoff_closure_receipt_id"]
    if closure is not None and not _canonical_nonblank(closure):
        raise ProjectionError("handoff closure receipt ID must be null or canonical text")
    return dict(value)


def _gate_structure(packet: dict[str, Any], kind: str) -> list[Any]:
    gates = packet.get("domain_gates")
    if not isinstance(gates, list):
        if kind == NATIVE_EVIDENCE_KIND:
            raise ProjectionError("validated native packet lost domain_gates")
        return []
    return gates


def _packet_route(packet: dict[str, Any], kind: str) -> tuple[Any, Any, Any]:
    if kind == NATIVE_EVIDENCE_KIND:
        routing = packet["routing"]
        return routing["role"], routing["primary_domain"], packet["handoff_status"]
    return packet.get("routing_role"), packet.get("primary_domain"), packet.get("handoff_status")


def _legacy_gate_verdict(gate: Any) -> tuple[str, str | None, str | None, str | None]:
    """Return verdict, stage, phase, and gate id without coercing unsupported values."""
    if not isinstance(gate, dict):
        return "quarantined", None, None, None
    gate_id = gate.get("gate_id") if _canonical_nonblank(gate.get("gate_id")) else None
    stage = gate.get("action_stage") if _canonical_nonblank(gate.get("action_stage")) else None
    phase = gate.get("proof_phase") if gate.get("proof_phase") in {"entry", "result"} else None
    applicability = gate.get("applicability")
    decision = gate.get("decision")
    applicability_refs = gate.get("applicability_evidence_refs")
    reopen = gate.get("reopen_or_invalidation_trigger")
    if gate_id is None or stage is None or phase is None:
        return "quarantined", stage, phase, gate_id
    if not isinstance(applicability_refs, list) or not applicability_refs:
        return "quarantined", stage, phase, gate_id
    if not isinstance(reopen, list) or not reopen:
        return "quarantined", stage, phase, gate_id
    if applicability == "not_applicable":
        return (
            ("not_applicable" if decision == "not_applicable" else "quarantined"),
            stage,
            phase,
            gate_id,
        )
    if applicability == "unresolved":
        return "quarantined", stage, phase, gate_id
    if applicability != "applicable":
        return "quarantined", stage, phase, gate_id
    if decision == "pass":
        refs = gate.get("evidence_refs")
        if isinstance(refs, list) and refs:
            return "passed", stage, phase, gate_id
        return "quarantined", stage, phase, gate_id
    if decision in {"fail", "escalate", "blocked", "open"}:
        return "blocked", stage, phase, gate_id
    return "quarantined", stage, phase, gate_id


def _native_gate_verdict(gate: dict[str, Any]) -> str:
    if gate["applicability"] == "not_applicable":
        return "not_applicable"
    if gate["decision"] == "pass":
        return "passed"
    return "blocked"


def _action_template(
    action_id: str, action_stage: str, join_kind: str
) -> dict[str, Any]:
    return {
        "action_id": action_id,
        "action_stage": action_stage,
        "join_kind": join_kind,
        "receipt_ids": [],
        "gate_results": [],
        "entry_blockers": [],
        "result_debt": [],
        "human_blockers": [],
        "human_resolutions": [],
        "handoff_blockers": [],
        "handoff_closures": [],
        "domain_eligible": False,
        "result_acceptance_eligible": False,
        "execution_state": "BLOCKED",
    }


def _projection_hash_source(projection: dict[str, Any]) -> dict[str, Any]:
    """Return the approval-independent domain core.

    ``plan_sha256`` and ``scope_sha256`` are excluded because the canonical
    digest's plan hash already contains its domain-projection references.
    Including either here would create a circular hash.  The canonical
    approval binds both fields separately at dispatch.
    """
    context = {
        key: value
        for key, value in projection["material_context"].items()
        if key not in {"plan_sha256", "scope_sha256"}
    }
    return {
        "projection_contract": projection["projection_contract"],
        "owner": projection["owner"],
        "authoritative": projection["authoritative"],
        "preapproval_execution_allowed": projection["preapproval_execution_allowed"],
        "material_context_without_plan_or_scope": context,
        "evidence": projection["evidence"],
        "route": projection["route"],
        "actions": projection["actions"],
        "global_blockers": projection["global_blockers"],
        "alignment_status": projection["alignment_status"],
    }


def _validate_projected_blockers(value: Any, label: str) -> list[dict[str, Any]]:
    if not isinstance(value, list) or any(not isinstance(item, dict) for item in value):
        raise ProjectionError(f"{label} must be an array of blocker objects")
    blockers = [dict(item) for item in value]
    for blocker in blockers:
        if not _canonical_nonblank(blocker.get("code")):
            raise ProjectionError(f"{label} blocker requires a canonical code")
        canonical_json_bytes(blocker)
    if blockers != _dedupe_sorted(blockers):
        raise ProjectionError(f"{label} blockers must be unique and canonical-sorted")
    return blockers


def _gate_blocker_identities(
    blockers: list[dict[str, Any]], label: str
) -> set[tuple[str, str, str]]:
    identities: set[tuple[str, str, str]] = set()
    for blocker in blockers:
        if blocker["code"] not in PROJECTED_GATE_BLOCKER_CODES:
            raise ProjectionError(f"{label} contains a non-gate blocker")
        receipt_id = blocker.get("receipt_id")
        gate_id = blocker.get("gate_id")
        gate_index = blocker.get("gate_index")
        if (
            not _canonical_nonblank(receipt_id)
            or not _canonical_nonblank(gate_id)
            or not isinstance(gate_index, int)
            or isinstance(gate_index, bool)
            or gate_index < 0
        ):
            raise ProjectionError(f"{label} gate blocker identity is malformed")
        identities.add((blocker["code"], receipt_id, gate_id))
    if len(identities) != len(blockers):
        raise ProjectionError(f"{label} contains duplicate gate blocker identities")
    return identities


def _validate_projected_action(
    action_key: str,
    value: Any,
    *,
    evidence_receipt_ids: set[str],
    global_blockers: list[dict[str, Any]],
) -> dict[str, Any]:
    action = _exact_object(value, PROJECTION_ACTION_KEYS, "projected action")
    if not _canonical_nonblank(action_key) or action["action_id"] != action_key:
        raise ProjectionError("projected action key and action_id disagree")
    if not _canonical_nonblank(action["action_stage"]):
        raise ProjectionError("projected action stage must be canonical and nonblank")
    if action["join_kind"] not in ACTION_JOIN_KINDS:
        raise ProjectionError("projected action join_kind is unsupported")

    receipt_ids = action["receipt_ids"]
    if (
        not isinstance(receipt_ids, list)
        or not receipt_ids
        or any(not _canonical_nonblank(item) for item in receipt_ids)
        or receipt_ids != sorted(set(receipt_ids))
        or not set(receipt_ids) <= evidence_receipt_ids
    ):
        raise ProjectionError("projected action receipt_ids are invalid")

    gate_results = action["gate_results"]
    if not isinstance(gate_results, list):
        raise ProjectionError("projected action gate_results must be an array")
    normalized_gate_results: list[dict[str, Any]] = []
    for raw in gate_results:
        result = _exact_object(raw, PROJECTION_GATE_RESULT_KEYS, "projected gate result")
        if (
            not _canonical_nonblank(result["receipt_id"])
            or result["receipt_id"] not in receipt_ids
            or not _canonical_nonblank(result["gate_id"])
            or result["proof_phase"] not in {"entry", "result"}
            or result["verdict"]
            not in {"passed", "not_applicable", "blocked", "quarantined"}
        ):
            raise ProjectionError("projected gate result is malformed")
        normalized_gate_results.append(dict(result))
    if normalized_gate_results != _dedupe_sorted(normalized_gate_results):
        raise ProjectionError("projected gate results must be unique and canonical-sorted")

    entry_blockers = _validate_projected_blockers(
        action["entry_blockers"], "projected entry blockers"
    )
    result_debt = _validate_projected_blockers(
        action["result_debt"], "projected result debt"
    )
    expected_entry: set[tuple[str, str, str]] = set()
    expected_result: set[tuple[str, str, str]] = set()
    for result in normalized_gate_results:
        if result["verdict"] not in {"blocked", "quarantined"}:
            continue
        code = (
            "DOMAIN_GATE_BLOCKED"
            if result["verdict"] == "blocked"
            else "LEGACY_GATE_QUARANTINED"
        )
        identity = (code, result["receipt_id"], result["gate_id"])
        (expected_entry if result["proof_phase"] == "entry" else expected_result).add(
            identity
        )
    if _gate_blocker_identities(entry_blockers, "projected entry blockers") != expected_entry:
        raise ProjectionError("projected entry blockers disagree with gate results")
    if _gate_blocker_identities(result_debt, "projected result debt") != expected_result:
        raise ProjectionError("projected result debt disagrees with gate results")

    human_blockers = _validate_projected_blockers(
        action["human_blockers"], "projected human blockers"
    )
    handoff_blockers = _validate_projected_blockers(
        action["handoff_blockers"], "projected handoff blockers"
    )
    for label, blockers in (
        ("projected human blockers", human_blockers),
        ("projected handoff blockers", handoff_blockers),
    ):
        if any(
            blocker.get("receipt_id") not in receipt_ids
            for blocker in blockers
        ):
            raise ProjectionError(f"{label} references an unbound receipt")

    resolutions = action["human_resolutions"]
    if not isinstance(resolutions, list):
        raise ProjectionError("projected human resolutions must be an array")
    normalized_resolutions: list[dict[str, Any]] = []
    for raw in resolutions:
        item = _exact_object(
            raw, PROJECTION_HUMAN_RESOLUTION_KEYS, "projected human resolution"
        )
        if (
            not _is_sha256(item["resolution_id"])
            or item["receipt_id"] not in receipt_ids
            or item["item_kind"] not in {"native_human_delta", "legacy_question"}
            or not isinstance(item["item_index"], int)
            or isinstance(item["item_index"], bool)
            or item["item_index"] < 0
        ):
            raise ProjectionError("projected human resolution is malformed")
        normalized_resolutions.append(dict(item))
    if normalized_resolutions != _dedupe_sorted(normalized_resolutions):
        raise ProjectionError("projected human resolutions must be unique and canonical-sorted")

    closures = action["handoff_closures"]
    if not isinstance(closures, list):
        raise ProjectionError("projected handoff closures must be an array")
    normalized_closures: list[dict[str, Any]] = []
    for raw in closures:
        item = _exact_object(
            raw, PROJECTION_HANDOFF_CLOSURE_KEYS, "projected handoff closure"
        )
        if (
            not _is_sha256(item["closure_id"])
            or item["receipt_id"] not in receipt_ids
            or item["source_handoff_status"] not in {"partial", "blocked"}
        ):
            raise ProjectionError("projected handoff closure is malformed")
        normalized_closures.append(dict(item))
    if normalized_closures != _dedupe_sorted(normalized_closures):
        raise ProjectionError("projected handoff closures must be unique and canonical-sorted")

    if not isinstance(action["domain_eligible"], bool) or not isinstance(
        action["result_acceptance_eligible"], bool
    ):
        raise ProjectionError("projected action eligibility must be boolean")
    expected_domain_eligible = not bool(
        global_blockers or entry_blockers or human_blockers or handoff_blockers
    )
    if action["domain_eligible"] is not expected_domain_eligible:
        raise ProjectionError("projected domain eligibility contradicts blockers")
    expected_result_eligible = expected_domain_eligible and not result_debt
    if action["result_acceptance_eligible"] is not expected_result_eligible:
        raise ProjectionError("projected result eligibility contradicts result debt")
    expected_execution_state = (
        "AWAITING_APPROVAL" if expected_domain_eligible else "BLOCKED"
    )
    if action["execution_state"] != expected_execution_state:
        raise ProjectionError("projected execution state contradicts eligibility")
    return dict(action)


def project_domain_alignment(
    *,
    evidence_receipts: list[dict[str, Any]],
    route_bindings: list[dict[str, Any]],
    action_bindings: list[dict[str, Any]],
    material_context: dict[str, Any],
    human_resolution_receipts: list[dict[str, Any]] | None = None,
    handoff_closure_receipts: list[dict[str, Any]] | None = None,
    routing_exception: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """Create a deterministic parent projection; never join execution approval."""
    if not isinstance(evidence_receipts, list) or not evidence_receipts:
        raise ProjectionError("at least one evidence receipt is required")
    if not isinstance(route_bindings, list) or not isinstance(action_bindings, list):
        raise ProjectionError("route and action bindings must be arrays")
    context = _validate_material_context(material_context)
    context_sha = _context_sha256(context)
    resolutions = [
        validate_human_resolution(item)
        for item in (human_resolution_receipts or [])
    ]
    closures = [
        validate_handoff_closure(item)
        for item in (handoff_closure_receipts or [])
    ]
    if len({item["resolution_id"] for item in resolutions}) != len(resolutions):
        raise ProjectionError("duplicate human resolution receipt")
    if len({item["closure_id"] for item in closures}) != len(closures):
        raise ProjectionError("duplicate handoff closure receipt")
    if any(item["material_context_sha256"] != context_sha for item in resolutions + closures):
        raise ProjectionError("domain closure/resolution receipt belongs to another context")
    resolution_by_identity: dict[tuple[Any, ...], list[dict[str, Any]]] = {}
    for item in resolutions:
        identity = (
            item["receipt_id"],
            item["item_kind"],
            item["item_index"],
            item["source_item_sha256"],
            item["action_id"],
            item["action_stage"],
        )
        resolution_by_identity.setdefault(identity, []).append(item)
    closure_by_id = {item["closure_id"]: item for item in closures}
    used_resolution_ids: set[str] = set()
    used_closure_ids: set[str] = set()
    exception = None if routing_exception is None else validate_routing_exception(routing_exception)
    if exception is not None and exception["material_context_sha256"] != context_sha:
        raise ProjectionError("routing exception belongs to another material context")

    receipts: dict[str, dict[str, Any]] = {}
    identities: dict[str, dict[str, Any]] = {}
    packets: dict[str, dict[str, Any]] = {}
    for receipt in evidence_receipts:
        receipt_id, producer, packet_sha, packet = _receipt_identity(receipt)
        if receipt_id in receipts:
            raise ProjectionError("duplicate evidence receipt_id")
        receipts[receipt_id] = receipt
        packets[receipt_id] = packet
        identities[receipt_id] = {
            "receipt_id": receipt_id,
            "evidence_kind": receipt["evidence_kind"],
            "producer": producer,
            "packet_sha256": packet_sha,
        }

    routes = [_validate_route_binding(value) for value in route_bindings]
    actions_in = [_validate_action_binding(value) for value in action_bindings]
    global_blockers: list[dict[str, Any]] = []

    route_receipts = [binding["receipt_id"] for binding in routes]
    route_producers = [binding["producer"] for binding in routes]
    if set(route_receipts) != set(receipts) or len(route_receipts) != len(set(route_receipts)):
        global_blockers.append(_blocker("ROUTE_RECEIPT_SET_MISSING_OR_DUPLICATE"))
    if len(route_producers) != len(set(route_producers)):
        global_blockers.append(_blocker("ROUTE_PRODUCER_DUPLICATE"))
    primaries = [binding for binding in routes if binding["role"] == "primary"]
    primary_domain = primaries[0]["producer"] if len(primaries) == 1 else None
    if len(primaries) != 1:
        global_blockers.append(_blocker("ROUTE_REQUIRES_EXACTLY_ONE_PRIMARY"))
    borrowed_producers = sorted(
        binding["producer"] for binding in routes if binding["role"] == "borrowed"
    )
    if len(borrowed_producers) > 2:
        valid_exception = bool(
            exception
            and exception["primary_domain"] == primary_domain
            and exception["borrowed_producers"] == borrowed_producers
        )
        if not valid_exception:
            global_blockers.append(_blocker("BORROWED_LENS_LIMIT_EXCEEDED"))
    elif exception is not None:
        global_blockers.append(_blocker("ROUTING_EXCEPTION_UNNECESSARY"))
    for binding in routes:
        receipt_id = binding["receipt_id"]
        if receipt_id not in receipts:
            global_blockers.append(_blocker("ROUTE_UNKNOWN_RECEIPT", receipt_id=receipt_id))
            continue
        identity = identities[receipt_id]
        if binding["producer"] != identity["producer"]:
            global_blockers.append(_blocker("ROUTE_PRODUCER_IDENTITY_MISMATCH", receipt_id=receipt_id))
        if primary_domain is not None and binding["primary_domain"] != primary_domain:
            global_blockers.append(_blocker("ROUTE_PRIMARY_DOMAIN_INCONSISTENT", receipt_id=receipt_id))
        packet_role, packet_primary, _handoff = _packet_route(
            packets[receipt_id], identity["evidence_kind"]
        )
        if packet_role != binding["role"] or packet_primary != binding["primary_domain"]:
            global_blockers.append(_blocker("ROUTE_PACKET_BINDING_MISMATCH", receipt_id=receipt_id))

    binding_by_packet_stage: dict[tuple[str, str], tuple[str, str]] = {}
    action_signature_by_id: dict[str, tuple[str, str]] = {}
    action_objects: dict[str, dict[str, Any]] = {}
    bindings_by_receipt: dict[str, list[dict[str, Any]]] = {key: [] for key in receipts}
    legacy_question_bindings: dict[tuple[str, int], set[str]] = {}
    for binding in actions_in:
        receipt_id = binding["receipt_id"]
        action_id, action_stage = binding["action_id"], binding["action_stage"]
        join_kind = binding["join_kind"]
        if receipt_id not in receipts:
            global_blockers.append(_blocker("ACTION_UNKNOWN_RECEIPT", receipt_id=receipt_id))
            continue
        signature = (action_stage, join_kind)
        previous_signature = action_signature_by_id.setdefault(action_id, signature)
        if previous_signature != signature:
            global_blockers.append(
                _blocker("ACTION_ID_BINDING_AMBIGUOUS", action_id=action_id)
            )
        action = action_objects.setdefault(
            action_id, _action_template(action_id, action_stage, join_kind)
        )
        action["receipt_ids"].append(receipt_id)
        bindings_by_receipt[receipt_id].append(binding)
        packet_key = (receipt_id, binding["packet_action_stage"])
        action_key = (action_id, action_stage)
        if packet_key in binding_by_packet_stage:
            global_blockers.append(_blocker(
                "ACTION_PACKET_STAGE_AMBIGUOUS",
                receipt_id=receipt_id,
                packet_action_stage=binding["packet_action_stage"],
            ))
        else:
            binding_by_packet_stage[packet_key] = action_key
        for index in binding["legacy_required_question_indexes"]:
            legacy_question_bindings.setdefault((receipt_id, index), set()).add(action_id)

    # Every packet gate must have one explicit packet-stage -> parent-action edge.
    for receipt_id, packet in packets.items():
        kind = identities[receipt_id]["evidence_kind"]
        for gate in _gate_structure(packet, kind):
            if kind == NATIVE_EVIDENCE_KIND:
                packet_stage = gate["action_stage"]
            else:
                _verdict, packet_stage, _phase, _gate_id = _legacy_gate_verdict(gate)
                if packet_stage is None:
                    global_blockers.append(_blocker("LEGACY_GATE_QUARANTINED", receipt_id=receipt_id))
                    continue
            if (receipt_id, packet_stage) not in binding_by_packet_stage:
                global_blockers.append(_blocker(
                    "ACTION_BINDING_MISSING",
                    receipt_id=receipt_id,
                    packet_action_stage=packet_stage,
                ))

    # Project gates only after explicit binding; borrowed and primary verdicts join
    # on the same parent action, so any stricter applicable veto wins.
    gate_token_bindings: dict[tuple[str, str], set[str]] = {}
    for (receipt_id, packet_stage), (action_id, _action_stage) in binding_by_packet_stage.items():
        gate_token_bindings.setdefault((receipt_id, packet_stage), set()).add(action_id)
    for receipt_id, packet in packets.items():
        kind = identities[receipt_id]["evidence_kind"]
        for gate_index, gate in enumerate(_gate_structure(packet, kind)):
            if kind == NATIVE_EVIDENCE_KIND:
                verdict = _native_gate_verdict(gate)
                packet_stage, phase, gate_id = gate["action_stage"], gate["proof_phase"], gate["gate_id"]
            else:
                verdict, packet_stage, phase, gate_id = _legacy_gate_verdict(gate)
                if packet_stage is None or phase is None or gate_id is None:
                    continue
            action_key = binding_by_packet_stage.get((receipt_id, packet_stage))
            if action_key is None:
                continue
            action_id, _action_stage = action_key
            action = action_objects[action_id]
            result = {
                "receipt_id": receipt_id,
                "gate_id": gate_id,
                "proof_phase": phase,
                "verdict": verdict,
            }
            action["gate_results"].append(result)
            gate_token_bindings.setdefault((receipt_id, gate_id), set()).add(action_id)
            if verdict in {"blocked", "quarantined"}:
                blocker = _blocker(
                    "DOMAIN_GATE_BLOCKED" if verdict == "blocked" else "LEGACY_GATE_QUARANTINED",
                    receipt_id=receipt_id,
                    gate_id=gate_id,
                    gate_index=gate_index,
                )
                if phase == "entry":
                    action["entry_blockers"].append(blocker)
                else:
                    action["result_debt"].append(blocker)

    # Native human blockers are mapped by exact action-stage or gate-id tokens.
    # A parent-owned typed resolution can close only the exact source item,
    # parent action/stage, material context, and evidence receipt it names.
    for receipt_id, packet in packets.items():
        kind = identities[receipt_id]["evidence_kind"]
        if kind != NATIVE_EVIDENCE_KIND:
            continue
        for human_index, item in enumerate(packet["human_input_deltas"]):
            if item.get("applicability") == "not_applicable":
                continue
            affected = item["decisions_actions_gates_affected"]
            mapped: set[str] = set()
            ambiguous = False
            for token in affected:
                candidates = gate_token_bindings.get((receipt_id, token), set())
                if len(candidates) != 1:
                    ambiguous = True
                mapped.update(candidates)
            if ambiguous or not mapped:
                global_blockers.append(_blocker(
                    "HUMAN_INPUT_BINDING_MISSING_OR_AMBIGUOUS",
                    receipt_id=receipt_id,
                    human_index=human_index,
                ))
                continue
            for action_id in mapped:
                action = action_objects[action_id]
                identity = (
                    receipt_id,
                    "native_human_delta",
                    human_index,
                    sha256_bytes(canonical_json_bytes(item)),
                    action_id,
                    action["action_stage"],
                )
                matches = resolution_by_identity.get(identity, [])
                if len(matches) == 1:
                    resolution = matches[0]
                    used_resolution_ids.add(resolution["resolution_id"])
                    action["human_resolutions"].append({
                        "resolution_id": resolution["resolution_id"],
                        "receipt_id": receipt_id,
                        "item_kind": "native_human_delta",
                        "item_index": human_index,
                    })
                else:
                    action["human_blockers"].append(_blocker(
                        "HUMAN_INPUT_RESOLUTION_AMBIGUOUS" if matches else "HUMAN_INPUT_UNRESOLVED",
                        receipt_id=receipt_id,
                        human_index=human_index,
                    ))

    # Legacy questions remain opaque.  Only explicit numeric bindings can map
    # them; their free-form text is never interpreted as authority or approval.
    for receipt_id, packet in packets.items():
        if identities[receipt_id]["evidence_kind"] != legacy_adapter.EVIDENCE_KIND:
            continue
        questions = packet.get("required_questions", [])
        if not isinstance(questions, list):
            global_blockers.append(_blocker("LEGACY_REQUIRED_QUESTIONS_QUARANTINED", receipt_id=receipt_id))
            continue
        for index, _question in enumerate(questions):
            mapped = legacy_question_bindings.get((receipt_id, index), set())
            if len(mapped) != 1:
                global_blockers.append(_blocker(
                    "LEGACY_HUMAN_BINDING_MISSING_OR_AMBIGUOUS",
                    receipt_id=receipt_id,
                    question_index=index,
                ))
                continue
            action_id = next(iter(mapped))
            action = action_objects[action_id]
            identity = (
                receipt_id,
                "legacy_question",
                index,
                sha256_bytes(canonical_json_bytes(_question)),
                action_id,
                action["action_stage"],
            )
            matches = resolution_by_identity.get(identity, [])
            if len(matches) == 1:
                resolution = matches[0]
                used_resolution_ids.add(resolution["resolution_id"])
                action["human_resolutions"].append({
                    "resolution_id": resolution["resolution_id"],
                    "receipt_id": receipt_id,
                    "item_kind": "legacy_question",
                    "item_index": index,
                })
            else:
                action["human_blockers"].append(_blocker(
                    "LEGACY_HUMAN_RESOLUTION_AMBIGUOUS"
                    if matches else "LEGACY_HUMAN_INPUT_UNRESOLVED",
                    receipt_id=receipt_id,
                    question_index=index,
                ))
        extra_indexes = sorted(
            index for candidate_receipt, index in legacy_question_bindings
            if candidate_receipt == receipt_id and index >= len(questions)
        )
        if extra_indexes:
            global_blockers.append(_blocker(
                "LEGACY_HUMAN_BINDING_OUT_OF_RANGE",
                receipt_id=receipt_id,
            ))

    # A non-ready producer handoff blocks each affected stage unless a parent
    # supplied a typed receipt closing this exact packet/status/action/context.
    for receipt_id, packet in packets.items():
        kind = identities[receipt_id]["evidence_kind"]
        _role, _primary, handoff = _packet_route(packet, kind)
        if handoff not in {"ready", "partial", "blocked"}:
            global_blockers.append(_blocker("HANDOFF_STATUS_QUARANTINED", receipt_id=receipt_id))
            continue
        if handoff == "ready":
            continue
        if not bindings_by_receipt[receipt_id]:
            global_blockers.append(_blocker("HANDOFF_STAGE_BINDING_MISSING", receipt_id=receipt_id))
        for binding in bindings_by_receipt[receipt_id]:
            action = action_objects[binding["action_id"]]
            closure_id = binding["handoff_closure_receipt_id"]
            closure = closure_by_id.get(closure_id) if closure_id is not None else None
            exact = bool(
                closure
                and closure["receipt_id"] == receipt_id
                and closure["source_packet_sha256"] == identities[receipt_id]["packet_sha256"]
                and closure["source_handoff_status"] == handoff
                and closure["action_id"] == binding["action_id"]
                and closure["action_stage"] == binding["action_stage"]
            )
            if exact:
                used_closure_ids.add(closure["closure_id"])
                action["handoff_closures"].append({
                    "closure_id": closure["closure_id"],
                    "receipt_id": receipt_id,
                    "source_handoff_status": handoff,
                })
            else:
                action["handoff_blockers"].append(_blocker(
                    "HANDOFF_CLOSURE_MISMATCH" if closure_id is not None else "HANDOFF_STAGE_NOT_CLOSED",
                    receipt_id=receipt_id,
                    handoff_status=handoff,
                ))

    for resolution in resolutions:
        if resolution["resolution_id"] not in used_resolution_ids:
            global_blockers.append(_blocker(
                "HUMAN_RESOLUTION_UNUSED_OR_MISMATCHED",
                resolution_id=resolution["resolution_id"],
            ))
    for closure in closures:
        if closure["closure_id"] not in used_closure_ids:
            global_blockers.append(_blocker(
                "HANDOFF_CLOSURE_UNUSED_OR_MISMATCHED",
                closure_id=closure["closure_id"],
            ))

    global_blockers = _dedupe_sorted(global_blockers)
    for action in action_objects.values():
        for key in ("receipt_ids",):
            action[key] = sorted(set(action[key]))
        for key in (
            "gate_results",
            "entry_blockers",
            "result_debt",
            "human_blockers",
            "human_resolutions",
            "handoff_blockers",
            "handoff_closures",
        ):
            action[key] = _dedupe_sorted(action[key])
        local_blocked = bool(
            action["entry_blockers"] or action["human_blockers"] or action["handoff_blockers"]
        )
        action["domain_eligible"] = not global_blockers and not local_blocked
        action["result_acceptance_eligible"] = action["domain_eligible"] and not action["result_debt"]
        action["execution_state"] = "AWAITING_APPROVAL" if action["domain_eligible"] else "BLOCKED"

    route = {
        "status": "aligned" if not global_blockers else "blocked",
        "primary_domain": primary_domain,
        "bindings": sorted(routes, key=lambda item: canonical_json_bytes(item)),
        "blockers": [
            blocker for blocker in global_blockers if blocker["code"].startswith("ROUTE_")
            or blocker["code"] == "BORROWED_LENS_LIMIT_EXCEEDED"
        ],
        "routing_exception": exception,
    }
    evidence = sorted(identities.values(), key=lambda item: item["receipt_id"])
    normalized_actions = {
        key: action_objects[key] for key in sorted(action_objects)
    }
    snapshot_source = {
        "projection_contract": PROJECTION_CONTRACT,
        "material_context": context,
        "evidence": evidence,
        "route_bindings": route["bindings"],
        "action_bindings": sorted(actions_in, key=lambda item: canonical_json_bytes(item)),
        "human_resolution_receipts": sorted(
            resolutions, key=lambda item: item["resolution_id"]
        ),
        "handoff_closure_receipts": sorted(
            closures, key=lambda item: item["closure_id"]
        ),
        "routing_exception": exception,
    }
    alignment_snapshot = sha256_bytes(canonical_json_bytes(snapshot_source))
    projection: dict[str, Any] = {
        "projection_contract": PROJECTION_CONTRACT,
        "owner": "parent",
        "authoritative": False,
        "preapproval_execution_allowed": False,
        "material_context": context,
        "evidence": evidence,
        "route": route,
        "actions": normalized_actions,
        "global_blockers": global_blockers,
        "alignment_status": "aligned" if not global_blockers else "blocked",
        "alignment_snapshot_sha256": alignment_snapshot,
    }
    projection["projection_sha256"] = sha256_bytes(
        canonical_json_bytes(_projection_hash_source(projection))
    )
    return projection


def validate_projection_integrity(
    projection: Any,
    *,
    expected_material_context: dict[str, Any] | None = None,
    expected_alignment_snapshot_sha256: str | None = None,
) -> dict[str, Any]:
    """Validate the immutable core and, when supplied, current parent bindings.

    The projection core deliberately excludes plan/scope hashes to avoid a
    digest↔projection hash cycle. Dispatch-facing callers must therefore supply
    the current parent context and the separately retained alignment snapshot.
    """
    projection = _exact_object(projection, PROJECTION_KEYS, "domain alignment projection")
    if projection["projection_contract"] != PROJECTION_CONTRACT:
        raise ProjectionError("projection contract mismatch")
    if projection["owner"] != "parent" or projection["authoritative"] is not False:
        raise ProjectionError("domain projection claimed authority")
    if projection["preapproval_execution_allowed"] is not False:
        raise ProjectionError("projection attempted to authorize preapproval execution")
    material_context = _validate_material_context(projection["material_context"])
    evidence = projection["evidence"]
    if not isinstance(evidence, list) or not evidence:
        raise ProjectionError("projection evidence must be a nonempty array")
    normalized_evidence: list[dict[str, Any]] = []
    for raw in evidence:
        item = _exact_object(raw, PROJECTION_EVIDENCE_KEYS, "projection evidence item")
        if (
            not _canonical_nonblank(item["receipt_id"])
            or item["evidence_kind"]
            not in {NATIVE_EVIDENCE_KIND, legacy_adapter.EVIDENCE_KIND}
            or not _canonical_nonblank(item["producer"])
            or not _is_sha256(item["packet_sha256"])
        ):
            raise ProjectionError("projection evidence identity is malformed")
        normalized_evidence.append(dict(item))
    if normalized_evidence != sorted(
        normalized_evidence, key=lambda item: item["receipt_id"]
    ):
        raise ProjectionError("projection evidence must be receipt-id-sorted")
    evidence_receipt_ids = {item["receipt_id"] for item in normalized_evidence}
    if len(evidence_receipt_ids) != len(normalized_evidence):
        raise ProjectionError("projection evidence receipt IDs must be unique")

    global_blockers = _validate_projected_blockers(
        projection["global_blockers"], "projection global blockers"
    )
    expected_alignment_status = "blocked" if global_blockers else "aligned"
    if projection["alignment_status"] != expected_alignment_status:
        raise ProjectionError("projection alignment status contradicts global blockers")

    route = _exact_object(projection["route"], PROJECTION_ROUTE_KEYS, "projection route")
    bindings_raw = route["bindings"]
    if not isinstance(bindings_raw, list):
        raise ProjectionError("projection route bindings must be an array")
    bindings = [_validate_route_binding(item) for item in bindings_raw]
    if bindings != sorted(bindings, key=lambda item: canonical_json_bytes(item)):
        raise ProjectionError("projection route bindings must be canonical-sorted")
    route_receipts = [item["receipt_id"] for item in bindings]
    if set(route_receipts) != evidence_receipt_ids or len(route_receipts) != len(
        set(route_receipts)
    ):
        raise ProjectionError("projection route bindings do not cover evidence exactly")
    evidence_by_receipt = {
        item["receipt_id"]: item for item in normalized_evidence
    }
    if any(
        item["producer"] != evidence_by_receipt[item["receipt_id"]]["producer"]
        for item in bindings
    ):
        raise ProjectionError("projection route producer contradicts evidence identity")
    primaries = [item for item in bindings if item["role"] == "primary"]
    expected_primary = primaries[0]["producer"] if len(primaries) == 1 else None
    if route["primary_domain"] != expected_primary:
        raise ProjectionError("projection primary domain contradicts route bindings")
    if expected_primary is not None and any(
        item["primary_domain"] != expected_primary for item in bindings
    ):
        raise ProjectionError("projection route bindings disagree on primary domain")
    if route["status"] != expected_alignment_status:
        raise ProjectionError("projection route status contradicts global blockers")
    route_blockers = _validate_projected_blockers(
        route["blockers"], "projection route blockers"
    )
    expected_route_blockers = [
        blocker
        for blocker in global_blockers
        if blocker["code"].startswith("ROUTE_")
        or blocker["code"] == "BORROWED_LENS_LIMIT_EXCEEDED"
    ]
    if route_blockers != expected_route_blockers:
        raise ProjectionError("projection route blockers contradict global blockers")
    exception = route["routing_exception"]
    if exception is not None:
        exception = validate_routing_exception(exception)
        if exception["material_context_sha256"] != _context_sha256(material_context):
            raise ProjectionError("projection routing exception belongs to another context")

    actions = projection["actions"]
    if not isinstance(actions, dict):
        raise ProjectionError("projection actions must be an object")
    for action_key, action in actions.items():
        _validate_projected_action(
            action_key,
            action,
            evidence_receipt_ids=evidence_receipt_ids,
            global_blockers=global_blockers,
        )
    if not _is_sha256(projection["alignment_snapshot_sha256"]):
        raise ProjectionError("alignment snapshot must be SHA-256")
    observed = projection["projection_sha256"]
    if (
        not _is_sha256(observed)
        or sha256_bytes(canonical_json_bytes(_projection_hash_source(projection))) != observed
    ):
        raise ProjectionError("projection integrity mismatch")
    if expected_material_context is not None:
        expected_context = _validate_material_context(expected_material_context)
        if projection["material_context"] != expected_context:
            raise ProjectionError("projection material context is stale or mutated")
    if expected_alignment_snapshot_sha256 is not None:
        if (
            not _is_sha256(expected_alignment_snapshot_sha256)
            or projection["alignment_snapshot_sha256"]
            != expected_alignment_snapshot_sha256
        ):
            raise ProjectionError("projection alignment snapshot binding mismatch")
    return projection


def domain_projection_ref(projection: dict[str, Any]) -> dict[str, str]:
    """Return the exact canonical digest/approval reference for this projection."""
    projection = validate_projection_integrity(projection)
    return {
        "projection_ref": DOMAIN_PROJECTION_REF,
        "projection_sha256": projection["projection_sha256"],
    }


def _parse_iso_time(value: Any, field: str) -> datetime:
    if not _canonical_nonblank(value):
        raise ProjectionError(f"{field} must be a canonical nonblank ISO-8601 time")
    try:
        parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
    except ValueError as exc:
        raise ProjectionError(f"{field} must be ISO-8601") from exc
    if parsed.tzinfo is None:
        raise ProjectionError(f"{field} must include timezone")
    return parsed.astimezone(timezone.utc)


def _string_array(value: Any, field: str) -> list[str]:
    if (
        not isinstance(value, list)
        or any(not _canonical_nonblank(item) for item in value)
        or len(value) != len(set(value))
    ):
        raise ProjectionError(f"{field} must be unique canonical nonblank strings")
    return value


def validate_canonical_approval(approval: Any) -> dict[str, Any]:
    """Validate the exact canonical pre-execution approval and issuance identity."""
    if APPROVAL_KEYS != frozenset(pre_execution_gate.APPROVAL_KEYS):
        raise ProjectionError("domain approval shape drifted from the parent contract")
    try:
        pre_execution_gate.validate_approval(approval)
    except pre_execution_gate.GateError as exc:
        raise ProjectionError(f"canonical parent approval rejected: {exc}") from exc
    approval = _exact_object(approval, APPROVAL_KEYS, "canonical pre-execution approval")
    if approval["format"] != pre_execution_gate.APPROVAL_FORMAT:
        raise ProjectionError("canonical approval format mismatch")
    for field in (
        "approval_id",
        "authorized_user_event_ref",
        "issued_at",
        "task_id",
        "workflow_epoch",
        "digest_id",
    ):
        if not _canonical_nonblank(approval[field]):
            raise ProjectionError(f"canonical approval {field} must be nonblank")
    for field in (
        "approval_id",
        "digest_sha256",
        "plan_sha256",
        "scope_sha256",
        "execution_snapshot_sha256",
    ):
        if not _is_sha256(approval[field]):
            raise ProjectionError(f"canonical approval {field} must be SHA-256")

    issued = _parse_iso_time(approval["issued_at"], "approval.issued_at")
    expiry = approval["expires_at"]
    if expiry is not None and _parse_iso_time(expiry, "approval.expires_at") <= issued:
        raise ProjectionError("canonical approval expires_at must follow issued_at")

    actions = approval["action_classes_and_stages"]
    if not isinstance(actions, list) or not actions:
        raise ProjectionError("canonical approval must contain action classes and stages")
    for item in actions:
        item = _exact_object(item, frozenset({"action", "stage"}), "approved action/stage")
        if not _canonical_nonblank(item["action"]) or not _canonical_nonblank(item["stage"]):
            raise ProjectionError("approved action and stage must be canonical and nonblank")

    roots_effects = _exact_object(
        approval["exact_roots_and_effects"],
        frozenset({"allowed_roots", "effects"}),
        "canonical approval roots/effects",
    )
    _string_array(roots_effects["allowed_roots"], "approval.allowed_roots")
    _string_array(roots_effects["effects"], "approval.effects")

    references = approval["domain_projection_refs_and_hashes"]
    if not isinstance(references, list):
        raise ProjectionError("domain projection references must be an array")
    normalized_refs: list[bytes] = []
    for reference in references:
        reference = _exact_object(
            reference, DOMAIN_PROJECTION_REF_KEYS, "canonical domain projection reference"
        )
        if not _canonical_nonblank(reference["projection_ref"]):
            raise ProjectionError("domain projection reference must be canonical and nonblank")
        if not _is_sha256(reference["projection_sha256"]):
            raise ProjectionError("domain projection reference hash must be SHA-256")
        normalized_refs.append(canonical_json_bytes(reference))
    if len(normalized_refs) != len(set(normalized_refs)):
        raise ProjectionError("canonical approval contains duplicate domain projection references")

    if not isinstance(approval["workload_cost_budget_stop_and_recovery_limits"], dict):
        raise ProjectionError("canonical approval workload limits must be an object")
    if not isinstance(approval["authority_and_protected_permit_refs"], list):
        raise ProjectionError("canonical approval authority refs must be an array")
    if approval["invalidation_triggers"] != sorted(pre_execution_gate.MATERIAL_INVALIDATION_FIELDS):
        raise ProjectionError("canonical approval invalidation triggers mismatch")
    if not isinstance(approval["revoked"], bool) or not _canonical_nonblank(approval["state"]):
        raise ProjectionError("canonical approval state/revocation fields are malformed")
    evidence = approval["invalidation_evidence"]
    if not isinstance(evidence, list):
        raise ProjectionError("canonical approval invalidation evidence must be an array")
    for item in evidence:
        item = _exact_object(
            item, frozenset({"changed_fields", "evidence_ref"}), "approval invalidation evidence"
        )
        _string_array(item["changed_fields"], "approval.changed_fields")
        if not _canonical_nonblank(item["evidence_ref"]):
            raise ProjectionError("approval invalidation evidence_ref must be nonblank")

    # ``approval_id`` identifies the immutable issuance.  The canonical
    # invalidator appends revocation evidence without changing that ID, so
    # normalize only those three invalidation fields before checking it.
    issuance_core = dict(approval)
    issuance_id = issuance_core.pop("approval_id")
    issuance_core["state"] = "approved"
    issuance_core["revoked"] = False
    issuance_core["invalidation_evidence"] = []
    if pre_execution_gate.sha256(issuance_core) != issuance_id:
        raise ProjectionError("canonical approval issuance integrity mismatch")
    return approval


def check_dispatch(
    projection: dict[str, Any],
    *,
    action_id: str,
    approval: dict[str, Any] | None,
    now: str,
    current_material_context: dict[str, Any],
    expected_alignment_snapshot_sha256: str,
) -> dict[str, Any]:
    """Check domain/approval join readiness, never a complete dispatch permit."""
    projection = validate_projection_integrity(
        projection,
        expected_material_context=current_material_context,
        expected_alignment_snapshot_sha256=expected_alignment_snapshot_sha256,
    )
    if not _canonical_nonblank(action_id):
        raise ProjectionError("dispatch action_id must be canonical and nonblank")
    current_time = _parse_iso_time(now, "now")
    reasons: list[str] = []
    action = projection["actions"].get(action_id)
    if action is None:
        reasons.append("UNKNOWN_ACTION")
    elif not action["domain_eligible"]:
        reasons.append("DOMAIN_ALIGNMENT_BLOCKED")
    elif action["join_kind"] == "result_acceptance" and action["result_debt"]:
        reasons.append("DOMAIN_RESULT_DEBT")

    approval_sha256 = None
    if approval is None:
        reasons.append("MISSING_APPROVAL")
    else:
        try:
            approval = validate_canonical_approval(approval)
            approval_sha256 = sha256_bytes(canonical_json_bytes(approval))
            if approval["state"] != "approved":
                reasons.append("APPROVAL_STATE_INVALID")
            if approval["revoked"] is not False:
                reasons.append("APPROVAL_REVOKED")
            if not approval["authorized_user_event_ref"].strip():
                reasons.append("APPROVAL_USER_EVENT_PROVENANCE_INVALID")
            context = projection["material_context"]
            if approval["task_id"] != context["task_id"]:
                reasons.append("APPROVAL_TASK_MISMATCH")
            if approval["workflow_epoch"] != context["workflow_epoch"]:
                reasons.append("APPROVAL_EPOCH_MISMATCH")
            if action is not None and {
                "action": action_id,
                "stage": action["action_stage"],
            } not in approval["action_classes_and_stages"]:
                if not any(item["action"] == action_id for item in approval["action_classes_and_stages"]):
                    reasons.append("APPROVAL_ACTION_MISMATCH")
                else:
                    reasons.append("APPROVAL_STAGE_MISMATCH")
            if approval["plan_sha256"] != context["plan_sha256"]:
                reasons.append("APPROVAL_PLAN_MISMATCH")
            if approval["scope_sha256"] != context["scope_sha256"]:
                reasons.append("APPROVAL_SCOPE_MISMATCH")
            if approval["execution_snapshot_sha256"] != context["execution_snapshot_sha256"]:
                reasons.append("APPROVAL_EXECUTION_SNAPSHOT_MISMATCH")
            if domain_projection_ref(projection) not in approval["domain_projection_refs_and_hashes"]:
                reasons.append("APPROVAL_DOMAIN_PROJECTION_MISMATCH")
            issued = _parse_iso_time(approval["issued_at"], "approval.issued_at")
            if current_time < issued:
                reasons.append("APPROVAL_NOT_YET_VALID")
            expiry = approval["expires_at"]
            if expiry is not None and current_time >= _parse_iso_time(
                expiry, "approval.expires_at"
            ):
                reasons.append("APPROVAL_EXPIRED")
        except ProjectionError:
            reasons.append("MALFORMED_APPROVAL")

    return {
        "dispatch_contract": "arlecchino-domain-join-decision-1",
        "action_id": action_id,
        "decision": "DOMAIN_JOIN_READY" if not reasons else "BLOCKED",
        "reason_codes": sorted(set(reasons)),
        "approval_sha256": approval_sha256,
        "alignment_snapshot_sha256": projection["alignment_snapshot_sha256"],
        "domain_projection_sha256": projection["projection_sha256"],
    }


def render_task_status_projection(projection: dict[str, Any]) -> dict[str, Any]:
    """Render an idempotent status delta; this function performs no file write."""
    projection = validate_projection_integrity(projection)
    actions = []
    for action_id, action in projection["actions"].items():
        actions.append({
            "action_id": action_id,
            "action_stage": action["action_stage"],
            "join_kind": action["join_kind"],
            "domain_eligible": action["domain_eligible"],
            "result_acceptance_eligible": action["result_acceptance_eligible"],
            "execution_state": action["execution_state"],
            "entry_blocker_count": len(action["entry_blockers"]),
            "result_debt_count": len(action["result_debt"]),
            "human_blocker_count": len(action["human_blockers"]),
            "handoff_blocker_count": len(action["handoff_blockers"]),
        })
    return {
        "render_contract": "arlecchino-domain-status-render-1",
        "writer_instruction": "coordinator_or_observer_only",
        "source_projection_sha256": projection["projection_sha256"],
        "alignment_snapshot_sha256": projection["alignment_snapshot_sha256"],
        "alignment_status": projection["alignment_status"],
        "preapproval_execution_allowed": False,
        "actions": actions,
    }


def native_receipt_to_transport(receipt: dict[str, Any]) -> dict[str, Any]:
    receipt = validate_native_evidence_receipt(receipt)
    return {
        "transport_contract": "arlecchino-native-domain-transport-1",
        "receipt_id": receipt["receipt_id"],
        "source_selection": receipt["source_selection"],
        "rendered_packet_bytes_base64": base64.b64encode(
            receipt["rendered_packet_bytes"]
        ).decode("ascii"),
    }


def native_receipt_from_transport(value: Any) -> dict[str, Any]:
    value = _exact_object(
        value,
        frozenset({
            "transport_contract",
            "receipt_id",
            "source_selection",
            "rendered_packet_bytes_base64",
        }),
        "native evidence transport",
    )
    if value["transport_contract"] != "arlecchino-native-domain-transport-1":
        raise ProjectionError("native transport contract mismatch")
    try:
        payload = base64.b64decode(value["rendered_packet_bytes_base64"], validate=True)
    except (ValueError, TypeError) as exc:
        raise ProjectionError("native transport bytes are not canonical base64") from exc
    return build_native_evidence_receipt(
        payload,
        receipt_id=value["receipt_id"],
        source_selection=value["source_selection"],
    )


if __name__ == "__main__":
    # Runtime use is import-oriented because approval objects must come from the
    # authenticated parent event stream.  Keep direct invocation deterministic.
    sys.stdout.write(json.dumps({
        "contract": PROJECTION_CONTRACT,
        "status": "library_ready",
        "preapproval_execution_allowed": False,
    }, sort_keys=True, separators=(",", ":")) + "\n")
