# TASK_STATUS

> Arlecchino-managed tracking ledger. This Markdown is the human-readable single
> source of truth for task progress; it is never parsed to grant approval,
> authority, writer identity, or execution permission.

<!-- ARLECCHINO:METADATA -->

## Contract and approval

<!-- ARLECCHINO:CONTRACT -->

## Self-grill receipt summary

<!-- ARLECCHINO:SELF_GRILL -->

## Domain gates

<!-- ARLECCHINO:DOMAIN_GATES -->

## Milestones

<!-- ARLECCHINO:MILESTONES -->

## Execution

<!-- ARLECCHINO:EXECUTION -->

## Decisions and replans

<!-- ARLECCHINO:DECISIONS -->

## Blockers

<!-- ARLECCHINO:BLOCKERS -->

## Verification

<!-- ARLECCHINO:VERIFICATION -->

## Terminal disposition

<!-- ARLECCHINO:TERMINAL -->
