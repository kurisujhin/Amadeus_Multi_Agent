#!/usr/bin/env bash
set -euo pipefail

bundle_root=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
series_root=${1:-$bundle_root/skills/multi-agent-workflow-designer}
v6_root="$series_root/versions/v6"
legacy_root="$series_root/subskills/snapshots/2026-07-12"
native_root="$series_root/subskills/snapshots/2026-07-12-v5-native"
legacy_manifest="$series_root/subskills/2026-07-12-v4-producers.sha256"

[[ -f "$v6_root/SKILL.md" ]]
grep -q '^name: arlecchino$' "$v6_root/SKILL.md"
[[ $(find "$v6_root" -type f ! -path '*/__pycache__/*' | wc -l) -eq 25 ]]
[[ $(find "$legacy_root" -mindepth 1 -maxdepth 1 -type d -name 'workflow-design-*' | wc -l) -eq 10 ]]
[[ $(find "$native_root" -mindepth 1 -maxdepth 1 -type d -name 'workflow-design-*' | wc -l) -eq 10 ]]

while read -r digest relative; do
  actual=$(sha256sum "$legacy_root/$relative" | cut -d' ' -f1)
  [[ $actual == "$digest" ]]
done < "$legacy_manifest"

(cd "$native_root" && sha256sum -c manifest.sha256 >/dev/null)
PYTHONDONTWRITEBYTECODE=1 python3 "$v6_root/scripts/validate_domain_packet.py" \
  "$v6_root/references/v5-domain-1.example.json" >/dev/null

while IFS= read -r markdown; do
  while IFS= read -r target; do
    case "$target" in
      ''|'#'*|http://*|https://*|mailto:*) continue ;;
    esac
    target=${target%%#*}
    [[ -e "$(dirname "$markdown")/$target" ]] || {
      printf 'Broken Markdown link: %s -> %s\n' "$markdown" "$target" >&2
      exit 1
    }
  done < <(grep -oE '\[[^]]*\]\([^)]+\)' "$markdown" | sed -E 's/^.*\]\(([^)]+)\)$/\1/' || true)
done < <(find "$v6_root" "$legacy_root" "$native_root" -type f -name '*.md' -print)

if [[ $series_root == "$bundle_root/skills/multi-agent-workflow-designer" ]]; then
  [[ $(find "$bundle_root/active" -mindepth 1 -maxdepth 1 -type l | wc -l) -eq 11 ]]
  for link in "$bundle_root"/active/*; do
    [[ -L "$link" && -e "$link/SKILL.md" ]]
  done
fi

printf 'Verified Arlecchino package closure: 1 parent, 10 V4 subskills, 10 native V5 subskills.\n'
